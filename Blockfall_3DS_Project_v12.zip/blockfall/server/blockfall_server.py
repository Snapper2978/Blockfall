#!/usr/bin/env python3
"""
Blockfall online relay server.

A small, dependency-free (Python 3.8+) asyncio server that lets Blockfall
consoles play over the internet.  It does NOT simulate the game: the host
console still runs the block simulation exactly like local wireless play.
The server only manages rooms and forwards packets between the host and the
players of a room (it mimics what 3DS local wireless does).

    python3 blockfall_server.py                  # listen on 0.0.0.0:7777
    python3 blockfall_server.py --port 9000

Open the TCP port in your firewall / router and put "your.host:7777" into
Blockfall's SETTINGS > SERVER on every console.

Rooms
  * PUBLIC  rooms show up in the in-game room browser.
  * PRIVATE rooms are hidden; players must type the exact room name
    (MULTIPLAYER > ONLINE > JOIN BY NAME).
  * Room names are unique (case-insensitive) while a room exists.
  * A room holds up to 8 players; joining is only possible while the room is
    in its lobby.  When the host leaves, the room is closed.

Wire protocol (all integers little endian)
  frame   = u16 length | u8 type | body          (length counts type + body)
  string  = u8 length | ASCII bytes

  client -> server
    0x01 LIST                                    (no body)
    0x02 CREATE   u8 version, u8 public, string room, string host_name
    0x03 JOIN     u8 version, string room
    0x04 DATA     u8 dst_node, payload           (dst 0xFF = everyone)
    0x05 LEAVE                                   (no body)
  server -> client
    0x81 ROOMS    u8 count, count x (string room, string host,
                                     u8 players, u8 max, u8 state)
    0x82 CREATED  u8 node                        (always 1: the host)
    0x83 JOINED   u8 node                        (2..8)
    0x84 ERROR    u8 code, string message
    0x85 DATA     u8 src_node, payload

The host is always node 1; players get nodes 2..8.  When someone leaves, the
server tells the host by delivering a synthetic "bye" game packet
(DATA, payload 04 00) from that node; when the host leaves it does the same
to every player, so the game's normal "player/host left" logic just works.
"""
import argparse
import asyncio
import logging
import signal
import sys
import time

PROTOCOL_VERSION = 1
MAX_PLAYERS = 8
HOST_NODE = 1
BROADCAST = 0xFF
ROOM_NAME_MAX = 16
PLAYER_NAME_MAX = 12
MAX_FRAME = 4096              # bigger frames are a protocol violation
IDLE_TIMEOUT = 30.0           # seconds without any frame => drop
LIST_LIMIT = 40               # rooms returned per LIST
SLOW_PEER_DROP = 128 * 1024   # skip world snapshots for a backlogged peer
SLOW_PEER_KILL = 1024 * 1024  # disconnect a peer this far behind

C_LIST, C_CREATE, C_JOIN, C_DATA, C_LEAVE = 0x01, 0x02, 0x03, 0x04, 0x05
S_ROOMS, S_CREATED, S_JOINED, S_ERROR, S_DATA = 0x81, 0x82, 0x83, 0x84, 0x85

# error codes
E_BAD_REQUEST, E_VERSION, E_NAME_TAKEN, E_NO_ROOM, E_FULL, E_STARTED, \
    E_BAD_NAME, E_BUSY, E_LIMIT = range(1, 10)

# game packet ids the server needs to know about (see main.c)
PKT_WORLD = 2
PKT_BYE = 4
STATE_LOBBY = 0

log = logging.getLogger("blockfall")


def clean_text(raw, limit):
    """Printable ASCII only, trimmed.  Returns '' when nothing usable is left."""
    text = "".join(chr(b) for b in raw if 32 <= b <= 126)
    return text.strip()[:limit]


def enc_str(text):
    data = text.encode("ascii", "replace")[:255]
    return bytes([len(data)]) + data


class Reader:
    """Bounds-checked reader for frame bodies."""

    def __init__(self, data):
        self.data, self.pos = data, 0

    def u8(self):
        if self.pos >= len(self.data):
            raise ValueError("short frame")
        v = self.data[self.pos]
        self.pos += 1
        return v

    def string(self):
        n = self.u8()
        if self.pos + n > len(self.data):
            raise ValueError("short string")
        v = self.data[self.pos:self.pos + n]
        self.pos += n
        return v

    def rest(self):
        v = self.data[self.pos:]
        self.pos = len(self.data)
        return v


class Room:
    def __init__(self, name, public, host_name):
        self.name = name
        self.public = public
        self.host_name = host_name
        self.state = STATE_LOBBY
        self.members = {}            # node -> Peer
        self.created = time.time()

    @property
    def key(self):
        return self.name.lower()

    def free_node(self):
        for node in range(HOST_NODE + 1, MAX_PLAYERS + 1):
            if node not in self.members:
                return node
        return None


class Peer:
    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.addr = writer.get_extra_info("peername")
        self.ip = self.addr[0] if self.addr else "?"
        self.room = None
        self.node = 0
        self.closed = False
        self.last_seen = time.time()
        self.control_times = []      # recent control-message timestamps

    def send(self, mtype, body=b"", droppable=False):
        if self.closed:
            return
        backlog = self.writer.transport.get_write_buffer_size()
        if backlog > SLOW_PEER_KILL:
            log.warning("%s too slow, disconnecting", self.ip)
            self.close()
            return
        if droppable and backlog > SLOW_PEER_DROP:
            return
        frame = bytes([mtype]) + body
        self.writer.write(len(frame).to_bytes(2, "little") + frame)

    def error(self, code, message):
        self.send(S_ERROR, bytes([code]) + enc_str(message))

    def close(self):
        if not self.closed:
            self.closed = True
            try:
                self.writer.close()
            except Exception:       # pragma: no cover
                pass


class Server:
    def __init__(self, max_rooms=200, max_per_ip=16):
        self.rooms = {}              # key -> Room
        self.peers = set()
        self.max_rooms = max_rooms
        self.max_per_ip = max_per_ip

    # ---- room bookkeeping -------------------------------------------------
    def drop_room(self, room):
        if self.rooms.get(room.key) is room:
            del self.rooms[room.key]
        log.info("room %r closed", room.name)

    def leave_room(self, peer, notify=True):
        room, node = peer.room, peer.node
        if room is None:
            return
        peer.room, peer.node = None, 0
        room.members.pop(node, None)
        bye = bytes([PKT_BYE, 0])
        if node == HOST_NODE:
            # host gone: every player gets a "host left" packet, room dies
            self.drop_room(room)
            for other in list(room.members.values()):
                other.room, other.node = None, 0
                if notify:
                    other.send(S_DATA, bytes([HOST_NODE]) + bye)
            room.members.clear()
        elif notify:
            host = room.members.get(HOST_NODE)
            if host:
                host.send(S_DATA, bytes([node]) + bye)
            log.info("player left room %r (%d left)", room.name, len(room.members))

    # ---- request handlers -------------------------------------------------
    def throttle(self, peer):
        now = time.time()
        peer.control_times = [t for t in peer.control_times if now - t < 10.0]
        peer.control_times.append(now)
        return len(peer.control_times) <= 30

    def on_list(self, peer):
        rooms = [r for r in self.rooms.values() if r.public]
        rooms.sort(key=lambda r: (r.state != STATE_LOBBY, -len(r.members), r.name.lower()))
        rooms = rooms[:LIST_LIMIT]
        body = bytearray([len(rooms)])
        for r in rooms:
            body += enc_str(r.name) + enc_str(r.host_name)
            body += bytes([len(r.members), MAX_PLAYERS, r.state])
        peer.send(S_ROOMS, bytes(body))

    def on_create(self, peer, rd):
        version, public = rd.u8(), rd.u8()
        name = clean_text(rd.string(), ROOM_NAME_MAX)
        host_name = clean_text(rd.string(), PLAYER_NAME_MAX) or "HOST"
        if version != PROTOCOL_VERSION:
            return peer.error(E_VERSION, "Server and game versions differ.")
        if peer.room:
            return peer.error(E_BUSY, "Already in a room.")
        if not name:
            return peer.error(E_BAD_NAME, "Room name is empty.")
        if name.lower() in self.rooms:
            return peer.error(E_NAME_TAKEN, "That room name is taken.")
        if len(self.rooms) >= self.max_rooms:
            return peer.error(E_LIMIT, "Server is full, try later.")
        room = Room(name, bool(public), host_name)
        room.members[HOST_NODE] = peer
        peer.room, peer.node = room, HOST_NODE
        self.rooms[room.key] = room
        log.info("room %r created (%s) by %s", name,
                 "public" if public else "private", peer.ip)
        peer.send(S_CREATED, bytes([HOST_NODE]))

    def on_join(self, peer, rd):
        version = rd.u8()
        name = clean_text(rd.string(), ROOM_NAME_MAX)
        if version != PROTOCOL_VERSION:
            return peer.error(E_VERSION, "Server and game versions differ.")
        if peer.room:
            return peer.error(E_BUSY, "Already in a room.")
        room = self.rooms.get(name.lower())
        if room is None:
            return peer.error(E_NO_ROOM, "No room with that name.")
        if room.state != STATE_LOBBY:
            return peer.error(E_STARTED, "That round already started.")
        node = room.free_node()
        if node is None:
            return peer.error(E_FULL, "That room is full.")
        room.members[node] = peer
        peer.room, peer.node = room, node
        log.info("player joined room %r as node %d", room.name, node)
        peer.send(S_JOINED, bytes([node]))

    def on_data(self, peer, rd):
        room = peer.room
        if room is None:
            return
        dst = rd.u8()
        payload = rd.rest()
        if not payload:
            return
        out = bytes([peer.node]) + payload
        if peer.node == HOST_NODE:
            if payload[0] == PKT_WORLD and len(payload) > 1:
                room.state = payload[1]          # lobby / countdown / playing / results
            if dst == BROADCAST:
                for node, other in list(room.members.items()):
                    if node != HOST_NODE:
                        other.send(S_DATA, out, droppable=(payload[0] == PKT_WORLD))
            else:
                other = room.members.get(dst)
                if other:
                    other.send(S_DATA, out)
        else:
            # players only ever talk to the host
            host = room.members.get(HOST_NODE)
            if host:
                host.send(S_DATA, out)

    def dispatch(self, peer, mtype, body):
        rd = Reader(body)
        if mtype == C_DATA:
            return self.on_data(peer, rd)
        if not self.throttle(peer):
            return peer.error(E_LIMIT, "Too many requests.")
        if mtype == C_LIST:
            self.on_list(peer)
        elif mtype == C_CREATE:
            self.on_create(peer, rd)
        elif mtype == C_JOIN:
            self.on_join(peer, rd)
        elif mtype == C_LEAVE:
            self.leave_room(peer)
        else:
            raise ValueError("unknown message type %d" % mtype)

    # ---- connection loop --------------------------------------------------
    async def handle(self, reader, writer):
        peer = Peer(reader, writer)
        if sum(1 for p in self.peers if p.ip == peer.ip) >= self.max_per_ip:
            peer.close()
            return
        self.peers.add(peer)
        try:
            while not peer.closed:
                head = await asyncio.wait_for(reader.readexactly(2), IDLE_TIMEOUT)
                length = int.from_bytes(head, "little")
                if length < 1 or length > MAX_FRAME:
                    raise ValueError("bad frame length %d" % length)
                frame = await asyncio.wait_for(reader.readexactly(length), IDLE_TIMEOUT)
                peer.last_seen = time.time()
                try:
                    self.dispatch(peer, frame[0], frame[1:])
                except ValueError as exc:
                    log.info("%s sent a bad request: %s", peer.ip, exc)
                    peer.error(E_BAD_REQUEST, "Bad request.")
        except (asyncio.IncompleteReadError, asyncio.TimeoutError,
                ConnectionError, ValueError):
            pass
        finally:
            self.peers.discard(peer)
            self.leave_room(peer)
            peer.close()


async def run(args):
    server = Server(max_rooms=args.max_rooms, max_per_ip=args.max_per_ip)
    srv = await asyncio.start_server(server.handle, args.host, args.port)
    for sock in srv.sockets:
        log.info("Blockfall server listening on %s:%s", *sock.getsockname()[:2])
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:      # Windows
            pass
    try:
        await stop.wait()
    except asyncio.CancelledError:       # pragma: no cover
        pass
    srv.close()
    await srv.wait_closed()


def main():
    ap = argparse.ArgumentParser(description="Blockfall online relay server")
    ap.add_argument("--host", default="0.0.0.0", help="address to bind (default 0.0.0.0)")
    ap.add_argument("--port", type=int, default=7777, help="TCP port (default 7777)")
    ap.add_argument("--max-rooms", type=int, default=200)
    ap.add_argument("--max-per-ip", type=int, default=16,
                    help="simultaneous connections per IP address")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(message)s", datefmt="%H:%M:%S")
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
