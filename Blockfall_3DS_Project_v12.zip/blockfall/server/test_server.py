#!/usr/bin/env python3
"""Tests for blockfall_server.py.   Run:  python3 server/test_server.py"""
import asyncio
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import blockfall_server as bs  # noqa: E402


class Client:
    """Minimal protocol client (what the 3DS does)."""

    def __init__(self, reader, writer):
        self.r, self.w = reader, writer

    @classmethod
    async def connect(cls, port):
        r, w = await asyncio.open_connection("127.0.0.1", port)
        return cls(r, w)

    def send(self, mtype, body=b""):
        frame = bytes([mtype]) + body
        self.w.write(len(frame).to_bytes(2, "little") + frame)

    async def recv(self, timeout=2.0):
        head = await asyncio.wait_for(self.r.readexactly(2), timeout)
        frame = await asyncio.wait_for(self.r.readexactly(int.from_bytes(head, "little")), timeout)
        return frame[0], frame[1:]

    async def expect(self, mtype):
        got, body = await self.recv()
        assert got == mtype, "expected 0x%02x got 0x%02x %r" % (mtype, got, body)
        return body

    async def silent(self, wait=0.15):
        try:
            await asyncio.wait_for(self.r.readexactly(2), wait)
        except asyncio.TimeoutError:
            return True
        except asyncio.IncompleteReadError:
            return True
        return False

    async def closed(self, timeout=2.0):
        try:
            data = await asyncio.wait_for(self.r.read(1), timeout)
            return data == b""
        except (ConnectionError, asyncio.TimeoutError):
            return True

    # helpers
    async def create(self, room, public=True, host="HOSTY", version=bs.PROTOCOL_VERSION):
        self.send(bs.C_CREATE, bytes([version, 1 if public else 0]) + bs.enc_str(room) + bs.enc_str(host))
        return await self.recv()

    async def join(self, room, version=bs.PROTOCOL_VERSION):
        self.send(bs.C_JOIN, bytes([version]) + bs.enc_str(room))
        return await self.recv()

    async def list(self):
        self.send(bs.C_LIST)
        body = await self.expect(bs.S_ROOMS)
        rd = bs.Reader(body)
        rooms = []
        for _ in range(rd.u8()):
            rooms.append((rd.string().decode(), rd.string().decode(), rd.u8(), rd.u8(), rd.u8()))
        return rooms

    def close(self):
        self.w.close()


class ServerTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.server = bs.Server(max_rooms=5, max_per_ip=20)
        self.srv = await asyncio.start_server(self.server.handle, "127.0.0.1", 0)
        self.port = self.srv.sockets[0].getsockname()[1]
        self.clients = []

    async def asyncTearDown(self):
        for c in self.clients:
            c.close()
        self.srv.close()
        await self.srv.wait_closed()

    async def new(self):
        c = await Client.connect(self.port)
        self.clients.append(c)
        return c

    async def room_with(self, n_players, name="Arena", public=True):
        host = await self.new()
        t, body = await host.create(name, public)
        self.assertEqual((t, body), (bs.S_CREATED, bytes([1])))
        players = []
        for k in range(n_players):
            p = await self.new()
            t, body = await p.join(name)
            self.assertEqual((t, body), (bs.S_JOINED, bytes([2 + k])))
            players.append(p)
        return host, players

    # ------------------------------------------------------------------
    async def test_empty_list(self):
        c = await self.new()
        self.assertEqual(await c.list(), [])

    async def test_public_room_is_listed(self):
        host, _ = await self.room_with(2, "Arena")
        viewer = await self.new()
        self.assertEqual(await viewer.list(), [("Arena", "HOSTY", 3, 8, 0)])

    async def test_private_room_hidden_but_joinable_by_name(self):
        host, _ = await self.room_with(0, "Secret", public=False)
        viewer = await self.new()
        self.assertEqual(await viewer.list(), [])
        t, body = await viewer.join("sEcReT")          # case-insensitive
        self.assertEqual((t, body), (bs.S_JOINED, bytes([2])))

    async def test_room_names_are_unique(self):
        await self.room_with(0, "Arena", public=False)
        other = await self.new()
        t, body = await other.create("ARENA", True)
        self.assertEqual(t, bs.S_ERROR)
        self.assertEqual(body[0], bs.E_NAME_TAKEN)

    async def test_name_is_sanitised_and_empty_rejected(self):
        c = await self.new()
        t, body = await c.create("   \x01\x02  ")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_BAD_NAME))
        raw = b"  A\x01B\xffC  " + b"x" * 40            # control + non-ASCII bytes on the wire
        c.send(bs.C_CREATE, bytes([bs.PROTOCOL_VERSION, 1]) + bytes([len(raw)]) + raw + bs.enc_str("H"))
        t, _ = await c.recv()
        self.assertEqual(t, bs.S_CREATED)
        viewer = await self.new()
        names = [r[0] for r in await viewer.list()]
        self.assertEqual(names, ["ABC  " + "x" * 11])   # control/non-ASCII dropped, 16 chars max
        self.assertEqual(len(names[0]), bs.ROOM_NAME_MAX)

    async def test_join_unknown_room(self):
        c = await self.new()
        t, body = await c.join("Nope")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_NO_ROOM))

    async def test_version_mismatch(self):
        c = await self.new()
        t, body = await c.create("Arena", version=99)
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_VERSION))
        host, _ = await self.room_with(0, "Arena")
        t, body = await c.join("Arena", version=99)
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_VERSION))

    async def test_relay_directions(self):
        host, (p2, p3) = await self.room_with(2)
        # player -> host only, tagged with the sender's node
        p2.send(bs.C_DATA, bytes([1]) + b"\x01hello")
        self.assertEqual(await host.expect(bs.S_DATA), bytes([2]) + b"\x01hello")
        self.assertTrue(await p3.silent())
        # a player cannot address another player
        p2.send(bs.C_DATA, bytes([3]) + b"\x01sneaky")
        self.assertEqual(await host.expect(bs.S_DATA), bytes([2]) + b"\x01sneaky")
        self.assertTrue(await p3.silent())
        # host broadcast reaches every player, not the host
        host.send(bs.C_DATA, bytes([bs.BROADCAST]) + b"\x09all")
        self.assertEqual(await p2.expect(bs.S_DATA), bytes([1]) + b"\x09all")
        self.assertEqual(await p3.expect(bs.S_DATA), bytes([1]) + b"\x09all")
        self.assertTrue(await host.silent())
        # host unicast reaches one player
        host.send(bs.C_DATA, bytes([3]) + b"\x05only3")
        self.assertEqual(await p3.expect(bs.S_DATA), bytes([1]) + b"\x05only3")
        self.assertTrue(await p2.silent())

    async def test_rooms_are_isolated(self):
        h1, (a,) = await self.room_with(1, "One")
        h2, (b,) = await self.room_with(1, "Two")
        a.send(bs.C_DATA, bytes([1]) + b"\x01x")
        await h1.expect(bs.S_DATA)
        self.assertTrue(await h2.silent())
        h2.send(bs.C_DATA, bytes([bs.BROADCAST]) + b"\x01y")
        await b.expect(bs.S_DATA)
        self.assertTrue(await a.silent())

    async def test_eight_players_max(self):
        host, players = await self.room_with(7)
        extra = await self.new()
        t, body = await extra.join("Arena")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_FULL))
        # a freed slot is reused
        players[2].close()
        await host.expect(bs.S_DATA)
        t, body = await extra.join("Arena")
        self.assertEqual((t, body), (bs.S_JOINED, bytes([4])))

    async def test_no_joining_after_round_starts(self):
        host, _ = await self.room_with(1)
        world = bytes([bs.PKT_WORLD, 2]) + b"\x00" * 20      # state = PLAYING
        host.send(bs.C_DATA, bytes([bs.BROADCAST]) + world)
        await asyncio.sleep(0.1)
        late = await self.new()
        self.assertEqual((await late.list())[0][4], 2)
        t, body = await late.join("Arena")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_STARTED))
        world = bytes([bs.PKT_WORLD, 0]) + b"\x00" * 20      # back to lobby
        host.send(bs.C_DATA, bytes([bs.BROADCAST]) + world)
        await asyncio.sleep(0.1)
        t, body = await late.join("Arena")
        self.assertEqual(t, bs.S_JOINED)

    async def test_player_leaving_notifies_host(self):
        host, (p2, p3) = await self.room_with(2)
        p3.close()
        self.assertEqual(await host.expect(bs.S_DATA), bytes([3, bs.PKT_BYE, 0]))
        viewer = await self.new()
        self.assertEqual((await viewer.list())[0][2], 2)

    async def test_host_leaving_closes_room(self):
        host, (p2, p3) = await self.room_with(2)
        host.close()
        self.assertEqual(await p2.expect(bs.S_DATA), bytes([1, bs.PKT_BYE, 0]))
        self.assertEqual(await p3.expect(bs.S_DATA), bytes([1, bs.PKT_BYE, 0]))
        viewer = await self.new()
        self.assertEqual(await viewer.list(), [])
        t, _ = await viewer.create("Arena")                 # name is free again
        self.assertEqual(t, bs.S_CREATED)

    async def test_leave_message_returns_to_browsing(self):
        host, (p2,) = await self.room_with(1)
        p2.send(bs.C_LEAVE)
        self.assertEqual(await host.expect(bs.S_DATA), bytes([2, bs.PKT_BYE, 0]))
        t, _ = await p2.join("Arena")                        # same connection can rejoin
        self.assertEqual(t, bs.S_JOINED)

    async def test_cannot_double_join(self):
        host, (p2,) = await self.room_with(1)
        t, body = await p2.join("Arena")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_BUSY))
        t, body = await host.create("Another")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_BUSY))

    async def test_room_limit(self):
        for k in range(5):
            await self.room_with(0, "Room%d" % k)
        c = await self.new()
        t, body = await c.create("OneTooMany")
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_LIMIT))

    async def test_garbage_is_handled(self):
        c = await self.new()
        c.send(0x7E, b"junk")                                # unknown type
        t, body = await c.recv()
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_BAD_REQUEST))
        c.send(bs.C_CREATE, bytes([1, 1, 200]))              # truncated string
        t, body = await c.recv()
        self.assertEqual((t, body[0]), (bs.S_ERROR, bs.E_BAD_REQUEST))
        self.assertEqual(await c.list(), [])                 # still alive
        c.w.write((bs.MAX_FRAME + 1).to_bytes(2, "little") + b"\x01")   # oversized frame
        self.assertTrue(await c.closed())

    async def test_data_outside_a_room_is_ignored(self):
        c = await self.new()
        c.send(bs.C_DATA, bytes([1]) + b"\x01x")
        self.assertEqual(await c.list(), [])

    async def test_per_ip_limit(self):
        srv = bs.Server(max_per_ip=2)
        s = await asyncio.start_server(srv.handle, "127.0.0.1", 0)
        port = s.sockets[0].getsockname()[1]
        a, b, c = [await Client.connect(port) for _ in range(3)]
        self.assertEqual(await a.list(), [])
        self.assertEqual(await b.list(), [])
        self.assertTrue(await c.closed())
        for x in (a, b, c):
            x.close()
        s.close()
        await s.wait_closed()

    async def test_list_ordering_and_privacy_counts(self):
        await self.room_with(0, "Empty")
        await self.room_with(3, "Busy")
        await self.room_with(1, "Hidden", public=False)
        viewer = await self.new()
        rooms = await viewer.list()
        self.assertEqual([r[0] for r in rooms], ["Busy", "Empty"])   # fullest first, no private


if __name__ == "__main__":
    unittest.main(verbosity=2)
