BLOCKFALL: STICKMAN SURVIVAL (Nintendo 3DS homebrew)
====================================================

WHAT'S INCLUDED
- Complete C source for a 2D survival game with a home screen, local and online multiplayer.
- Stick figure controlled with the D-pad or Circle Pad.
- Random falling blocks with collision detection.
- Difficulty increases as the survival timer advances.
- Five best survival times saved on the SD card.
- Top screen gameplay; bottom screen timer, difficulty and leaderboard.
- devkitPro Makefile that builds Blockfall.3dsx.

BUILD REQUIREMENTS
- A computer with devkitPro installed.
- 3DS development tools: devkitARM, libctru, citro2d and citro3d.
- GNU make.

BUILD
1. Install/update devkitPro and select the Nintendo 3DS development tools,
   including citro2d.
2. Extract this ZIP to a folder named Blockfall_3DS.
3. Open a devkitPro MSYS2 terminal in that folder.
4. Run:
       make
5. The build output should include Blockfall.3dsx (and Blockfall.elf).

RUN ON YOUR 3DS
1. Copy Blockfall.3dsx to:
       SD:/3ds/Blockfall/Blockfall.3dsx
2. Launch it from the Homebrew Launcher.
3. The leaderboard data is stored at:
       SD:/3ds/blockfall/leaderboard.dat

HOME SCREEN
- PLAY GAME   : single-player survival.
- MULTIPLAYER : LOCAL HOST / LOCAL JOIN (wireless, up to 8 consoles), ONLINE.
- SETTINGS    : PLAYER NAME (shown in multiplayer) and SERVER (online address).
  Both are edited with the 3DS keyboard and saved to
  SD:/3ds/blockfall/settings.cfg.

CONTROLS
- Menus: D-pad Up/Down to choose, A to select, B to go back.
- Move: D-pad left/right or Circle Pad (deliberately slower than before).
- Jump: A, B or D-pad Up (you can land on settled blocks).
- Double jump: press jump again in the air (one extra jump per airtime).
- Wall jump: press jump while touching a wall (the screen edges or the side
  of a block) in the air. ONE per airtime. It comes back when you land on the
  ground or on a block, and also when you touch the side of a block that has
  not landed yet (still falling). You slide down walls slowly while pushing
  into them.
- R: TAP pushes the stickman right in front of you (0.7 s cooldown, only
  matters with another player). HOLD (a quarter second) shoves the block you
  are touching sideways, up to about 28 px per hold.
- L: BLAST. Destroys every block (landed or falling) close to your stickman.
  15 second cooldown (shown at the bottom of the screen).
- After game over: A/B/X/Y restarts.
- START: back to the menu (quits the app from the home screen).

HOW YOU LOSE (changed)
- Only the BOTTOM of a falling block kills: a block coming down on your head.
  Touching a falling block from the side is harmless (it acts as a wall and
  you can wall-jump off it); its top is a floor. You are also out if you are
  squeezed between a falling block and a wall/another block, squashed under a
  landed block while standing, or carried off the bottom of the rising view.

TWO PLAYERS ON ONE CONSOLE (Azahar / New 3DS)
- A 3DS has exactly one set of buttons, and Azahar presents your controllers to
  the game as ONE virtual 3DS, so the game cannot see "controller 2" itself.
  What it can see are the extra New 3DS inputs. Player 2 therefore uses:
      C-stick left/right = move     ZL = jump (and double / wall jump)
      ZR = push (tap) / shove block (hold)       SELECT = blast
- Player 2 joins when ZL, ZR or SELECT is pressed during PLAY GAME. (The
  C-stick alone does not add a player, so a bumped nub can't.) The hint
  "P2: PRESS ZL / ZR TO JOIN" is shown at the bottom right.
- In Azahar: Emulation > Configure > Controls: map your SECOND controller's
  stick / two buttons / one more button to C-Stick, ZL, ZR and Select, and your
  first controller to the normal 3DS buttons. Azahar must be set to emulate a
  New 3DS (System settings), otherwise ZL/ZR/C-stick do not exist.
- Co-op: both stickmen live in the same world; P1 and P2 can push each other.
  The round ends when both are out; the time is the last survivor's.
- Not included: a second local player inside an ONLINE/WIRELESS match (the
  network protocol has one player per console).

THE RISING SCREEN
- After a 5 second grace period the view rises constantly. Anything below
  the bottom of the screen is gone - if you fall back down past it you are
  out. Keep climbing the pile!
- The rise slows if the pile lags far behind the top of the view, then speeds
  up as the pile catches up. Tune SCROLL_* / MOVE_SPEED at the top of main.c.
- Blocks are fully random: sizes, speeds, colours, irregular timing, plus
  hail bursts, slow wide slabs, fast thin spears and blocks aimed at players.
- Buried blocks are recycled, so blocks never stop falling.

MULTIPLAYER (up to 8 players)
- Every player needs this same Blockfall.3dsx on a modded 3DS (Homebrew
  Launcher), Wi-Fi on, consoles close together.
- One player picks MULTIPLAYER > HOST GAME; everyone else picks JOIN GAME.
- The host presses A in the lobby (2+ players) to start a round.
- Get hit on the head by a falling block, get squashed, or fall off the bottom: you are out
  and spectate. Last stickman standing wins; the host presses A to play again.
- PUSH (R tap): shove rivals into falling blocks or off ledges. 0.7 s
  cooldown; the shoved player is knocked sideways and briefly stunned.
- R hold shoves blocks and L blasts blocks in multiplayer too: the host moves /
  destroys the blocks, clients ask the host (cooldown and shove limit are
  enforced by the host). Everyone sees the blast ring.
- Network protocol version is now 4: all players need this version.
- Uses 3DS local wireless (UDS), so no internet connection is needed.

ROOM NAMES (LOCAL WIRELESS)
- LOCAL HOST opens the keyboard: type a room name. Joiners see it in their
  list with the host name and player count (X on the list = find by name).

ONLINE PLAY (own server, replaces the old Pretendo test)
- Pretendo cannot host homebrew rooms, so Blockfall has its own relay
  server in server/ (plain Python 3, no packages). It only forwards packets;
  the host console still simulates the blocks.
- Run it on any machine reachable from the internet:
      python3 server/blockfall_server.py --port 7777
  Open TCP 7777 in the firewall/router.
- On every console: SETTINGS > SERVER, type  your.host.name:7777
  (the default in main.c is a placeholder: change DEFAULT_SERVER or use
  the setting).
- MULTIPLAYER > ONLINE:
    HOST PUBLIC ROOM    keyboard for the name; listed in the room browser.
    HOST PRIVATE ROOM   not listed; friends use JOIN BY ROOM NAME.
    BROWSE PUBLIC ROOMS pick a room (auto-refreshes, Y = refresh, X = by name).
    JOIN BY ROOM NAME   type the exact name (works for public and private).
- Room names are unique (case-insensitive). Up to 8 players; joining is only
  possible in the lobby. If the host leaves, the room closes.
- Duplicate player names get a number (Bob, Bob2).

SETTING UP THE SERVER ON THE INTERNET: see deploy/DEPLOY.txt
  (VPS or home hosting, firewall, systemd service, check_server.py, and an
  optional update download page).
MAKING A CIA + UPDATING IT: see cia/CIA_GUIDE.txt (cia/make_cia.sh).

TESTS (PC, needs gcc and python3)
- tests/run_tests.sh runs: game/netcode unit tests (real main.c on fake 3DS
  libraries), the server tests, and an end-to-end test with the real server
  and several game clients (public/private rooms, browsing, late join).
- Not tested on hardware: no devkitPro/3DS here, so please build and try it.

IMPORTANT
This ZIP contains the compilable project source, not a prebuilt .3dsx binary.
A .3dsx must be produced by running make in a configured devkitPro
environment. The project uses citro2d/citro3d and libctru.
