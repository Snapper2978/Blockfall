#pragma once
#include <3ds.h>
static inline uint32_t C2D_Color32(int r,int g,int b,int a){return (uint32_t)(r|(g<<8)|(b<<16)|(a<<24));}
void C2D_SceneBegin(C3D_RenderTarget*);void C2D_TargetClear(C3D_RenderTarget*,uint32_t);
bool C2D_DrawRectSolid(float x,float y,float z,float w,float h,uint32_t clr);bool C2D_DrawCircleSolid(float,float,float,float,uint32_t);
bool C2D_DrawLine(float x0,float y0,uint32_t clr0,float x1,float y1,uint32_t clr1,float thickness,float depth);
typedef struct C2D_TextBuf_s* C2D_TextBuf; typedef struct { int d[8]; } C2D_Text;
C2D_TextBuf C2D_TextBufNew(size_t);void C2D_TextBufDelete(C2D_TextBuf);void C2D_TextBufClear(C2D_TextBuf);
const char* C2D_TextParse(C2D_Text*,C2D_TextBuf,const char*);void C2D_TextOptimize(const C2D_Text*);
void C2D_TextGetDimensions(const C2D_Text*,float,float,float*,float*);
#define C2D_WithColor 2
void C2D_DrawText(const C2D_Text*,u32,float,float,float,float,float,...);
