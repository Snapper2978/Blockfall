#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8; typedef int32_t Result;
#define R_FAILED(r) ((r)<0)
typedef struct{short dx,dy;}circlePosition;
#define KEY_A 1
#define KEY_B 2
#define KEY_X 4
#define KEY_Y 8
#define KEY_START 16
#define KEY_LEFT 32
#define KEY_RIGHT 64
#define KEY_UP 128
#define KEY_DOWN 512
#define KEY_TOUCH 256
#define KEY_L 1024
#define KEY_R 2048
#define KEY_SELECT 4096
#define KEY_ZL 8192
#define KEY_ZR 16384
#define KEY_CSTICK_LEFT 32768
#define KEY_CSTICK_RIGHT 65536
#define R_SUCCEEDED(r) ((r)>=0)
#define GFX_TOP 0
#define GFX_BOTTOM 1
#define GFX_LEFT 0
#define C3D_FRAME_SYNCDRAW 1
#define C3D_DEFAULT_CMDBUF_SIZE 1
#define C2D_DEFAULT_MAX_OBJECTS 1
typedef struct C3D_RenderTarget C3D_RenderTarget;
uint64_t osGetTime(void);u32 hidKeysHeld(void);u32 hidKeysDown(void);u32 hidKeysUp(void);void hidCstickRead(circlePosition*);void hidScanInput(void);void hidCircleRead(circlePosition*);
void gfxInitDefault(void);void consoleInit(int,void*);void romfsInit(void);void C3D_Init(int);void C2D_Init(int);void C2D_Prepare(void);
C3D_RenderTarget*C2D_CreateScreenTarget(int,int);bool aptMainLoop(void);void consoleClear(void);void gspWaitForVBlank(void);
void C2D_Fini(void);void C3D_Fini(void);void romfsExit(void);void gfxExit(void);void C3D_FrameBegin(int);void C3D_FrameEnd(int);
Result cfguInit(void);void cfguExit(void);
/* uds */
#define UDS_BROADCAST_NETWORKNODEID 0xFFFF
#define UDS_DEFAULT_RECVBUFSIZE 0x2E30
enum { UDS_SENDFLAG_Default = 2 };
typedef enum { UDSCONTYPE_Client = 1, UDSCONTYPE_Spectator = 2 } UDS_ConnectionType;
typedef struct { int dummy[8]; } udsBindContext;
typedef struct { int dummy[32]; } udsNetworkStruct;
typedef struct { u8 d[0x14]; udsNetworkStruct network; } udsNetworkScanInfo;
Result udsInit(size_t,const char*);void udsExit(void);
Result udsGenerateDefaultNetworkStruct(udsNetworkStruct*,u32,u8,u8);
Result udsCreateNetwork(const udsNetworkStruct*,const void*,size_t,udsBindContext*,u8,u32);
Result udsConnectNetwork(const udsNetworkStruct*,const void*,size_t,udsBindContext*,u16,UDS_ConnectionType,u8,u32);
Result udsScanBeacons(void*,size_t,udsNetworkScanInfo**,size_t*,u32,u8,const u8*,bool);
Result udsSendTo(u16,u8,u8,const void*,size_t);
Result udsPullPacket(const udsBindContext*,void*,size_t,size_t*,u16*);
Result udsUnbind(udsBindContext*);Result udsDestroyNetwork(void);Result udsDisconnectNetwork(void);

Result udsSetApplicationData(const void*,size_t);
Result udsGetNetworkStructApplicationData(const udsNetworkStruct*,void*,size_t,size_t*);

Result acInit(void);void acExit(void);Result ACU_GetWifiStatus(u32*);
Result socInit(u32*,u32);Result socExit(void);

/* software keyboard */
typedef struct { int dummy[64]; } SwkbdState;
typedef enum { SWKBD_TYPE_NORMAL = 0 } SwkbdType;
typedef enum { SWKBD_NOTEMPTY_NOTBLANK = 3 } SwkbdValidInput;
typedef enum { SWKBD_BUTTON_LEFT = 0, SWKBD_BUTTON_MIDDLE = 1, SWKBD_BUTTON_RIGHT = 2,
               SWKBD_BUTTON_CONFIRM = 2, SWKBD_BUTTON_NONE = 3 } SwkbdButton;
void swkbdInit(SwkbdState*,SwkbdType,int,int);
void swkbdSetValidation(SwkbdState*,SwkbdValidInput,u32,int);
void swkbdSetHintText(SwkbdState*,const char*);
void swkbdSetInitialText(SwkbdState*,const char*);
SwkbdButton swkbdInputText(SwkbdState*,char*,size_t);
