/*
 * Fake 3DS platform for the PC tests.  Include AFTER source/main.c (it
 * implements the libctru / citro2d / UDS functions main.c calls).
 *   - UDS: records what is sent, fakes scan results and the beacon data
 *   - software keyboard: the test chooses what the player "types"
 *   - clock: fakeNow, or real time when FAKE_CLOCK_REAL is defined
 */
#pragma once
/* ------------------------------------------------------------------ */
/* Fake platform layer                                                 */
/* ------------------------------------------------------------------ */
static uint64_t fakeNow = 1000000;
static u32 fakeHeld = 0, fakeDown = 0, fakeUp = 0;
static circlePosition fakeCircle = {0, 0}, fakeCstick = {0, 0};
#ifdef FAKE_CLOCK_REAL            /* end-to-end test: real time */
#include <time.h>
uint64_t osGetTime(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000u + (uint64_t)(ts.tv_nsec / 1000000) + 1000000u;
}
#else                             /* unit tests: time only moves when the test says so */
uint64_t osGetTime(void) { return fakeNow; }
#endif
u32 hidKeysHeld(void) { return fakeHeld; }
u32 hidKeysDown(void) { return fakeDown; }
u32 hidKeysUp(void) { return fakeUp; }
void hidCstickRead(circlePosition *c) { *c = fakeCstick; }
void hidScanInput(void) {}
void hidCircleRead(circlePosition *c) { *c = fakeCircle; }
void gfxInitDefault(void) {}
void consoleInit(int a, void *b) { (void)a; (void)b; }
void romfsInit(void) {}
void C3D_Init(int a) { (void)a; }
void C2D_Init(int a) { (void)a; }
void C2D_Prepare(void) {}
C3D_RenderTarget *C2D_CreateScreenTarget(int a, int b) { (void)a; (void)b; return NULL; }
bool aptMainLoop(void) { return false; }
void consoleClear(void) {}
void gspWaitForVBlank(void) {}
void C2D_Fini(void) {}
void C3D_Fini(void) {}
void romfsExit(void) {}
void gfxExit(void) {}
void C3D_FrameBegin(int a) { (void)a; }
void C3D_FrameEnd(int a) { (void)a; }
Result cfguInit(void) { return 0; }
void cfguExit(void) {}
void C2D_SceneBegin(C3D_RenderTarget *t) { (void)t; }
void C2D_TargetClear(C3D_RenderTarget *t, uint32_t c) { (void)t; (void)c; }
bool C2D_DrawRectSolid(float x, float y, float z, float w, float h, uint32_t c) { (void)x;(void)y;(void)z;(void)w;(void)h;(void)c; return true; }
bool C2D_DrawCircleSolid(float x, float y, float z, float r, uint32_t c) { (void)x;(void)y;(void)z;(void)r;(void)c; return true; }
bool C2D_DrawLine(float a, float b, uint32_t c, float d, float e, uint32_t f, float g, float h) { (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h; return true; }
C2D_TextBuf C2D_TextBufNew(size_t n) { (void)n; return NULL; }
void C2D_TextBufDelete(C2D_TextBuf b) { (void)b; }
void C2D_TextBufClear(C2D_TextBuf b) { (void)b; }
const char *C2D_TextParse(C2D_Text *t, C2D_TextBuf b, const char *s) { (void)t; (void)b; return s; }
void C2D_TextOptimize(const C2D_Text *t) { (void)t; }
void C2D_TextGetDimensions(const C2D_Text *t, float sx, float sy, float *w, float *h) { (void)t; *w = 10 * sx; *h = 10 * sy; }
void C2D_DrawText(const C2D_Text *t, u32 f, float x, float y, float z, float sx, float sy, ...) { (void)t;(void)f;(void)x;(void)y;(void)z;(void)sx;(void)sy; }

Result acInit(void) { return 0; }
void acExit(void) {}
Result ACU_GetWifiStatus(u32 *o) { *o = 3; return 0; }
Result socInit(u32 *a, u32 b) { (void)a; (void)b; return 0; }
Result socExit(void) { return 0; }

/* Fake keyboard: the test sets what the "player" types. */
static const char *fakeKbText = NULL;
static SwkbdButton fakeKbButton = SWKBD_BUTTON_CONFIRM;
static char fakeKbHint[96], fakeKbInitial[96];
static int fakeKbMax = 0;
void swkbdInit(SwkbdState *k, SwkbdType t, int b, int max) { (void)k;(void)t;(void)b; fakeKbMax = max; fakeKbHint[0] = fakeKbInitial[0] = 0; }
void swkbdSetValidation(SwkbdState *k, SwkbdValidInput v, u32 f, int d) { (void)k;(void)v;(void)f;(void)d; }
void swkbdSetHintText(SwkbdState *k, const char *t) { (void)k; snprintf(fakeKbHint, sizeof(fakeKbHint), "%s", t); }
void swkbdSetInitialText(SwkbdState *k, const char *t) { (void)k; snprintf(fakeKbInitial, sizeof(fakeKbInitial), "%s", t); }
SwkbdButton swkbdInputText(SwkbdState *k, char *buf, size_t size) {
    (void)k;
    if (fakeKbButton == SWKBD_BUTTON_CONFIRM && fakeKbText) snprintf(buf, size, "%s", fakeKbText);
    return fakeKbButton;
}

/* Fake UDS: record everything the game sends. */
typedef struct { uint16_t dst; size_t n; uint8_t buf[NET_BUF_SIZE]; } SentPacket;
static SentPacket sent[256];
static int sentCount = 0;
Result udsInit(size_t a, const char *b) { (void)a; (void)b; return 0; }
void udsExit(void) {}
Result udsGenerateDefaultNetworkStruct(udsNetworkStruct *n, u32 a, u8 b, u8 c) { (void)n;(void)a;(void)b;(void)c; return 0; }
Result udsCreateNetwork(const udsNetworkStruct *n, const void *p, size_t ps, udsBindContext *c, u8 d, u32 r) { (void)n;(void)p;(void)ps;(void)c;(void)d;(void)r; return 0; }
Result udsConnectNetwork(const udsNetworkStruct *n, const void *p, size_t ps, udsBindContext *c, u16 r, UDS_ConnectionType t, u8 d, u32 rb) { (void)n;(void)p;(void)ps;(void)c;(void)r;(void)t;(void)d;(void)rb; return 0; }
static udsNetworkScanInfo fakeScan[4];
static uint8_t fakeScanData[4][0xC8];
static size_t fakeScanLen[4];
static int fakeScanCount = 0;
static uint8_t fakeAppData[0xC8];
static size_t fakeAppDataLen = 0;
static int appDataSets = 0;
Result udsScanBeacons(void *o, size_t m, udsNetworkScanInfo **n, size_t *t, u32 w, u8 i, const u8 *h, bool c) { (void)o;(void)m;(void)w;(void)i;(void)h;(void)c; *n = fakeScan; *t = (size_t)fakeScanCount; return 0; }
Result udsSetApplicationData(const void *b, size_t n) { memcpy(fakeAppData, b, n); fakeAppDataLen = n; appDataSets++; return 0; }
Result udsGetNetworkStructApplicationData(const udsNetworkStruct *net, void *out, size_t size, size_t *actual) {
    size_t idx = (size_t)((const char *)net - (const char *)&fakeScan[0].network) / sizeof(udsNetworkScanInfo);
    if (idx >= 4 || fakeScanLen[idx] > size) return -1;
    memcpy(out, fakeScanData[idx], fakeScanLen[idx]);
    *actual = fakeScanLen[idx];
    return 0;
}
Result udsSendTo(u16 dst, u8 ch, u8 fl, const void *buf, size_t size) {
    (void)ch; (void)fl;
    if (sentCount < 256 && size <= NET_BUF_SIZE) {
        sent[sentCount].dst = dst;
        sent[sentCount].n = size;
        memcpy(sent[sentCount].buf, buf, size);
        sentCount++;
    }
    return 0;
}
Result udsPullPacket(const udsBindContext *c, void *b, size_t s, size_t *a, u16 *src) { (void)c;(void)b;(void)s; *a = 0; *src = 0; return 0; }
Result udsUnbind(udsBindContext *c) { (void)c; return 0; }
Result udsDestroyNetwork(void) { return 0; }
Result udsDisconnectNetwork(void) { return 0; }

