/*
 * Blockfall PC test-suite.
 *
 * Compiles the REAL source/main.c against fake 3DS / UDS / citro2d layers
 * (tests/stubs) and exercises the game + network logic headlessly:
 *   - world packet round trip (8 players, 96 blocks, huge/negative y)
 *   - 8-player lobby capacity and rejection of the 9th
 *   - push mechanic: range, relaying through the host, knockback
 *   - death only from a block's bottom, double jump, wall jump (+ resets)
 *   - R tap vs hold, block shoving, L blast + cooldown (local and online)
 *   - second local player (C-stick / ZL / ZR / SELECT)
 *   - constant screen rise, sweep-kill, culling, rubber band
 *   - block recycling when every slot is full
 *   - spawn randomness
 *   - slower movement speed
 *   - player names (packets, duplicates), keyboard input, saved settings
 *   - local room names carried in the wireless beacon
 *   - the online relay client: framing, rooms, create/join, errors, loss
 *     (fed through a real socketpair; tests/online_e2e.c runs it against the
 *     real server)
 *
 * Run:  tests/run_tests.sh
 */
#define SETTINGS_PATH "tests/.test_settings.cfg"
#define main blockfall_main
#include "../source/main.c"
#undef main

#include <assert.h>

#include "stubs/fake_platform.h"

/* ------------------------------------------------------------------ */
/* Tiny test framework                                                 */
/* ------------------------------------------------------------------ */
static int checks = 0, failures = 0;
#define CHECK(cond, ...) do { checks++; if (!(cond)) { failures++; \
    printf("  FAIL  %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
static void section(const char *name) { printf("\n[%s]\n", name); }

static void freshState(void) {
    memset(blocks, 0, sizeof(blocks));
    memset(players, 0, sizeof(players));
    sentCount = 0;
    fakeHeld = 0; fakeDown = 0;
    mode = MODE_MP_SESSION;
    isHost = true; myIndex = 0; welcomed = true; inSession = false;
    mpState = MP_LOBBY; mpTime = 0;
    playerX = 191; playerY = GROUND_Y; playerVY = 0; onGround = true;
    playerAnim = (Anim){0.0f, 1, false, 0, 0.0f};
    bodyResetAt(&me, 191.0f);
    bodyResetAt(&p2, 230.0f);
    p2Active = false;
    fakeUp = 0; fakeCircle = (circlePosition){0, 0}; fakeCstick = (circlePosition){0, 0};
    memset(hostBlastReady, 0, sizeof(hostBlastReady));
    memset(hostShoveLast, 0, sizeof(hostShoveLast));
    memset(hostShoveLock, 0, sizeof(hostShoveLock));
    resetScrollState();
    players[0].connected = true;
    players[0].alive = true;
    snprintf(players[0].name, sizeof(players[0].name), "HOST");
    netKind = NET_LOCAL;
    roomOnline = false;
}

static void makeHelloNamed(uint8_t *buf, size_t *n, const char *name) {
    uint8_t *p = buf;
    wr8(&p, PKT_HELLO); wr8(&p, PROTOCOL_VERSION); wrText(&p, name, NAME_LEN);
    *n = (size_t)(p - buf);
}
static void makeHello(uint8_t *buf, size_t *n) { makeHelloNamed(buf, n, "Bob"); }

/* ------------------------------------------------------------------ */
static void test_packet_roundtrip(void) {
    section("world packet round trip (8 players, 96 blocks)");
    freshState();
    srand(42);
    mpState = MP_PLAYING;
    mpTime = 123456;
    scrolling = true;
    autoCamY = -1234.5f;
    for (int i = 0; i < MAX_PLAYERS; i++) {
        players[i].connected = true;
        players[i].alive = (i % 3) != 0;
        players[i].x = 10.0f + (float)i * 40.25f;
        players[i].y = -5000.5f + (float)i * 100.0f;
        players[i].timeMs = 1000u * (unsigned)i + 7u;
        players[i].netPush = (i % 2) == 1;
        players[i].netFaceLeft = (i % 4) == 2;
        snprintf(players[i].name, sizeof(players[i].name), "Player%d", i + 1);
    }
    playerAnim.push = 0.1f; playerAnim.facing = -1; /* host (player 0) shoving left */
    for (int i = 0; i < MAX_BLOCKS; i++) {
        blocks[i].active = (i % 7) != 0;
        blocks[i].falling = (i % 2) == 0;
        blocks[i].type = i % 8;
        blocks[i].x = (float)(rand() % 320);
        blocks[i].y = -6000.0f + (float)(rand() % 6200) + 0.5f;
        blocks[i].w = (float)(8 + rand() % 140);
        blocks[i].h = (float)(8 + rand() % 70);
        blocks[i].speed = (float)(2 * (rand() % 170));
    }

    uint8_t buf[NET_BUF_SIZE];
    size_t n = encodeWorld(buf);
    CHECK(n == WORLD_PACKET_SIZE, "encoded %zu bytes, WORLD_PACKET_SIZE=%d", n, WORLD_PACKET_SIZE);
    CHECK(WORLD_PACKET_SIZE <= 1478, "world packet fits a UDS frame");
    CHECK(n <= 1478, "packet (%zu bytes) must fit in one UDS frame (1478)", n);
    printf("  world packet = %zu bytes (limit 1478)\n", n);

    Block expectB[MAX_BLOCKS]; NetPlayer expectP[MAX_PLAYERS];
    memcpy(expectB, blocks, sizeof(blocks));
    memcpy(expectP, players, sizeof(players));

    /* become client #3 and apply */
    memset(blocks, 0, sizeof(blocks));
    float ownX = 77.0f, ownY = 55.0f;
    memset(players, 0, sizeof(players));
    isHost = false; myIndex = 3; welcomed = true;
    mpState = MP_LOBBY; scrolling = false; autoCamY = NO_SCROLL;
    players[3].x = ownX; players[3].y = ownY;
    applyWorld(buf, n, fakeNow);

    CHECK(mpState == MP_PLAYING, "state");
    CHECK(mpTime == 123456, "mpTime=%u", (unsigned)mpTime);
    CHECK(scrolling && fabsf(autoCamY + 1234.5f) < 0.13f, "autoCamY=%f", autoCamY);
    CHECK(players[3].x == ownX && players[3].y == ownY, "own position must not be overwritten");

    int bad = 0;
    for (int i = 0; i < MAX_PLAYERS; i++) {
        CHECK(players[i].connected, "player %d connected", i);
        if (i == 3) continue;
        if (players[i].alive != expectP[i].alive) bad++;
        if (fabsf(players[i].tx - expectP[i].x) > 0.13f) bad++;
        if (fabsf(players[i].ty - expectP[i].y) > 0.13f) bad++;
        if (players[i].timeMs != expectP[i].timeMs) bad++;
        bool wantPush = (i == 0) ? true : expectP[i].netPush;
        bool wantLeft = (i == 0) ? true : expectP[i].netFaceLeft;
        if (players[i].netPush != wantPush) bad++;
        if (players[i].netFaceLeft != wantLeft) bad++;
    }
    CHECK(bad == 0, "%d player field mismatches", bad);
    for (int i = 0; i < MAX_PLAYERS; i++) {
        char want[16];
        snprintf(want, sizeof(want), "Player%d", i + 1);
        CHECK(strcmp(players[i].name, want) == 0, "name of player %d is \"%s\"", i, players[i].name);
    }

    bad = 0;
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (blocks[i].active != expectB[i].active) bad++;
        if (blocks[i].falling != expectB[i].falling) bad++;
        if (blocks[i].type != expectB[i].type) bad++;
        if (fabsf(blocks[i].x - expectB[i].x) > 0.13f) bad++;
        if (fabsf(blocks[i].y - expectB[i].y) > 0.13f) bad++;
        if (blocks[i].w != expectB[i].w || blocks[i].h != expectB[i].h) bad++;
        if (fabsf(blocks[i].speed - expectB[i].speed) > 2.01f) bad++;
    }
    CHECK(bad == 0, "%d block field mismatches", bad);

    /* "not scrolling" sentinel */
    freshState();
    mpState = MP_PLAYING;
    n = encodeWorld(buf);
    isHost = false; myIndex = 1; scrolling = true; autoCamY = -5;
    applyWorld(buf, n, fakeNow);
    CHECK(!scrolling && autoCamY >= NO_SCROLL * 0.5f, "no-scroll sentinel");

    /* truncated packets are ignored */
    mpState = MP_LOBBY;
    applyWorld(buf, n - 1, fakeNow);
    CHECK(mpState == MP_LOBBY, "truncated packet must be ignored");
}

static void test_lobby_capacity(void) {
    section("8-player lobby");
    freshState();
    mpState = MP_LOBBY;
    uint8_t buf[32]; size_t n;
    makeHello(buf, &n);
    for (int k = 1; k <= 7; k++) {
        sentCount = 0;
        handleHostPacket(buf, n, (uint16_t)(10 + k), fakeNow);
        CHECK(sentCount == 1 && sent[0].buf[0] == PKT_WELCOME && sent[0].buf[1] == k,
              "client %d should get slot %d (got %d)", k, k, sentCount ? sent[0].buf[1] : -1);
        CHECK(sent[0].dst == 10 + k, "welcome sent to node");
    }
    CHECK(countConnected() == 8, "8 connected, got %d", countConnected());
    /* everyone asked to be "Bob": duplicates get a number so scoreboards stay readable */
    CHECK(strcmp(players[1].name, "Bob") == 0 && strcmp(players[2].name, "Bob2") == 0 &&
          strcmp(players[7].name, "Bob7") == 0, "duplicate names numbered: %s %s %s",
          players[1].name, players[2].name, players[7].name);
    sentCount = 0;
    handleHostPacket(buf, n, 99, fakeNow);
    CHECK(sentCount == 1 && sent[0].buf[1] == 0xFF, "9th player must be rejected");
    /* duplicate HELLO from an existing node keeps its slot */
    sentCount = 0;
    handleHostPacket(buf, n, 13, fakeNow);
    CHECK(sent[0].buf[1] == 3, "duplicate hello keeps slot");
    /* wrong protocol version rejected */
    freshState();
    buf[1] = PROTOCOL_VERSION + 1;
    sentCount = 0;
    handleHostPacket(buf, n, 50, fakeNow);
    CHECK(sent[0].buf[1] == WELCOME_BAD_VERSION && countConnected() == 1, "protocol mismatch rejected");
    /* an old (name-less, version 2) client */
    uint8_t old[2] = {PKT_HELLO, 2};
    sentCount = 0;
    handleHostPacket(old, 2, 52, fakeNow);
    CHECK(sent[0].buf[1] == WELCOME_BAD_VERSION && countConnected() == 1, "old client told about the version");
    /* a name-less hello with the right version is not accepted either */
    old[1] = PROTOCOL_VERSION;
    sentCount = 0;
    handleHostPacket(old, 2, 53, fakeNow);
    CHECK(sent[0].buf[1] == 0xFF && countConnected() == 1, "truncated hello rejected");
    /* a client with an empty / junk name still joins */
    makeHelloNamed(buf, &n, "");
    sentCount = 0;
    handleHostPacket(buf, n, 54, fakeNow);
    CHECK(sent[0].buf[1] == 1 && strcmp(players[1].name, "PLAYER") == 0, "empty name becomes PLAYER");
    /* joining mid-match rejected */
    freshState();
    mpState = MP_PLAYING;
    makeHello(buf, &n);
    sentCount = 0;
    handleHostPacket(buf, n, 51, fakeNow);
    CHECK(sent[0].buf[1] == 0xFF, "join during a match rejected");
}

static void joinClient(int idx, uint16_t node) {
    players[idx].connected = true; players[idx].alive = true; players[idx].node = node;
    players[idx].x = players[idx].tx = 100.0f * (float)idx; players[idx].y = players[idx].ty = GROUND_Y;
}

/* One frame of the local player with the given buttons (+ mpIntents). */
static void step(u32 held, u32 down, u32 up) {
    fakeHeld = held; fakeDown = down; fakeUp = up;
    updatePlayer(1.0f / 60.0f);
    bool dead = resolvePlayerVsBlocks();
    (void)dead;
    mpIntents();
    fakeHeld = fakeDown = fakeUp = 0;
}
static void tapR(void) {
    step(KEY_R, KEY_R, 0);
    step(0, 0, KEY_R);
}

static void test_push(void) {
    section("push mechanic");
    freshState();
    mpState = MP_PLAYING;
    joinClient(2, 22); joinClient(5, 55);

    /* client 2 shoves client 5: host relays only to 5 */
    uint8_t pkt[4] = {PKT_PUSH, 2, 5, (uint8_t)(int8_t)1};
    sentCount = 0;
    handleHostPacket(pkt, 4, 22, fakeNow);
    CHECK(sentCount == 1 && sent[0].dst == 55 && sent[0].buf[0] == PKT_PUSH &&
          sent[0].buf[1] == 2 && sent[0].buf[2] == 5, "host must relay push to the victim only");

    /* spoofed sender ignored */
    sentCount = 0;
    handleHostPacket(pkt, 4, 99, fakeNow);
    CHECK(sentCount == 0, "push from the wrong node must be ignored");
    /* dead victim ignored */
    players[5].alive = false;
    handleHostPacket(pkt, 4, 22, fakeNow);
    CHECK(sentCount == 0, "pushing a dead player must be ignored");
    players[5].alive = true;
    /* not during lobby / countdown */
    mpState = MP_COUNTDOWN;
    handleHostPacket(pkt, 4, 22, fakeNow);
    CHECK(sentCount == 0, "no pushing outside PLAYING");
    mpState = MP_PLAYING;

    /* victim applies knockback */
    freshState();
    mpState = MP_PLAYING;
    isHost = false; myIndex = 5; players[5].connected = true; players[5].alive = true;
    onGround = true; playerKnockVX = 0; stunT = 0;
    uint8_t toVictim[4] = {PKT_PUSH, 2, 5, (uint8_t)(int8_t)-1};
    handleClientPacket(toVictim, 4, fakeNow);
    CHECK(fabsf(playerKnockVX + PUSH_SPEED) < 0.01f, "knockback left, got %f", playerKnockVX);
    CHECK(stunT > 0.2f, "stunned");
    CHECK(playerVY < 0 && !onGround, "hop when shoved on the ground");

    /* knockback actually moves and decays */
    freshState();
    mpState = MP_PLAYING;
    playerX = 200; playerKnockVX = PUSH_SPEED; stunT = 0.25f;
    for (int i = 0; i < 90; i++) updatePlayer(1.0f / 60.0f);
    CHECK(playerX > 230 && playerX < 280, "shoved distance plausible: x=%f", playerX);
    CHECK(playerKnockVX == 0.0f, "knockback decays to zero");

    /* a dead player is immune */
    freshState();
    isHost = false; myIndex = 1; mpState = MP_PLAYING;
    players[1].connected = true; players[1].alive = false; playerKnockVX = 0;
    applyPush(1);
    CHECK(playerKnockVX == 0.0f, "dead players are not pushed");

    /* host is the target */
    freshState();
    mpState = MP_PLAYING; joinClient(1, 11);
    uint8_t toHost[4] = {PKT_PUSH, 1, 0, (uint8_t)(int8_t)1};
    handleHostPacket(toHost, 4, 11, fakeNow);
    CHECK(playerKnockVX > 0, "host shoved by client");

    /* R tap: range, direction, cooldown */
    freshState();
    mpState = MP_PLAYING;
    joinClient(1, 11); joinClient(2, 22);
    players[1].x = playerX + PLAYER_W + 6; players[1].y = playerY;   /* in front */
    players[2].x = playerX - 60;           players[2].y = playerY;   /* far behind */
    playerAnim.facing = 1;
    sentCount = 0;
    tapR();
    CHECK(sentCount == 1 && sent[0].dst == 11, "R tap pushes only the player in front (sent=%d)", sentCount);
    CHECK(pushCooldown > 0.5f && playerAnim.push > 0.0f, "cooldown + animation start");
    sentCount = 0;
    tapR();
    CHECK(sentCount == 0, "cooldown blocks a second push");
    pushCooldown = 0;
    playerAnim.facing = -1;
    players[2].x = playerX - PLAYER_W - 6;
    sentCount = 0;
    tapR();
    CHECK(sentCount == 1 && sent[0].dst == 22, "pushes left when facing left");
    pushCooldown = 0;
    players[2].y = playerY - 100; /* standing far above */
    sentCount = 0;
    tapR();
    CHECK(sentCount == 0, "cannot push someone at a different height");
    pushCooldown = 0;

    /* X / Y / L / A no longer push */
    players[2].y = playerY;
    sentCount = 0;
    step(KEY_X | KEY_Y, KEY_X | KEY_Y, 0); step(0, 0, KEY_X | KEY_Y);
    CHECK(sentCount == 0 && !me.tapPush, "X / Y are not push buttons any more");
}


static Block mkBlock(float x, float y, float w, float h, bool falling) {
    return (Block){x, y, w, h, falling ? 100.0f : 0.0f, 0, true, falling};
}

static void settle(void) {                 /* run until standing on something */
    for (int i = 0; i < 400 && !me.grounded; i++) step(0, 0, 0);
}

static void test_new_rules(void) {
    section("death only from a block's bottom");
    freshState(); mode = MODE_SINGLE;
    me.x = 100;
    blocks[0] = mkBlock(95, GROUND_Y - 30 + 8, 30, 30, true);          /* bottom 8px into the head */
    CHECK(bodyResolve(&me), "falling block bottom on the head kills");

    freshState(); mode = MODE_SINGLE;
    me.x = 100;
    blocks[0] = mkBlock(me.x + PLAYER_W - 3, GROUND_Y - 5, 30, 40, true);   /* grazes the right side */
    CHECK(!bodyResolve(&me), "a falling block touching the side does NOT kill");
    CHECK(me.x == 100 - 3 || fabsf(me.x - 97.0f) < 0.01f, "pushed out sideways (x=%f)", me.x);
    CHECK(me.wallDir == 1, "that side counts as a wall (wallDir=%d)", me.wallDir);

    freshState(); mode = MODE_SINGLE;
    me.x = 100; me.y = 100; me.grounded = false;
    blocks[0] = mkBlock(me.x - 5, me.y + PLAYER_H - 3, 40, 30, true);       /* feet just on top */
    CHECK(!bodyResolve(&me) && me.grounded && fabsf(me.y - (blocks[0].y - PLAYER_H)) < 0.01f,
          "standing on top of a falling block is safe");

    freshState(); mode = MODE_SINGLE;
    me.x = 2;
    blocks[0] = mkBlock(2 + PLAYER_W - 4, GROUND_Y - 5, 30, 40, true);      /* pushes us into the wall */
    CHECK(bodyResolve(&me), "squeezed between a falling block and the wall kills");

    freshState(); mode = MODE_SINGLE;
    me.x = 100; me.y = 100; me.grounded = false;
    blocks[0] = mkBlock(90, 95 - 20, 40, 20, false);   /* settled block bottom just above the head */
    me.vy = -50;
    CHECK(!bodyResolve(&me), "bumping the underside of a settled block in the air is harmless");

    section("double jump");
    freshState(); mode = MODE_SINGLE;
    step(0, KEY_A, 0);
    CHECK(me.vy < -300 && !me.grounded, "ground jump");
    for (int i = 0; i < 8; i++) step(0, 0, 0);
    float before = me.vy;
    step(0, KEY_B, 0);
    CHECK(me.doubleUsed && me.vy < before - 50.0f, "second jump in the air works (vy %f -> %f)", before, me.vy);
    for (int i = 0; i < 25; i++) step(0, 0, 0);
    CHECK(me.vy > 0.0f && !me.grounded, "falling again, still in the air");
    float vy3 = me.vy;
    step(0, KEY_A, 0);
    CHECK(me.vy > vy3 - 1.0f, "no third jump");
    settle();
    CHECK(me.grounded, "landed");
    step(0, 0, 0);
    CHECK(!me.doubleUsed, "landing resets the double jump");
    step(0, KEY_UP, 0);
    for (int i = 0; i < 8; i++) step(0, 0, 0);
    step(0, KEY_UP, 0);
    CHECK(me.doubleUsed, "double jump available again after landing");

    section("wall jump");
    freshState(); mode = MODE_SINGLE;
    me.x = 2; me.y = GROUND_Y - 120; me.grounded = false; me.vy = 0;
    bodyResolve(&me);
    CHECK(me.wallDir == -1 && me.wallReady, "touching the left screen edge in the air");
    step(KEY_LEFT, KEY_A, 0);
    CHECK(me.vy < -300 && me.knockVX > 100.0f && !me.wallReady, "wall jump kicks away from the wall");
    CHECK(!me.doubleUsed, "wall jump does not spend the double jump");
    me.x = 2; me.y = GROUND_Y - 120; me.vy = 0; me.knockVX = 0; bodyResolve(&me);
    step(0, KEY_A, 0);
    CHECK(me.doubleUsed && me.knockVX < 150.0f, "second touch: wall jump is spent, the double jump fires instead");
    me.x = 2; me.y = GROUND_Y - 120; me.vy = 0; bodyResolve(&me);
    float vyc = me.vy;
    step(0, KEY_A, 0);
    CHECK(me.vy > vyc - 1.0f, "nothing left in the air after wall + double jump");
    settle(); step(0, 0, 0);
    CHECK(me.wallReady && !me.doubleUsed, "landing resets both");

    /* a settled block's side is a wall but does not reset by itself */
    freshState(); mode = MODE_SINGLE;
    blocks[0] = mkBlock(150, GROUND_Y - 200, 40, 200, false);
    me.x = 150 - PLAYER_W; me.y = GROUND_Y - 120; me.grounded = false; me.wallReady = false;
    bodyResolve(&me);
    CHECK(me.wallDir == 1 && !me.wallReady, "settled block side: wall, but no refresh");
    /* a block that has not landed yet refreshes it */
    freshState(); mode = MODE_SINGLE;
    blocks[0] = mkBlock(150, GROUND_Y - 200, 40, 200, true);
    me.x = 150 - PLAYER_W; me.y = GROUND_Y - 120; me.grounded = false; me.wallReady = false;
    bodyResolve(&me);
    CHECK(me.wallDir == 1 && me.wallReady, "falling block side refreshes the wall jump");
    /* standing on a settled block resets too */
    freshState(); mode = MODE_SINGLE;
    blocks[0] = mkBlock(100, GROUND_Y - 50, 60, 50, false);
    me.x = 110; me.y = GROUND_Y - 50 - PLAYER_H - 30; me.vy = 0; me.grounded = false;
    me.wallReady = false; me.doubleUsed = true;
    settle(); step(0, 0, 0);
    CHECK(me.wallReady && !me.doubleUsed && fabsf(me.y - (GROUND_Y - 50 - PLAYER_H)) < 0.5f,
          "landing on a block resets the jumps");

    section("R: tap pushes a player, hold shoves a block");
    freshState(); mpState = MP_PLAYING; mode = MODE_MP_SESSION;
    blocks[0] = mkBlock(me.x + PLAYER_W, GROUND_Y, 30, PLAYER_H, false);     /* touching, on the floor */
    blocks[1] = mkBlock(me.x + PLAYER_W + 30 + 10, GROUND_Y, 30, PLAYER_H, false); /* 10px further */
    joinClient(1, 11); players[1].x = 20; players[1].y = GROUND_Y;
    me.anim.facing = 1;
    float bx0 = blocks[0].x;
    sentCount = 0;
    for (int i = 0; i < 12; i++) step(KEY_R, i == 0 ? KEY_R : 0, 0);            /* 0.2 s: still a tap window */
    CHECK(blocks[0].x == bx0, "block not shoved before the tap window ends");
    for (int i = 0; i < 60; i++) step(KEY_R, 0, 0);
    float moved = blocks[0].x - bx0;
    CHECK(moved > 3.0f, "holding R shoves a block (%f px) even though the shover stays put", moved);
    CHECK(fabsf(moved - 10.0f) < 0.01f, "...and stops at the next block (%f px, gap 10)", moved);
    step(0, 0, KEY_R);
    CHECK(sentCount == 0 && !me.tapPush, "releasing a long hold is not also a player push");
    /* budget resets on release */
    blocks[1].active = false;
    me.x = blocks[0].x - PLAYER_W;                      /* step up to the block again */
    me.shoveLock = 0;
    bx0 = blocks[0].x;
    for (int i = 0; i < 12; i++) step(KEY_R, i == 0 ? KEY_R : 0, 0);
    for (int i = 0; i < 120; i++) step(KEY_R, 0, 0);
    moved = blocks[0].x - bx0;
    CHECK(fabsf(moved - PUSH_BLOCK_MAX) < 0.01f, "second hold: exactly the %f px limit, got %f", PUSH_BLOCK_MAX, moved);
    /* walls stop shoved blocks */
    blocks[0].x = SCREEN_W - 3 - 30 - 2; me.x = blocks[0].x - PLAYER_W;
    step(0, 0, KEY_R);
    for (int i = 0; i < 12; i++) step(KEY_R, i == 0 ? KEY_R : 0, 0);
    for (int i = 0; i < 60; i++) step(KEY_R, 0, 0);
    CHECK(blocks[0].x + blocks[0].w <= SCREEN_W - 3 + 0.01f, "block stays inside the screen");

    section("L: blast");
    freshState(); mpState = MP_PLAYING; mode = MODE_MP_SESSION;
    blocks[0] = mkBlock(me.x + PLAYER_W + 10, GROUND_Y - 20, 30, 30, false);
    blocks[1] = mkBlock(me.x - 40, GROUND_Y - 60, 30, 30, true);
    blocks[2] = mkBlock(me.x + 200, GROUND_Y - 20, 30, 30, false);
    step(0, KEY_L, 0);
    CHECK(!blocks[0].active && !blocks[1].active, "blocks around the stickman are destroyed");
    CHECK(blocks[2].active, "far blocks survive");
    CHECK(me.blastCd > 14.9f && me.blastFx > 0.3f, "cooldown (%f) and effect start", me.blastCd);
    blocks[0] = mkBlock(me.x + PLAYER_W + 10, GROUND_Y - 20, 30, 30, false);
    for (int i = 0; i < 60 * 10; i++) step(0, i == 100 ? KEY_L : 0, 0);
    CHECK(blocks[0].active && me.blastCd > 4.0f && me.blastCd < 5.1f, "no blast during cooldown (cd=%f)", me.blastCd);
    for (int i = 0; i < 60 * 5 + 5; i++) step(0, 0, 0);
    step(0, KEY_L, 0);
    CHECK(!blocks[0].active, "blast works again after 15 s");

    section("blast / block shove over the network");
    freshState(); mpState = MP_PLAYING;
    isHost = false; myIndex = 3; welcomed = true; players[3].connected = true; players[3].alive = true;
    blocks[0] = mkBlock(me.x + PLAYER_W + 10, GROUND_Y - 20, 30, 30, false);
    sentCount = 0;
    step(0, KEY_L, 0);
    CHECK(sentCount == 1 && sent[0].dst == NET_HOST_NODE && sent[0].buf[0] == PKT_BLAST && sent[0].buf[1] == 3,
          "client asks the host to blast");
    CHECK(blocks[0].active, "client does not edit blocks itself");
    blocks[1] = mkBlock(me.x + PLAYER_W, GROUND_Y, 30, PLAYER_H, false);
    me.anim.facing = 1;
    sentCount = 0;
    for (int i = 0; i < 12; i++) step(KEY_R, i == 0 ? KEY_R : 0, 0);
    for (int i = 0; i < 90; i++) step(KEY_R, 0, 0);
    step(0, 0, KEY_R);
    float total = 0; int pk = 0;
    for (int i = 0; i < sentCount; i++)
        if (sent[i].buf[0] == PKT_BLOCKPUSH) { total += (float)sent[i].buf[3] / 8.0f; pk++; }
    CHECK(pk >= 2 && total > 20.0f && total <= PUSH_BLOCK_MAX + 1.0f,
          "client sends block shoves (%d packets, %f px)", pk, total);

    /* host side */
    freshState(); mpState = MP_PLAYING;
    joinClient(1, 11);
    players[1].x = 100; players[1].y = GROUND_Y;
    blocks[0] = mkBlock(100 + PLAYER_W, GROUND_Y, 30, PLAYER_H, false);
    blocks[1] = mkBlock(100 - 80, GROUND_Y - 10, 30, 30, false);
    blocks[2] = mkBlock(400 - 33 - 30, GROUND_Y, 30, 30, false);
    uint8_t bp[4] = {PKT_BLOCKPUSH, 1, 1, 24};          /* +3 px */
    float x0 = blocks[0].x;
    handleHostPacket(bp, 4, 11, fakeNow);
    CHECK(fabsf(blocks[0].x - x0 - 3.0f) < 0.01f, "host moves the block next to that player (dx=%f)", blocks[0].x - x0);
    handleHostPacket(bp, 4, 99, fakeNow);
    CHECK(fabsf(blocks[0].x - x0 - 3.0f) < 0.01f, "shove from the wrong node ignored");
    uint8_t big[4] = {PKT_BLOCKPUSH, 1, 1, 255};        /* tries 31 px */
    handleHostPacket(big, 4, 11, fakeNow);
    CHECK(blocks[0].x - x0 <= PUSH_BLOCK_MAX + 0.01f, "host caps the shove per hold (%f)", blocks[0].x - x0);
    float cap = blocks[0].x - x0;
    handleHostPacket(big, 4, 11, fakeNow + 100);
    CHECK(blocks[0].x - x0 == cap, "no more until the hold ends");
    players[1].x = blocks[0].x - PLAYER_W;               /* walks up to the block again */
    handleHostPacket(big, 4, 11, fakeNow + 900);
    CHECK(blocks[0].x - x0 > cap, "budget refreshes after a pause");
    players[1].x = 100;

    uint8_t bl[2] = {PKT_BLAST, 1};
    handleHostPacket(bl, 2, 99, fakeNow);
    CHECK(blocks[1].active, "blast from the wrong node ignored");
    handleHostPacket(bl, 2, 11, fakeNow);
    CHECK(!blocks[1].active && blocks[2].active, "host blasts around that player only");
    CHECK(players[1].blastFx > 0.3f, "blast effect started for everyone to see");
    blocks[1] = mkBlock(100 - 80, GROUND_Y - 10, 30, 30, false);
    handleHostPacket(bl, 2, 11, fakeNow + 5000);
    CHECK(blocks[1].active, "host enforces the cooldown");
    handleHostPacket(bl, 2, 11, fakeNow + 15000);
    CHECK(!blocks[1].active, "...and allows it again later");

    /* effect travels in the world snapshot */
    freshState(); mpState = MP_PLAYING; joinClient(1, 11); players[1].blastFx = BLAST_FX_TIME;
    size_t n = encodeWorld(sendBuf);
    uint8_t snap[WORLD_PACKET_SIZE + 8]; memcpy(snap, sendBuf, n);
    freshState(); isHost = false; myIndex = 3; players[3].connected = true;
    applyWorld(snap, n, fakeNow);
    CHECK(players[1].blastFx > 0.3f, "clients see other players' blasts");
}

static void test_local_coop(void) {
    section("second local player (C-stick, ZL, ZR, SELECT)");
    freshState(); mode = MODE_SINGLE;
    resetGame();
    CHECK(!p2Active, "starts alone");
    fakeDown = KEY_A; fakeHeld = KEY_A;
    updateSingle(0.016f);
    CHECK(!p2Active, "normal buttons do not add a player");
    fakeCstick.dx = 156; fakeHeld = 0; fakeDown = 0;
    updateSingle(0.016f);
    CHECK(!p2Active, "bumping the C-stick alone does not add a player");
    fakeCstick.dx = 0; fakeDown = KEY_ZL;
    updateSingle(0.016f);
    CHECK(p2Active && p2.alive, "ZL joins player 2");
    fakeDown = 0;
    float x0 = p2.x;
    fakeCstick.dx = 156;
    for (int i = 0; i < 30; i++) updateSingle(0.016f);
    CHECK(p2.x > x0 + 40.0f, "C-stick moves player 2 (dx=%f)", p2.x - x0);
    CHECK(me.x == 191.0f, "player 1 unaffected");
    fakeCstick.dx = 0;
    float y0 = p2.y; fakeDown = KEY_ZL;
    updateSingle(0.016f); fakeDown = 0;
    for (int i = 0; i < 5; i++) updateSingle(0.016f);
    CHECK(p2.y < y0 - 5.0f || p2.vy < 0, "ZL jumps (y %f -> %f)", y0, p2.y);

    /* P1 dies, P2 carries on; game ends when both are out */
    me.x = 20; p2.x = 300; p2.y = GROUND_Y; me.y = GROUND_Y;
    blocks[0] = mkBlock(me.x - 2, GROUND_Y - 30 + 8, 30, 30, true);
    blocks[0].speed = 0;
    updateSingle(0.016f);
    CHECK(!me.alive && p2.alive && !gameOver, "P1 out, P2 still playing");
    p2.x = 300; p2.y = GROUND_Y; p2.vy = 0;
    blocks[1] = mkBlock(p2.x - 2, GROUND_Y - 30 + 8, 30, 30, true);
    blocks[1].speed = 0;
    updateSingle(0.016f);
    CHECK(!p2.alive && gameOver, "game over when both are out");

    /* blast / push of P2 with ZR and SELECT */
    freshState(); mode = MODE_SINGLE; resetGame();
    fakeDown = KEY_SELECT; updateSingle(0.016f); fakeDown = 0;            /* SELECT also joins ... */
    CHECK(p2Active, "SELECT joins player 2");
    p2.x = 300; p2.y = GROUND_Y;
    blocks[0] = mkBlock(p2.x + PLAYER_W + 8, GROUND_Y - 20, 30, 30, false);
    fakeDown = KEY_SELECT; updateSingle(0.016f); fakeDown = 0;
    CHECK(!blocks[0].active && p2.blastCd > 14.0f, "SELECT blasts for player 2");
    /* ZR tap pushes player 1 */
    me.x = 200; me.y = GROUND_Y; p2.x = me.x + PLAYER_W + 8; p2.y = GROUND_Y; p2.anim.facing = -1;
    p2.pushCd = 0;
    fakeHeld = KEY_ZR; updateSingle(0.016f);
    fakeHeld = 0; fakeUp = KEY_ZR; updateSingle(0.016f); fakeUp = 0;
    CHECK(me.knockVX < 0.0f && me.stun > 0.1f, "ZR tap shoves the other local player (knock=%f)", me.knockVX);
    fakeCstick.dx = 0;
}

static void test_scroll(void) {
    section("constant rising screen");
    freshState();
    mode = MODE_SINGLE;
    updateScroll(0.016f, 4000);
    CHECK(!scrolling, "no scroll during the grace period");
    updateScroll(0.016f, SCROLL_DELAY_MS + 100);
    CHECK(scrolling, "scroll starts after the grace period");

    float last = autoCamY; bool monotonic = true; float maxStep = 0;
    uint32_t t = SCROLL_DELAY_MS + 100;
    for (int i = 0; i < 60 * 120; i++) {           /* two minutes */
        t += 16;
        updateScroll(0.016f, t);
        if (autoCamY > last + 1e-6f) monotonic = false;
        if (last - autoCamY > maxStep) maxStep = last - autoCamY;
        last = autoCamY;
    }
    CHECK(monotonic, "the view only ever rises");
    CHECK(maxStep <= SCROLL_MAX * 0.016f + 1e-4f, "speed capped (max step %f)", maxStep);
    CHECK(autoCamY < -100.0f, "view keeps rising (autoCamY=%f)", autoCamY);

    /* rubber band: a tall pile near the top of the view lets it rise at full speed */
    freshState(); mode = MODE_SINGLE;
    updateScroll(0.016f, SCROLL_DELAY_MS + 1);
    float slowStart = autoCamY;
    for (int i = 0; i < 600; i++) updateScroll(0.016f, SCROLL_DELAY_MS + 2000 + i * 16);
    float slowDist = slowStart - autoCamY;
    freshState(); mode = MODE_SINGLE;
    updateScroll(0.016f, SCROLL_DELAY_MS + 1);
    float fastStart = autoCamY;
    for (int i = 0; i < 600; i++) {
        blocks[0].active = true; blocks[0].falling = false; blocks[0].y = autoCamY + 30; /* pile near top */
        updateScroll(0.016f, SCROLL_DELAY_MS + 2000 + i * 16);
    }
    float fastDist = fastStart - autoCamY;
    CHECK(fastDist > slowDist * 2.5f, "pile near the top => faster rise (%f vs %f)", fastDist, slowDist);

    /* falling back down kills */
    freshState(); mode = MODE_SINGLE;
    scrolling = true; autoCamY = -100.0f;
    playerY = GROUND_Y;                                  /* 198: below the view bottom (136) */
    CHECK(sweptAway(), "player below the view is swept away");
    playerY = -200.0f;
    CHECK(!sweptAway(), "player inside the view survives");
    autoCamY = NO_SCROLL; scrolling = false; playerY = GROUND_Y;
    CHECK(!sweptAway(), "no sweeping before the rise starts");

    /* blocks below the view disappear */
    freshState(); mode = MODE_SINGLE;
    scrolling = true; autoCamY = -500.0f;
    blocks[0] = (Block){10, 100, 20, 20, 0, 0, true, false};      /* far below */
    blocks[1] = (Block){10, -400, 20, 20, 0, 0, true, false};     /* in view  */
    blocks[2] = (Block){10, -700, 20, 20, 90, 0, true, true};     /* above     */
    cullBlocks();
    CHECK(!blocks[0].active && blocks[1].active && blocks[2].active, "only blocks below the view are culled");

    /* camera follows the player upward, but never below the rising limit */
    freshState(); mode = MODE_SINGLE;
    for (int i = 0; i < 120; i++) updateCamera(1.0f / 60.0f, -400.0f);
    CHECK(camY < -400.0f + 20.0f && camY > -600.0f, "camera follows a climbing player (camY=%f)", camY);
    scrolling = true; autoCamY = -900.0f;
    for (int i = 0; i < 120; i++) updateCamera(1.0f / 60.0f, 198.0f);
    CHECK(camY <= -900.0f + 0.01f, "view cannot sink below the rising limit (camY=%f)", camY);
}

static void test_recycle_and_random(void) {
    section("block recycling and randomness");
    freshState(); mode = MODE_SINGLE;
    for (int i = 0; i < MAX_BLOCKS; i++) {
        blocks[i] = (Block){(float)(i % 10) * 30, (float)i * 3, 20, 20, 0, 0, true, false};
    }
    spawnWave(10000);
    int falling = 0;
    for (int i = 0; i < MAX_BLOCKS; i++) if (blocks[i].active && blocks[i].falling) falling++;
    CHECK(falling >= 1, "spawning continues even when every slot is full");

    srand(7);
    int colors[8] = {0}, bursts = 0, aimed = 0;
    float minW = 999, maxW = 0, minH = 999, maxH = 0, minSp = 999, maxSp = 0;
    int distinct = 0;
    static uint32_t seen[4000]; int seenN = 0;
    playerX = 300; playerY = GROUND_Y;
    for (int i = 0; i < 3000; i++) {
        memset(blocks, 0, sizeof(blocks));
        spawnWave(20000);
        int n = 0;
        for (int b = 0; b < MAX_BLOCKS; b++) {
            if (!blocks[b].active) continue;
            n++;
            colors[blocks[b].type & 7]++;
            if (blocks[b].w < minW) minW = blocks[b].w;
            if (blocks[b].w > maxW) maxW = blocks[b].w;
            if (blocks[b].h < minH) minH = blocks[b].h;
            if (blocks[b].h > maxH) maxH = blocks[b].h;
            if (blocks[b].speed < minSp) minSp = blocks[b].speed;
            if (blocks[b].speed > maxSp) maxSp = blocks[b].speed;
            uint32_t key = ((uint32_t)blocks[b].w << 8) | (uint32_t)blocks[b].h;
            bool dup = false;
            for (int k = 0; k < seenN; k++) if (seen[k] == key) { dup = true; break; }
            if (!dup && seenN < 4000) { seen[seenN++] = key; distinct++; }
            /* every block must be above the view and inside the screen */
            CHECK(blocks[b].y + blocks[b].h <= 0.0f, "block spawns above the screen (y=%f)", blocks[b].y);
            CHECK(blocks[b].x >= 0 && blocks[b].x + blocks[b].w <= SCREEN_W, "block inside the walls");
        }
        if (n >= 3) bursts++;
        if (n == 1) {
            for (int b = 0; b < MAX_BLOCKS; b++)
                if (blocks[b].active && fabsf((blocks[b].x + blocks[b].w / 2) - 300.0f) < 45.0f) aimed++;
        }
    }
    printf("  sizes %.0f-%.0f x %.0f-%.0f, speeds %.0f-%.0f, %d distinct sizes, %d bursts\n",
           minW, maxW, minH, maxH, minSp, maxSp, distinct, bursts);
    for (int c = 0; c < 8; c++) CHECK(colors[c] > 100, "colour %d used (%d)", c, colors[c]);
    CHECK(minW <= 10 && maxW >= 120, "wide size range (%f..%f)", minW, maxW);
    CHECK(minH <= 12 && maxH >= 60, "tall size range (%f..%f)", minH, maxH);
    CHECK(maxSp - minSp > 150, "wide speed range");
    CHECK(distinct > 400, "many different block sizes (%d)", distinct);
    CHECK(bursts > 150 && bursts < 450, "hail bursts happen sometimes (%d of 3000)", bursts);
    CHECK(aimed > 150, "some blocks are aimed at the player (%d)", aimed);

    /* irregular spawn rhythm */
    freshState(); mode = MODE_SINGLE;
    lastSpawn = 0;
    uint32_t minD = 100000, maxD = 0;
    uint64_t now = 100000;
    for (int i = 0; i < 400; i++) {
        now += 2000;
        maybeSpawn(10000, now);
        if (spawnDelayMs < minD) minD = spawnDelayMs;
        if (spawnDelayMs > maxD) maxD = spawnDelayMs;
    }
    CHECK(maxD > minD * 3, "irregular delays (%u..%u ms)", (unsigned)minD, (unsigned)maxD);
}

static void test_movement_and_collision(void) {
    section("movement speed and block sides");
    freshState(); mode = MODE_SINGLE;
    fakeHeld = KEY_RIGHT;
    playerX = 20;
    for (int i = 0; i < 60; i++) updatePlayer(1.0f / 60.0f);
    CHECK(playerX - 20 <= 150.5f && playerX - 20 >= 140.0f, "1 s of running covers %f px (max 150)", playerX - 20);
    CHECK(MOVE_SPEED <= 150.0f && CPAD_SPEED <= 170.0f, "movement slowed down");
    fakeHeld = 0;

    freshState(); mode = MODE_SINGLE;
    blocks[0] = (Block){100, FLOOR_Y - 40, 40, 40, 0, 0, true, false};
    playerX = 75; bool dead = false;
    for (int i = 0; i < 30; i++) { playerX += 2.5f; dead |= resolvePlayerVsBlocks(); }
    CHECK(!dead && playerX <= 82.01f, "side of a settled block is a harmless wall (x=%f)", playerX);
    blocks[1] = (Block){playerX, playerY - 12, 20, 20, 100, 0, true, true};
    CHECK(resolvePlayerVsBlocks(), "a falling block still kills");
}

/* ------------------------------------------------------------------ */
static void test_text_and_settings(void) {
    section("names, keyboard and saved settings");
    char b[96];

    snprintf(b, sizeof(b), "  He\x01llo \xc3\xa9World  ");
    sanitizeText(b, 12);
    CHECK(strcmp(b, "Hello World") == 0, "sanitised: \"%s\"", b);
    snprintf(b, sizeof(b), "   \x02\xff  ");
    sanitizeText(b, 12);
    CHECK(b[0] == '\0', "blank / junk becomes empty");
    snprintf(b, sizeof(b), "ABCDEFGHIJKLMNOP");
    sanitizeText(b, 12);
    CHECK(strcmp(b, "ABCDEFGHIJKL") == 0 && strlen(b) == 12, "cut to 12 characters");
    CHECK(sameText("Arena", "aRENA") && !sameText("Arena", "Aren") && !sameText("", "x"), "sameText");

    /* keyboard */
    char out[NAME_LEN + 1] = "keep";
    fakeKbText = "Zed\xc3\xa9\x01 The Great Wizard"; fakeKbButton = SWKBD_BUTTON_CONFIRM;
    CHECK(askText("Your name", "Old", out, NAME_LEN), "confirmed text accepted");
    CHECK(strcmp(out, "Zed The Grea") == 0, "keyboard text sanitised and cut: \"%s\"", out);
    CHECK(strcmp(fakeKbHint, "Your name") == 0 && strcmp(fakeKbInitial, "Old") == 0 && fakeKbMax == NAME_LEN,
          "hint / initial text / length passed to the keyboard");
    strcpy(out, "keep");
    fakeKbButton = SWKBD_BUTTON_LEFT;
    CHECK(!askText("x", NULL, out, NAME_LEN) && strcmp(out, "keep") == 0, "cancel changes nothing");
    fakeKbButton = SWKBD_BUTTON_CONFIRM; fakeKbText = "\x01\x02   ";
    CHECK(!askText("x", NULL, out, NAME_LEN) && strcmp(out, "keep") == 0, "unusable text rejected");

    /* settings file round trip */
    remove(SETTINGS_PATH);
    snprintf(settingName, sizeof(settingName), "Ana");
    snprintf(settingServer, sizeof(settingServer), "my.host.net:9000");
    saveSettings();
    snprintf(settingName, sizeof(settingName), "x");
    snprintf(settingServer, sizeof(settingServer), "y");
    loadSettings();
    CHECK(strcmp(settingName, "Ana") == 0 && strcmp(settingServer, "my.host.net:9000") == 0,
          "settings survive a save/load (%s, %s)", settingName, settingServer);

    /* a hand-edited / hostile file cannot break the limits */
    FILE *f = fopen(SETTINGS_PATH, "w");
    fprintf(f, "name=  ABCDEFGHIJKLMNOPQRSTUV\x01\r\nserver=\r\nbogus=1\r\n");
    fclose(f);
    snprintf(settingServer, sizeof(settingServer), "keep.me:1");
    loadSettings();
    CHECK(strcmp(settingName, "ABCDEFGHIJKL") == 0, "long name cut to 12: \"%s\"", settingName);
    CHECK(strcmp(settingServer, "keep.me:1") == 0, "empty server line ignored");

    /* the SETTINGS screen */
    remove(SETTINGS_PATH);
    mode = MODE_SETTINGS; settingsSel = 0;
    fakeKbText = "Bob"; fakeKbButton = SWKBD_BUTTON_CONFIRM;
    updateSettings(KEY_A);
    CHECK(strcmp(settingName, "Bob") == 0, "player name edited with the keyboard");
    updateSettings(KEY_DOWN);
    CHECK(settingsSel == 1, "cursor moves");
    fakeKbText = "play.example.org:7777";
    updateSettings(KEY_A);
    CHECK(strcmp(settingServer, "play.example.org:7777") == 0, "server edited");
    snprintf(settingName, sizeof(settingName), "zzz");
    loadSettings();
    CHECK(strcmp(settingName, "Bob") == 0, "settings were saved to the card");
    updateSettings(KEY_DOWN);
    updateSettings(KEY_A);
    CHECK(mode == MODE_MENU, "BACK leaves the settings");
    mode = MODE_SETTINGS; updateSettings(KEY_B);
    CHECK(mode == MODE_MENU, "B leaves the settings");
    remove(SETTINGS_PATH);

    /* server address parsing */
    char host[SERVER_LEN + 1], port[16];
    snprintf(settingServer, sizeof(settingServer), "a.b.c:1234");
    splitServer(host, sizeof(host), port, sizeof(port));
    CHECK(!strcmp(host, "a.b.c") && !strcmp(port, "1234"), "host:port");
    snprintf(settingServer, sizeof(settingServer), "a.b.c");
    splitServer(host, sizeof(host), port, sizeof(port));
    CHECK(!strcmp(host, "a.b.c") && atoi(port) == ONLINE_DEFAULT_PORT, "default port");
    snprintf(settingServer, sizeof(settingServer), "a.b.c:");
    splitServer(host, sizeof(host), port, sizeof(port));
    CHECK(!strcmp(host, "a.b.c") && atoi(port) == ONLINE_DEFAULT_PORT, "trailing colon");
    snprintf(settingName, sizeof(settingName), "PLAYER");
}

static void test_names_in_game(void) {
    section("player names in the lobby and results");
    freshState();
    myIndex = 0;
    snprintf(players[0].name, sizeof(players[0].name), "Anna");
    char tmp[8], label[64];
    CHECK(strcmp(playerLabel(0, tmp, sizeof(tmp)), "Anna") == 0, "named player shows the name");
    CHECK(strcmp(playerLabel(3, tmp, sizeof(tmp)), "P4") == 0, "unnamed player falls back to P4");
    playerName(0, label, sizeof(label));
    CHECK(strcmp(label, "Anna (HOST) - YOU") == 0, "host label \"%s\"", label);
    joinClient(1, 11);
    snprintf(players[1].name, sizeof(players[1].name), "Ben");
    playerName(1, label, sizeof(label));
    CHECK(strcmp(label, "Ben") == 0, "client label \"%s\"", label);

    /* the host broadcasts everybody's names, a client adopts them (even its own, if renamed) */
    uint8_t buf[NET_BUF_SIZE];
    size_t n = encodeWorld(buf);
    memset(players, 0, sizeof(players));
    isHost = false; myIndex = 1; welcomed = true;
    snprintf(players[1].name, sizeof(players[1].name), "Ben");
    applyWorld(buf, n, fakeNow);
    CHECK(strcmp(players[0].name, "Anna") == 0 && strcmp(players[1].name, "Ben") == 0, "names arrive in the world packet");
}

static void test_local_room_names(void) {
    section("local wireless: room name in the beacon / join list");
    freshState();
    fakeScanCount = 0; appDataSets = 0;
    snprintf(settingName, sizeof(settingName), "Hosty");
    CHECK(hostStart("Cool Room"), "hostStart");
    CHECK(inSession && isHost && netKind == NET_LOCAL && strcmp(roomName, "Cool Room") == 0, "room name kept");
    CHECK(appDataSets == 1 && fakeAppDataLen == BEACON_SIZE, "beacon published (%zu bytes)", fakeAppDataLen);
    CHECK(fakeAppData[0] == 'B' && fakeAppData[1] == 'F' && fakeAppData[2] == PROTOCOL_VERSION &&
          fakeAppData[3] == 1 && fakeAppData[4] == 0, "beacon header: 1 player, lobby");

    /* a player arrives -> beacon refreshes; nothing changes -> no refresh */
    joinClient(1, 21);
    updateBeacon(false);
    CHECK(appDataSets == 2 && fakeAppData[3] == 2, "player count republished");
    updateBeacon(false);
    CHECK(appDataSets == 2, "unchanged state is not republished");
    mpState = MP_PLAYING;
    updateBeacon(false);
    CHECK(appDataSets == 3 && fakeAppData[4] == 1, "round in progress republished");
    mpState = MP_LOBBY;
    updateBeacon(false);

    /* what a scanning console sees */
    memcpy(fakeScanData[0], fakeAppData, fakeAppDataLen); fakeScanLen[0] = fakeAppDataLen;
    fakeScanLen[1] = 0;                                  /* old build without beacon data */
    uint8_t junk[40] = {'X', 'Y'}; memcpy(fakeScanData[2], junk, sizeof(junk)); fakeScanLen[2] = sizeof(junk);
    fakeScanCount = 3;
    netStop();
    CHECK(netBegin(), "netBegin");
    joinScan();
    CHECK(localCount == 3, "3 networks found");
    CHECK(localRooms[0].known && strcmp(localRooms[0].name, "Cool Room") == 0 &&
          strcmp(localRooms[0].host, "Hosty") == 0 && localRooms[0].players == 2 &&
          localRooms[0].max == MAX_PLAYERS && localRooms[0].state == 0,
          "room info parsed: \"%s\" by %s %u/%u", localRooms[0].name, localRooms[0].host,
          localRooms[0].players, localRooms[0].max);
    CHECK(!localRooms[1].known && !localRooms[2].known, "networks without room info are listed as plain games");

    /* joining remembers the room name */
    CHECK(joinConnect(0), "joinConnect");
    CHECK(!isHost && strcmp(roomName, "Cool Room") == 0 && !roomOnline && mode == MODE_MP_SESSION, "joined by room");
    netStop();
    fakeScanCount = 0;

    /* join screen: "find by name" keyboard + refusing a running round */
    freshState();
    mode = MODE_MP_JOIN; scanCountdown = 0;
    localCount = 3; scanTotal = 3; scanNets = fakeScan; joinSel = 0; joinTop = 0;
    memset(localRooms, 0, sizeof(localRooms));
    snprintf(localRooms[0].name, ROOM_LEN + 1, "Alpha");  localRooms[0].known = true; localRooms[0].max = 8;
    snprintf(localRooms[1].name, ROOM_LEN + 1, "Bravo");  localRooms[1].known = true; localRooms[1].max = 8; localRooms[1].state = 1;
    snprintf(localRooms[2].name, ROOM_LEN + 1, "Charlie"); localRooms[2].known = true; localRooms[2].max = 8;
    fakeKbText = "cHARLIE"; fakeKbButton = SWKBD_BUTTON_CONFIRM;
    updateFrame(0.016f, KEY_X);
    CHECK(joinSel == 2 && joinMsg[0] == '\0', "typed name selects the room (joinSel=%d)", joinSel);
    fakeKbText = "Nope";
    updateFrame(0.016f, KEY_X);
    CHECK(joinSel == 2 && strstr(joinMsg, "NO ROOM NAMED") != NULL, "unknown name reports not found: %s", joinMsg);
    joinSel = 1;
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_MP_JOIN && strstr(joinMsg, "ALREADY STARTED") != NULL, "cannot join a running round");
    scanNets = NULL; scanTotal = 0; localCount = 0;
    mode = MODE_MENU;
    snprintf(settingName, sizeof(settingName), "PLAYER");
}

/* ---- online client: drive it with a real socketpair acting as the server ---- */
static int peerFd = -1;

static void attachSocket(void) {
    int sv[2];
    int rc = socketpair(AF_UNIX, SOCK_STREAM, 0, sv);
    assert(rc == 0);
    (void)rc;
    onlineDisconnect();
    sockFd = sv[0];
    fcntl(sockFd, F_SETFL, fcntl(sockFd, F_GETFL, 0) | O_NONBLOCK);
    peerFd = sv[1];
    fcntl(peerFd, F_SETFL, fcntl(peerFd, F_GETFL, 0) | O_NONBLOCK);
    onlineLost = false;
}
static void detachPeer(void) { if (peerFd >= 0) { close(peerFd); peerFd = -1; } }

static void peerSend(uint8_t type, const void *body, size_t n) {
    uint8_t f[ONLINE_MAX_FRAME + 8];
    size_t len = 1 + n;
    f[0] = (uint8_t)(len & 0xFF); f[1] = (uint8_t)(len >> 8); f[2] = type;
    if (n) memcpy(f + 3, body, n);
    ssize_t w = write(peerFd, f, 2 + len);
    assert(w == (ssize_t)(2 + len));
    (void)w;
}
/* one frame sent by the console: returns type, body in out */
static int peerRecvFrame(uint8_t *out, size_t *n) {
    uint8_t h[2];
    ssize_t r = read(peerFd, h, 2);
    if (r != 2) return -1;
    size_t len = (size_t)h[0] | ((size_t)h[1] << 8);
    uint8_t tmp[ONLINE_MAX_FRAME + 4];
    size_t got = 0;
    while (got < len) { ssize_t k = read(peerFd, tmp + got, len - got); if (k <= 0) return -1; got += (size_t)k; }
    memcpy(out, tmp + 1, len - 1);
    *n = len - 1;
    return tmp[0];
}
static void drain(void) { uint8_t b[ONLINE_MAX_FRAME]; size_t n; while (peerRecvFrame(b, &n) >= 0) {} }

static size_t putStr(uint8_t *p, const char *s) { size_t n = strlen(s); p[0] = (uint8_t)n; memcpy(p + 1, s, n); return n + 1; }

static void online_reset(void) {
    freshState();
    netStop();
    detachPeer();
    onlineOp = OP_NONE; opFromList = false; opSent = false; opDelay = 0;
    statusMsg[0] = listMsg[0] = '\0';
    roomCount = 0; roomSel = roomTop = 0;
    mode = MODE_ONLINE_MENU;
    snprintf(settingName, sizeof(settingName), "Tester");
}

static void test_online_client(void) {
    section("online relay client");
    uint8_t body[1024], got[ONLINE_MAX_FRAME];
    size_t n;

    /* --- browsing: request, reply parsed, split frames, junk --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_LIST, "", true, false);
    CHECK(mode == MODE_ONLINE_BUSY && opDelay == 0, "an open connection needs no connect delay");
    updateOnlineBusy(0);
    CHECK(peerRecvFrame(got, &n) == ON_LIST && n == 0, "LIST request sent");
    uint8_t *p = body;
    *p++ = 2;
    p += putStr(p, "Arena"); p += putStr(p, "Anna"); *p++ = 3; *p++ = 8; *p++ = 0;
    p += putStr(p, "Night \x01Shift"); p += putStr(p, "Ben"); *p++ = 8; *p++ = 8; *p++ = 2;
    size_t bodyLen = (size_t)(p - body);
    /* arrives in two pieces */
    uint8_t whole[1100]; size_t wl = 0;
    whole[wl++] = (uint8_t)((1 + bodyLen) & 0xFF); whole[wl++] = (uint8_t)((1 + bodyLen) >> 8); whole[wl++] = ON_ROOMS;
    memcpy(whole + wl, body, bodyLen); wl += bodyLen;
    ssize_t w = write(peerFd, whole, 7); (void)w;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_BUSY && roomCount == 0, "half a frame changes nothing");
    w = write(peerFd, whole + 7, wl - 7); (void)w;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_LIST && roomCount == 2, "room list shown (count=%d)", roomCount);
    CHECK(strcmp(roomList[0].name, "Arena") == 0 && strcmp(roomList[0].host, "Anna") == 0 &&
          roomList[0].players == 3 && roomList[0].max == 8 && roomList[0].state == 0, "first room parsed");
    CHECK(strcmp(roomList[1].name, "Night Shift") == 0 && roomList[1].state == 2, "second room parsed + sanitised: \"%s\"", roomList[1].name);

    /* truncated room list is ignored, not half-applied */
    uint8_t bad[] = {5, 3, 'A', 'b', 'c'};
    peerSend(ON_ROOMS, bad, sizeof(bad));
    updateOnlineList(0);
    CHECK(roomCount == 2 && mode == MODE_ONLINE_LIST, "malformed ROOMS frame ignored");

    /* refresh key + cursor + joining a running / full room is refused locally */
    drain();
    updateOnlineList(KEY_Y);
    CHECK(peerRecvFrame(got, &n) == ON_LIST, "Y refreshes the list");
    updateOnlineList(KEY_DOWN);
    CHECK(roomSel == 1, "cursor down");
    updateOnlineList(KEY_A);
    CHECK(mode == MODE_ONLINE_LIST && strstr(listMsg, "already started") != NULL, "running round refused: %s", listMsg);
    roomList[1].state = 0; roomList[1].players = 8;
    updateOnlineList(KEY_A);
    CHECK(mode == MODE_ONLINE_LIST && strstr(listMsg, "full") != NULL, "full room refused: %s", listMsg);

    /* auto refresh keeps the connection alive */
    drain();
    fakeNow += ONLINE_REFRESH_MS + 1;
    updateOnlineList(0);
    CHECK(peerRecvFrame(got, &n) == ON_LIST, "list refreshes by itself");

    /* join from the list; server says no -> back in the list with the reason */
    roomSel = 0;
    updateOnlineList(KEY_A);
    CHECK(mode == MODE_ONLINE_BUSY && onlineOp == OP_JOIN, "A starts a join");
    updateOnlineBusy(0);
    int t = peerRecvFrame(got, &n);
    CHECK(t == ON_JOIN && got[0] == ONLINE_VERSION && got[1] == 5 && memcmp(got + 2, "Arena", 5) == 0, "JOIN request names the room");
    uint8_t err[64]; err[0] = 5; size_t el = 1 + putStr(err + 1, "That room is full.");
    peerSend(ON_ERROR, err, el);
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_LIST && strcmp(listMsg, "That room is full.") == 0 && sockFd >= 0,
          "refused join returns to the list: %s", listMsg);

    /* --- hosting a private room --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_CREATE, "Arena", false, false);
    updateOnlineBusy(0);
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_CREATE && got[0] == ONLINE_VERSION && got[1] == 0 && got[2] == 5 &&
          memcmp(got + 3, "Arena", 5) == 0 && got[8] == 6 && memcmp(got + 9, "Tester", 6) == 0,
          "CREATE: version, private flag, room, host name");
    uint8_t node = 1;
    peerSend(ON_CREATED, &node, 1);
    updateOnlineBusy(0);
    CHECK(mode == MODE_MP_SESSION && isHost && inSession && netKind == NET_ONLINE && roomOnline &&
          !roomPublic && strcmp(roomName, "Arena") == 0 && strcmp(players[0].name, "Tester") == 0,
          "room created, host in the lobby");

    /* host broadcasts the world through the relay */
    drain();
    sendWorld();
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_DATA && got[0] == ONLINE_BROADCAST && got[1] == PKT_WORLD && n == 1 + WORLD_PACKET_SIZE,
          "world is sent once, addressed to everyone (n=%zu)", n);

    /* a player arrives: HELLO comes through the relay from node 3; reply goes to that node */
    drain();
    uint8_t hello[1 + NET_BUF_SIZE]; size_t hl;
    makeHelloNamed(hello + 1, &hl, "Ben");
    hello[0] = 3;
    peerSend(ON_SDATA, hello, hl + 1);
    updateMultiplayer(0.016f, 0);
    CHECK(players[1].connected && players[1].node == 3 && strcmp(players[1].name, "Ben") == 0, "player 2 joined via node 3");
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_DATA && got[0] == 3 && got[1] == PKT_WELCOME && got[2] == 1, "welcome unicast to node 3");

    /* the player's move packets arrive */
    uint8_t mv[1 + 13];
    uint8_t *q = mv; *q++ = 3; wr8(&q, PKT_PLAYER); wr8(&q, 1); wr8(&q, 1); wr16(&q, encFixed(123.0f)); wr32(&q, encFixed32(50.0f)); wr32(&q, 0);
    peerSend(ON_SDATA, mv, (size_t)(q - mv));
    updateMultiplayer(0.016f, 0);
    CHECK(fabsf(players[1].tx - 123.0f) < 0.2f, "player packets relayed to the host");

    /* the server reports the player left (synthetic BYE) */
    uint8_t bye[3] = {3, PKT_BYE, 0};
    peerSend(ON_SDATA, bye, 3);
    updateMultiplayer(0.016f, 0);
    CHECK(!players[1].connected, "player dropped when the server reports a BYE");

    /* host leaves: BYE goes out, connection closed, back on the online menu */
    drain();
    updateMultiplayer(0.016f, KEY_B);
    CHECK(mode == MODE_ONLINE_MENU && sockFd < 0 && !inSession, "leaving returns to the online menu");
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_DATA && got[0] == ONLINE_BROADCAST && got[1] == PKT_BYE, "host announced its departure");
    detachPeer();

    /* --- joining as a player --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_JOIN, "Arena", false, false);
    updateOnlineBusy(0);
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_JOIN, "JOIN sent");
    node = 4;
    peerSend(ON_JOINED, &node, 1);
    updateOnlineBusy(0);
    CHECK(mode == MODE_MP_SESSION && !isHost && inSession && netKind == NET_ONLINE && roomOnline &&
          strcmp(roomName, "Arena") == 0, "joined, waiting for the host's welcome");
    drain();
    fakeNow += 1000;
    updateMultiplayer(0.016f, 0);
    t = peerRecvFrame(got, &n);
    CHECK(t == ON_DATA && got[0] == 1 && got[1] == PKT_HELLO && got[2] == PROTOCOL_VERSION &&
          memcmp(got + 3, "Tester", 6) == 0 && n == 1 + HELLO_PACKET_SIZE, "HELLO addressed to the host, carries my name");
    /* data not coming from the host is ignored */
    uint8_t welcome[4] = {7, PKT_WELCOME, 2, 0};
    peerSend(ON_SDATA, welcome, 3);
    updateMultiplayer(0.016f, 0);
    CHECK(!welcomed, "packets from other nodes are ignored by a player");
    welcome[0] = 1;
    peerSend(ON_SDATA, welcome, 3);
    updateMultiplayer(0.016f, 0);
    CHECK(welcomed && myIndex == 2, "welcome accepted from the host");
    /* the server tells us the host is gone */
    uint8_t hostBye[3] = {1, PKT_BYE, 0};
    peerSend(ON_SDATA, hostBye, 3);
    updateMultiplayer(0.016f, 0);
    CHECK(mode == MODE_ONLINE_MENU && strstr(statusMsg, "host left") != NULL && sockFd < 0 && !inSession,
          "host left -> online menu with a message: %s", statusMsg);
    detachPeer();

    /* --- errors while creating --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_CREATE, "Arena", true, false);
    updateOnlineBusy(0);
    drain();
    err[0] = 3; el = 1 + putStr(err + 1, "That room name is taken.");
    peerSend(ON_ERROR, err, el);
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && strcmp(statusMsg, "That room name is taken.") == 0 && sockFd < 0,
          "name taken -> menu + message, connection closed");
    detachPeer();

    /* --- no answer --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_LIST, "", true, false);
    updateOnlineBusy(0);
    fakeNow += ONLINE_REPLY_MS - 1;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_BUSY, "still waiting before the timeout");
    fakeNow += 5;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && strstr(statusMsg, "did not answer") != NULL, "timeout reported: %s", statusMsg);
    detachPeer();

    /* --- server drops the connection --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_LIST, "", true, false);
    updateOnlineBusy(0);
    detachPeer();
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && strstr(statusMsg, "Lost connection") != NULL, "EOF while waiting: %s", statusMsg);

    /* --- nonsense frame length closes the connection --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_LIST, "", true, false);
    updateOnlineBusy(0);
    uint8_t zero[3] = {0, 0, 0};
    w = write(peerFd, zero, 3); (void)w;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && sockFd < 0, "zero-length frame is a protocol error");
    detachPeer();
    online_reset();
    attachSocket();
    startOnlineOp(OP_LIST, "", true, false);
    updateOnlineBusy(0);
    uint8_t huge[3] = {0xFF, 0xFF, ON_ROOMS};
    w = write(peerFd, huge, 3); (void)w;
    updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && sockFd < 0, "oversized frame is a protocol error");
    detachPeer();

    /* --- B cancels --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_CREATE, "Arena", true, false);
    updateOnlineBusy(KEY_B);
    CHECK(mode == MODE_ONLINE_MENU && sockFd < 0 && onlineOp == OP_NONE, "B cancels and disconnects");
    detachPeer();

    /* --- connection lost during a match --- */
    online_reset();
    attachSocket();
    startOnlineOp(OP_CREATE, "Arena", true, false);
    updateOnlineBusy(0);
    node = 1; peerSend(ON_CREATED, &node, 1);
    updateOnlineBusy(0);
    CHECK(mode == MODE_MP_SESSION, "hosting");
    detachPeer();
    updateMultiplayer(0.016f, 0);
    CHECK(mode == MODE_ONLINE_MENU && strstr(statusMsg, "Lost connection") != NULL && !inSession,
          "dropped connection ends the session: %s", statusMsg);

    /* --- really connecting: refused port gives a clear message --- */
    online_reset();
    snprintf(settingServer, sizeof(settingServer), "127.0.0.1:1");
    startOnlineOp(OP_LIST, "", true, false);
    CHECK(opDelay == 3, "connecting draws a few frames first");
    for (int i = 0; i < 10 && mode == MODE_ONLINE_BUSY; i++) updateOnlineBusy(0);
    CHECK(mode == MODE_ONLINE_MENU && strstr(statusMsg, "Could not reach") != NULL, "refused connection: %s", statusMsg);

    /* --- menu wiring: keyboard -> request --- */
    online_reset();
    fakeKbText = "My Room"; fakeKbButton = SWKBD_BUTTON_CONFIRM;
    onlineMenuSel = 1;                                  /* HOST PRIVATE ROOM */
    updateOnlineMenu(KEY_A);
    CHECK(mode == MODE_ONLINE_BUSY && onlineOp == OP_CREATE && !onlineRoomPublic &&
          strcmp(onlineRoom, "My Room") == 0, "private host: keyboard text becomes the room name");
    CHECK(strcmp(lastRoomName, "My Room") == 0, "room name remembered");
    online_reset();
    onlineMenuSel = 0;
    updateOnlineMenu(KEY_A);
    CHECK(mode == MODE_ONLINE_BUSY && onlineOp == OP_CREATE && onlineRoomPublic, "public host");
    CHECK(strcmp(fakeKbInitial, "My Room") == 0, "keyboard starts with the last room name");
    online_reset();
    onlineMenuSel = 3;                                  /* JOIN BY ROOM NAME */
    fakeKbText = "Secret";
    updateOnlineMenu(KEY_A);
    CHECK(mode == MODE_ONLINE_BUSY && onlineOp == OP_JOIN && strcmp(onlineRoom, "Secret") == 0, "join by name");
    online_reset();
    onlineMenuSel = 3;
    fakeKbButton = SWKBD_BUTTON_LEFT;
    updateOnlineMenu(KEY_A);
    CHECK(mode == MODE_ONLINE_MENU, "cancelling the keyboard stays in the menu");
    fakeKbButton = SWKBD_BUTTON_CONFIRM;
    onlineMenuSel = 2;                                  /* BROWSE */
    updateOnlineMenu(KEY_A);
    CHECK(mode == MODE_ONLINE_BUSY && onlineOp == OP_LIST, "browse");
    online_reset();
    updateOnlineMenu(KEY_B);
    CHECK(mode == MODE_MP_MENU, "B returns to the multiplayer menu");
    snprintf(settingName, sizeof(settingName), "PLAYER");
    snprintf(settingServer, sizeof(settingServer), DEFAULT_SERVER);
}

static void test_menus(void) {
    section("menu navigation");
    mode = MODE_MENU; menuSel = 0;
    updateFrame(0.016f, KEY_DOWN); updateFrame(0.016f, KEY_DOWN);
    CHECK(menuSel == 2, "home menu has 3 entries");
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_SETTINGS, "SETTINGS opens");
    updateFrame(0.016f, KEY_B);
    CHECK(mode == MODE_MENU, "and closes");
    menuSel = 1;
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_MP_MENU, "MULTIPLAYER opens");
    mpMenuSel = 2;
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_ONLINE_MENU, "ONLINE opens");
    updateFrame(0.016f, KEY_B);
    CHECK(mode == MODE_MP_MENU, "B returns");

    /* local host asks for a room name first; cancel keeps us on the menu */
    mpMenuSel = 0;
    fakeKbButton = SWKBD_BUTTON_LEFT;
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_MP_MENU && !inSession, "cancelled keyboard does not host");
    fakeKbButton = SWKBD_BUTTON_CONFIRM; fakeKbText = "Garage LAN";
    updateFrame(0.016f, KEY_A);
    CHECK(mode == MODE_MP_SESSION && isHost && strcmp(roomName, "Garage LAN") == 0, "local host uses the typed room name");
    netStop();
    mode = MODE_MENU;
}

int main(void) {
    printf("Blockfall test-suite\n====================\n");
    test_packet_roundtrip();
    test_lobby_capacity();
    test_push();
    test_scroll();
    test_new_rules();
    test_local_coop();
    test_recycle_and_random();
    test_movement_and_collision();
    test_text_and_settings();
    test_names_in_game();
    test_local_room_names();
    test_online_client();
    test_menus();
    printf("\n%d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
