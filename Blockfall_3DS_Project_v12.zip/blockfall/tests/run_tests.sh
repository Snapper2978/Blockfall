#!/bin/sh
# Runs every PC test:
#   1. game + netcode unit tests (needs gcc)           tests/netcode_test.c
#   2. relay server tests (needs python3)              server/test_server.py
#   3. end-to-end: real server + two game clients      tests/online_e2e.c
cd "$(dirname "$0")/.." || exit 1
TMP="${TMPDIR:-/tmp}"
status=0

echo "== game and netcode tests =="
gcc -std=gnu11 -O1 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter \
    -Itests/stubs tests/netcode_test.c -o "$TMP/blockfall_tests" -lm || exit 1
"$TMP/blockfall_tests" || status=1
rm -f tests/.test_settings.cfg

echo
echo "== relay server tests =="
python3 -I server/test_server.py 2>&1 | tail -4 || status=1
python3 -I server/test_server.py >/dev/null 2>&1 || status=1

echo
echo "== end-to-end (real server, two game clients) =="
python3 tests/online_e2e.py || status=1

exit $status
