/*
 * Blockfall end-to-end client for tests/online_e2e.py.
 *
 * This is the REAL source/main.c (menus, online client, lobby, match logic,
 * drawing code) compiled against fake 3DS libraries but REAL BSD sockets, so
 * it can talk to the real server (server/blockfall_server.py).  The driver
 * script starts the server plus several copies of this program in different
 * roles:
 *
 *   host  PORT ROOM PUBLIC NAME EXPECT_PLAYERS EXPECT_NAMES HOLD_MS
 *   join  PORT ROOM PUBLIC NAME HOST_NAME
 *   late  PORT ROOM PUBLIC NAME            (tries to join a running round)
 *
 * Progress goes to stderr ("ok[...]" / "FAIL[...]" / "MARK:..."); the exit
 * status is non-zero when any check failed.
 */
#define FAKE_CLOCK_REAL 1
#define SETTINGS_PATH "tests/.e2e_settings.cfg"
#define main blockfall_main
#include "../source/main.c"
#undef main
#include "stubs/fake_platform.h"

#include <assert.h>

static const char *who = "?";
static int fails = 0;
static u32 pendingDown = 0;
static uint64_t lastT = 0;

#define EXPECT(cond, ...) do { \
        bool _c = (cond); if (!_c) fails++; \
        fprintf(stderr, "%s[%s]: ", _c ? "ok" : "FAIL", who); \
        fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } while (0)

static void mark(const char *m) { fprintf(stderr, "MARK:%s\n", m); fflush(stderr); }

/* one iteration of the game's main loop: logic + both screens */
static void frame(void) {
    uint64_t now = osGetTime();
    if (!lastT) lastT = now;
    float dt = (float)(now - lastT) / 1000.0f;
    if (dt > 0.05f) dt = 0.05f;
    lastT = now;
    u32 d = pendingDown;
    pendingDown = 0;
    updateBackdrop(dt);
    updateFrame(dt, d);
    renderTop();
    printBottom();
    usleep(6000);
}

#define WAIT(cond, ms) ({ uint64_t _end = osGetTime() + (uint64_t)(ms); bool _ok = false; \
        while (osGetTime() < _end) { frame(); if (cond) { _ok = true; break; } } _ok; })

static int findRoom(const char *name) {
    for (int i = 0; i < roomCount; i++) if (strcmp(roomList[i].name, name) == 0) return i;
    return -1;
}

static int role_host(const char *room, bool pub, int expect, const char *names, int holdMs) {
    startOnlineOp(OP_CREATE, room, pub, false);
    EXPECT(WAIT(mode == MODE_MP_SESSION, 8000), "room \"%s\" created (%s)", room, pub ? "public" : "private");
    EXPECT(isHost && roomOnline && roomPublic == pub && strcmp(roomName, room) == 0, "hosting, type recorded");
    mark("HOSTING");

    EXPECT(WAIT(countConnected() >= 1 + expect, 25000), "%d players joined", countConnected() - 1);
    for (int k = 0; k < 20; k++) frame();
    bool namesOk = true;
    for (int i = 1; i < MAX_PLAYERS; i++) {
        if (!players[i].connected) continue;
        char needle[NAME_LEN + 4];
        snprintf(needle, sizeof(needle), ",%s,", players[i].name);
        char hay[128];
        snprintf(hay, sizeof(hay), ",%s,", names);
        fprintf(stderr, "  player %d is \"%s\"\n", i + 1, players[i].name);
        if (!strstr(hay, needle)) namesOk = false;
    }
    EXPECT(namesOk, "player names are %s (duplicates numbered)", names);

    pendingDown = KEY_A;
    EXPECT(WAIT(mpState == MP_COUNTDOWN, 3000), "countdown starts");
    EXPECT(WAIT(mpState == MP_PLAYING, 6000), "round starts after the countdown");
    mark("ROUND_STARTED");
    WAIT(false, holdMs);
    EXPECT(mpState == MP_PLAYING || mpState == MP_RESULTS, "round ran (state %d, %u ms)", (int)mpState, (unsigned)mpTime);

    pendingDown = KEY_START;
    frame();
    EXPECT(mode == MODE_ONLINE_MENU && !inSession && sockFd < 0, "host left, back on the online menu");
    mark("HOST_LEFT");
    return fails ? 1 : 0;
}

static int role_join(const char *room, bool pub, const char *me, const char *hostName) {
    startOnlineOp(OP_LIST, "", true, false);
    EXPECT(WAIT(mode == MODE_ONLINE_LIST, 8000), "room list received");
    int idx = findRoom(room);
    if (pub) {
        EXPECT(idx >= 0, "public room is listed (%d rooms)", roomCount);
        if (idx < 0) return 1;
        EXPECT(strcmp(roomList[idx].host, hostName) == 0 && roomList[idx].players >= 1 &&
               roomList[idx].max == MAX_PLAYERS && roomList[idx].state == 0,
               "listing shows host %s, %u/%u players", roomList[idx].host,
               (unsigned)roomList[idx].players, (unsigned)roomList[idx].max);
        roomSel = idx;
        pendingDown = KEY_A;
    } else {
        EXPECT(idx < 0, "private room is NOT in the public list");
        pendingDown = KEY_B;
        frame();
        EXPECT(mode == MODE_ONLINE_MENU, "left the list");
        startOnlineOp(OP_JOIN, room, true, false);     /* "JOIN BY ROOM NAME" */
    }
    EXPECT(WAIT(mode == MODE_MP_SESSION && welcomed, 10000), "joined the room and was welcomed");
    EXPECT(netKind == NET_ONLINE && !isHost && strcmp(roomName, room) == 0, "room name %s", roomName);
    mark("JOINED");
    EXPECT(WAIT(players[0].name[0] != '\0' && players[myIndex].name[0] != '\0', 5000), "names received");
    EXPECT(strcmp(players[0].name, hostName) == 0, "host is shown as \"%s\"", players[0].name);
    EXPECT(strncmp(players[myIndex].name, me, strlen(me)) == 0, "I am shown as \"%s\"", players[myIndex].name);

    EXPECT(WAIT(mpState == MP_COUNTDOWN || mpState == MP_PLAYING, 30000), "countdown/round started by the host");
    EXPECT(WAIT(mpState == MP_PLAYING, 8000), "round running");
    bool sawBlocks = false;
    uint64_t end = osGetTime() + 6000;
    while (osGetTime() < end && mode == MODE_MP_SESSION) {
        frame();
        for (int i = 0; i < MAX_BLOCKS; i++) if (blocks[i].active) sawBlocks = true;
        if (sawBlocks) break;
    }
    EXPECT(sawBlocks, "falling blocks arrive from the host");
    EXPECT(mpElapsed() > 0, "round timer runs (%u ms)", (unsigned)mpElapsed());

    EXPECT(WAIT(mode == MODE_ONLINE_MENU, 40000), "returned to the online menu");
    EXPECT(strstr(statusMsg, "host left") != NULL, "told why: \"%s\"", statusMsg);
    return fails ? 1 : 0;
}

static int role_late(const char *room) {
    startOnlineOp(OP_LIST, "", true, false);
    EXPECT(WAIT(mode == MODE_ONLINE_LIST, 8000), "room list received");
    int idx = findRoom(room);
    EXPECT(idx >= 0 && roomList[idx].state != 0, "listing marks the room as in-game (state %d)",
           idx >= 0 ? roomList[idx].state : -1);
    if (idx >= 0) {
        roomSel = idx;
        pendingDown = KEY_A;
        frame();
        EXPECT(mode == MODE_ONLINE_LIST && strstr(listMsg, "already started") != NULL, "list refuses it: %s", listMsg);
    }
    pendingDown = KEY_B;
    frame();
    /* ask the server directly (JOIN BY NAME) */
    startOnlineOp(OP_JOIN, room, true, false);
    EXPECT(WAIT(mode == MODE_ONLINE_MENU, 8000) && strstr(statusMsg, "already started") != NULL,
           "server refuses a join mid-round: \"%s\"", statusMsg);
    startOnlineOp(OP_JOIN, "No Such Room", true, false);
    EXPECT(WAIT(mode == MODE_ONLINE_MENU && statusMsg[0], 8000) && strstr(statusMsg, "No room") != NULL,
           "unknown room: \"%s\"", statusMsg);
    mark("LATE_DONE");
    return fails ? 1 : 0;
}

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: role port room public name ...\n"); return 2; }
    who = argv[1];
    snprintf(settingServer, sizeof(settingServer), "127.0.0.1:%s", argv[2]);
    snprintf(settingName, sizeof(settingName), "%s", argv[5]);
    bool pub = atoi(argv[4]) != 0;
    initBackdrop();
    mode = MODE_ONLINE_MENU;
    int rc = 2;
    if (!strcmp(argv[1], "host") && argc >= 9)
        rc = role_host(argv[3], pub, atoi(argv[6]), argv[7], atoi(argv[8]));
    else if (!strcmp(argv[1], "join") && argc >= 7)
        rc = role_join(argv[3], pub, argv[5], argv[6]);
    else if (!strcmp(argv[1], "late"))
        rc = role_late(argv[3]);
    netStop();
    fprintf(stderr, "%s[%s]: finished, %d failed check(s)\n", fails ? "FAIL" : "done", who, fails);
    return rc;
}
