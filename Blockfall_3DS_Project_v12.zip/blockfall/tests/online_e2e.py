#!/usr/bin/env python3
"""
End-to-end test: real relay server + several real game clients.

Compiles tests/online_e2e.c (the actual source/main.c on fake 3DS libraries
but real sockets), starts server/blockfall_server.py on a free port, and runs
two scenarios:

  1. PUBLIC room: a host, two players with the same name (-> "Bob", "Bob2")
     who find the room in the browser, and a late player who is refused
     because the round already started.
  2. PRIVATE room: not listed, joined by typing its name.
"""
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = tempfile.mkdtemp(prefix="blockfall_e2e_")
BIN = os.path.join(TMP, "online_e2e")


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Proc:
    def __init__(self, name, args):
        self.name = name
        self.lines = []
        self.marks = set()
        self.p = subprocess.Popen([BIN] + args, cwd=ROOT, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.PIPE, text=True)
        self.t = threading.Thread(target=self._read, daemon=True)
        self.t.start()

    def _read(self):
        for line in self.p.stderr:
            line = line.rstrip()
            if line.startswith("MARK:"):
                self.marks.add(line[5:])
            else:
                self.lines.append(line)

    def wait_mark(self, mark, timeout):
        end = time.time() + timeout
        while time.time() < end:
            if mark in self.marks:
                return True
            if self.p.poll() is not None and mark not in self.marks:
                time.sleep(0.2)
                return mark in self.marks
            time.sleep(0.05)
        return False

    def finish(self, timeout):
        try:
            rc = self.p.wait(timeout)
        except subprocess.TimeoutExpired:
            self.p.kill()
            self.lines.append("FAIL[%s]: timed out" % self.name)
            rc = -1
        self.t.join(2)
        return rc

    def report(self):
        for line in self.lines:
            print("   ", line)


def run_scenario(title, port, procs_fn):
    print("\n--- %s ---" % title)
    ok = procs_fn(port)
    print("    =>", "PASS" if ok else "FAIL")
    return ok


def public_scenario(port):
    room = "E2E Arena"
    host = Proc("host", ["host", str(port), room, "1", "Alice", "2", "Bob,Bob2", "3500"])
    ok = host.wait_mark("HOSTING", 10)
    a = Proc("join-1", ["join", str(port), room, "1", "Bob", "Alice"])
    b = Proc("join-2", ["join", str(port), room, "1", "Bob", "Alice"])
    ok &= host.wait_mark("ROUND_STARTED", 40)
    late = Proc("late", ["late", str(port), room, "1", "Cara"])
    procs = [host, a, b, late]
    rcs = [p.finish(90) for p in procs]
    for p in procs:
        p.report()
    return ok and all(rc == 0 for rc in rcs)


def private_scenario(port):
    room = "Secret Den"
    host = Proc("host", ["host", str(port), room, "0", "Dora", "1", "Eve", "1500"])
    ok = host.wait_mark("HOSTING", 10)
    eve = Proc("join", ["join", str(port), room, "0", "Eve", "Dora"])
    procs = [host, eve]
    rcs = [p.finish(90) for p in procs]
    for p in procs:
        p.report()
    return ok and all(rc == 0 for rc in rcs)


def main():
    cc = subprocess.run(
        ["gcc", "-std=gnu11", "-O1", "-Wall", "-Wextra", "-Wno-unused-function",
         "-Wno-unused-parameter", "-I", os.path.join(ROOT, "tests", "stubs"),
         os.path.join(ROOT, "tests", "online_e2e.c"), "-o", BIN, "-lm"],
        capture_output=True, text=True)
    if cc.returncode != 0:
        print(cc.stdout, cc.stderr)
        return 1

    port = free_port()
    server = subprocess.Popen(
        [sys.executable, "-I", os.path.join(ROOT, "server", "blockfall_server.py"),
         "--host", "127.0.0.1", "--port", str(port)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(100):                       # wait until it accepts connections
            try:
                socket.create_connection(("127.0.0.1", port), 0.2).close()
                break
            except OSError:
                time.sleep(0.05)
        results = [
            run_scenario("public room: browse, join, duplicate names, late join refused",
                         port, public_scenario),
            run_scenario("private room: hidden from the list, joined by name",
                         port, private_scenario),
        ]
    finally:
        server.terminate()
        server.wait(5)
        for f in ("tests/.e2e_settings.cfg",):
            try:
                os.remove(os.path.join(ROOT, f))
            except OSError:
                pass
    print()
    print("end-to-end:", "all scenarios passed" if all(results) else "FAILED")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
