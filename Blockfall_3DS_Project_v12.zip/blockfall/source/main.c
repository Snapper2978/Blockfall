/*
 * BLOCKFALL: STICKMAN SURVIVAL  (Nintendo 3DS homebrew)
 *
 *  - Home screen: PLAY GAME (single player, or 2 players on one console) / MULTIPLAYER / SETTINGS
 *  - Multiplayer: up to 8 players, either over 3DS local wireless (UDS) or
 *    over the internet through the Blockfall relay server (server/).
 *    The host simulates the falling blocks and broadcasts them; every
 *    player moves their own stickman and reports their position.
 *    Last stickman standing wins the round.
 *  - Rooms have a name typed with the system keyboard.  Online rooms are
 *    public (listed in the room browser) or private (join by name).
 *  - SETTINGS holds the player name shown in multiplayer and the address of
 *    the online server.
 */
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <malloc.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#if defined(__has_include)
# if __has_include(<netinet/tcp.h>)
#  include <netinet/tcp.h>
# endif
#endif

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */
#define SCREEN_W 400
#define SCREEN_H 240
#define MAX_BLOCKS 96
#define LEADERBOARD_SIZE 5
#define PLAYER_W 18
#define PLAYER_H 34
#define FLOOR_Y 232.0f
#define GROUND_Y (FLOOR_Y - PLAYER_H)
#define GRAVITY 1000.0f
#define JUMP_VELOCITY 380.0f

#define MAX_PLAYERS 8
#define NET_CHANNEL 1
#define NET_WLANCOMM_ID 0x42464C4Cu        /* "BFLL" - identifies our game */
#define NET_PASSPHRASE "blockfall-3ds-v1"
#define NET_BUF_SIZE 1500
#define NET_SHARED_MEM 0x3000
#define NET_HOST_NODE 1                    /* host is always network node 1 */
#define NET_SEND_INTERVAL_MS 50
#define NET_TIMEOUT_MS 4000
#define NET_TIMEOUT_ONLINE_MS 8000
#define SCAN_BUF_SIZE 0x4000
#define COUNTDOWN_MS 3000
#define PROTOCOL_VERSION 4

#define NAME_LEN 12                        /* player name, characters */
#define ROOM_LEN 16                        /* room name, characters */
#define SERVER_LEN 60                      /* "host:port" */
#define DEFAULT_SERVER "blockfall.example.com:7777"   /* change in SETTINGS */
#ifndef SETTINGS_PATH                      /* (overridden by the PC tests) */
#define SETTINGS_DIR_1 "sdmc:/3ds"
#define SETTINGS_DIR_2 "sdmc:/3ds/blockfall"
#define SETTINGS_PATH "sdmc:/3ds/blockfall/settings.cfg"
#endif
#define LOCAL_ROOMS_MAX 16
#define BEACON_SIZE (2 + 1 + 1 + 1 + ROOM_LEN + NAME_LEN)   /* "BF", ver, players, state, room, host */

/* Online relay protocol (see server/blockfall_server.py) */
#define ONLINE_VERSION 1
#define ONLINE_DEFAULT_PORT 7777
#define ONLINE_BROADCAST 0xFF
#define ONLINE_MAX_FRAME 4096
#define ONLINE_RX_SIZE 8192
#define ONLINE_TX_SIZE 16384
#define ONLINE_ROOMS_MAX 40
#define ONLINE_CONNECT_MS 6000
#define ONLINE_REPLY_MS 8000
#define ONLINE_REFRESH_MS 5000
enum { ON_LIST = 0x01, ON_CREATE = 0x02, ON_JOIN = 0x03, ON_DATA = 0x04, ON_LEAVE = 0x05 };
enum { ON_ROOMS = 0x81, ON_CREATED = 0x82, ON_JOINED = 0x83, ON_ERROR = 0x84, ON_SDATA = 0x85 };

/* Endless scrolling: after a short grace period the view rises constantly.
 * Anything (stickman or block) that ends up below the bottom of the view
 * is gone - players who fall back down are out.  The rise slows if the
 * pile is lagging far behind so players can always keep up by climbing. */
#define NO_SCROLL 1.0e9f
#define SCROLL_DELAY_MS 5000     /* grace period before the view starts rising */
#define SCROLL_BASE 8.0f         /* starting rise speed, px/s */
#define SCROLL_RAMP 0.15f        /* extra px/s gained per second of rising */
#define SCROLL_MAX 40.0f         /* rise speed cap, px/s */

/* Player movement (slower than before: was 220 / 250) */
#define MOVE_SPEED 150.0f
#define CPAD_SPEED 170.0f

/* Multiplayer push */
#define PUSH_RANGE 26.0f
#define PUSH_COOLDOWN 0.7f
#define PUSH_SPEED 340.0f

/* Moves: double jump, wall jump, R = push / shove block, L = blast */
#define DOUBLE_JUMP_VELOCITY 340.0f
#define WALL_JUMP_VELOCITY 360.0f
#define WALL_JUMP_PUSH 300.0f        /* sideways kick away from the wall */
#define WALL_SLIDE_SPEED 110.0f      /* max fall speed while hugging a wall */
#define WALL_TOUCH 1.5f              /* px gap that still counts as touching */
#define PUSH_TAP_MAX 0.25f           /* R released before this = player push */
#define PUSH_BLOCK_SPEED 60.0f       /* px/s a held R shoves a block */
#define PUSH_BLOCK_MAX 28.0f         /* px of shoving per hold */
#define BLAST_RADIUS 64.0f           /* L destroys blocks this close */
#define BLAST_COOLDOWN 15.0f         /* seconds */
#define BLAST_FX_TIME 0.4f

enum { PKT_HELLO = 0, PKT_PLAYER = 1, PKT_WORLD = 2, PKT_WELCOME = 3, PKT_BYE = 4, PKT_PUSH = 5,
       PKT_BLOCKPUSH = 6, PKT_BLAST = 7 };
#define HELLO_PACKET_SIZE (1 + 1 + NAME_LEN)
#define WELCOME_BAD_VERSION 0xFE
#define WORLD_PACKET_SIZE (1 + 1 + 4 + 4 + MAX_PLAYERS * (11 + NAME_LEN) + MAX_BLOCKS * 10)

typedef enum {
    MODE_MENU, MODE_SINGLE, MODE_MP_MENU, MODE_MP_JOIN, MODE_MP_SESSION,
    MODE_SETTINGS, MODE_ONLINE_MENU, MODE_ONLINE_BUSY, MODE_ONLINE_LIST
} Mode;

typedef enum { NET_LOCAL = 0, NET_ONLINE = 1 } NetKind;
typedef enum { OP_NONE = 0, OP_LIST, OP_CREATE, OP_JOIN } OnlineOp;

typedef enum { MP_LOBBY = 0, MP_COUNTDOWN = 1, MP_PLAYING = 2, MP_RESULTS = 3 } MpState;

typedef struct {
    float x, y, w, h, speed;
    int type;
    bool active;
    bool falling;
} Block;

typedef struct {
    float phase;     /* run-cycle angle in radians */
    int facing;      /* +1 right, -1 left */
    bool moving;     /* running on the ground */
    int air;         /* 0 grounded, 1 rising, 2 falling */
    float push;      /* >0 while the shove animation plays */
} Anim;

/* One stickman's physics + ability state.  The local player is `me`; the
 * optional second local player (same console) is `p2`. */
typedef struct {
    float x, y, vy;
    bool grounded;
    Anim anim;
    float knockVX, stun, pushCd;
    bool skipJ;
    bool doubleUsed;        /* the mid-air jump has been spent */
    bool wallReady;         /* a wall jump is available */
    int wallDir;            /* -1 wall on the left, +1 on the right, 0 none */
    float pushHold;         /* how long R has been held */
    float shoveBudget;      /* px of block shoving left in this hold */
    bool tapPush;           /* intent: shove the player in front */
    int shoveDir;           /* intent: shove a block this way ... */
    float shoveDt;          /* ... for this long (0 = not shoving) */
    bool shoving;
    float shoveSend;        /* online client: shove px not yet sent */
    int shoveLock;          /* block being shoved this hold (index+1, 0 = none) */
    bool blastReq;          /* intent: blast */
    float blastCd, blastFx;
    bool alive;             /* single / local co-op only */
    uint32_t deadMs;
} Body;

typedef struct {
    float vx;               /* desired horizontal speed, px/s */
    bool jump, pushHeld, pushUp, blast;
} PadInput;

typedef struct {
    bool connected;
    bool alive;
    float blastFx;     /* remote: blast ring animation */
    Anim anim;
    bool netPush;      /* remote: currently shoving */
    bool netFaceLeft;  /* remote: facing left */
    float x, y;        /* displayed position */
    float tx, ty;      /* network target (remote players) */
    uint32_t timeMs;   /* survival time once dead / round over */
    uint64_t lastHeard;
    uint16_t node;     /* host only: UDS / relay network node id */
    char name[NAME_LEN + 1];
} NetPlayer;

typedef struct {
    char name[ROOM_LEN + 1];
    char host[NAME_LEN + 1];
    uint8_t players, max, state;
    bool known;        /* local scan: beacon carried room info */
} RoomInfo;

typedef struct {
    float x, y, w, h, speed;
    int type;
} BgBlock;

/* ------------------------------------------------------------------ */
/* Globals                                                             */
/* ------------------------------------------------------------------ */
static Mode mode = MODE_MENU;
static int menuSel = 0;
static int mpMenuSel = 0;
static int joinSel = 0;
static int joinTop = 0;
static int settingsSel = 0;
static int onlineMenuSel = 0;
static char statusMsg[96] = "";
static char joinMsg[64] = "";

/* Settings (saved on the SD card) */
static char settingName[NAME_LEN + 1] = "PLAYER";
static char settingServer[SERVER_LEN + 1] = DEFAULT_SERVER;
static char lastRoomName[ROOM_LEN + 1] = "";

static Block blocks[MAX_BLOCKS];
static BgBlock bgBlocks[16];

static Body me = { .x = 191.0f, .y = GROUND_Y, .grounded = true,
                   .anim = {0.0f, 1, false, 0, 0.0f}, .wallReady = true,
                   .shoveBudget = PUSH_BLOCK_MAX, .alive = true };
static Body p2 = { .x = 230.0f, .y = GROUND_Y, .grounded = true,
                   .anim = {0.0f, -1, false, 0, 0.0f}, .wallReady = true,
                   .shoveBudget = PUSH_BLOCK_MAX };
static bool p2Active = false;        /* a second local player has joined */
/* The local player's state under its old names. */
#define playerX me.x
#define playerY me.y
#define playerVY me.vy
#define onGround me.grounded
#define skipJump me.skipJ
#define playerAnim me.anim
#define playerKnockVX me.knockVX
#define stunT me.stun
#define pushCooldown me.pushCd
static uint32_t hostBlastReady[MAX_PLAYERS];     /* host: next allowed blast (ms) */
static float hostShoveBudget[MAX_PLAYERS];
static uint64_t hostShoveLast[MAX_PLAYERS];
static int hostShoveLock[MAX_PLAYERS];

/* Camera / scrolling (world y grows downward, floor is at FLOOR_Y) */
static float camY = 0.0f;            /* world y at the top of the view (<= 0) */
static float camFollow = 0.0f;
static float autoCamY = NO_SCROLL;   /* limit the auto-scroll has reached */
static bool scrolling = false;
static uint32_t scrollStartMs = 0;
static uint32_t spawnDelayMs = 700;
static float yOff = 0.0f;            /* applied to all world drawing */

static uint64_t gameStart = 0;
static uint64_t lastSpawn = 0;
static uint64_t lastFrame = 0;
static bool gameOver = false;
static bool scoreSaved = false;
static uint32_t finalMs = 0;
static uint32_t bestTimes[LEADERBOARD_SIZE] = {0};
static float menuClock = 0.0f;

static C3D_RenderTarget *top;
static C2D_TextBuf textBuf;

/* Multiplayer state */
static NetPlayer players[MAX_PLAYERS];
static int myIndex = 0;
static bool isHost = false;
static bool udsUp = false;
static bool inSession = false;
static NetKind netKind = NET_LOCAL;
static char roomName[ROOM_LEN + 1] = "";
static bool roomPublic = true;
static bool roomOnline = false;
static bool welcomed = false;
static MpState mpState = MP_LOBBY;
static uint32_t mpTime = 0;        /* countdown remaining / elapsed / final */
static uint64_t mpTimeRecv = 0;
static uint64_t countdownEnd = 0;
static uint64_t lastNetSend = 0;
static uint64_t lastHello = 0;
static uint64_t lastWorldRecv = 0;
static udsBindContext bindCtx;
static uint8_t netBuf[NET_BUF_SIZE];
static uint8_t sendBuf[NET_BUF_SIZE];
static char netError[96] = "";

static void *scanBuf = NULL;
static udsNetworkScanInfo *scanNets = NULL;
static size_t scanTotal = 0;
static int scanCountdown = 0;
static RoomInfo localRooms[LOCAL_ROOMS_MAX];
static int localCount = 0;
static uint8_t beaconCount = 0xFF, beaconState = 0xFF;

/* Online relay connection */
static int sockFd = -1;
static bool socUp = false, acUp = false;
static u32 *socBuf = NULL;
static uint8_t rxBuf[ONLINE_RX_SIZE];
static size_t rxLen = 0;
static uint8_t txBuf[ONLINE_TX_SIZE];
static size_t txLen = 0;
static bool onlineLost = false;
static OnlineOp onlineOp = OP_NONE;
static bool opSent = false, opFromList = false;
static int opDelay = 0;
static uint64_t opStart = 0;
static char onlineRoom[ROOM_LEN + 1] = "";
static bool onlineRoomPublic = true;
static RoomInfo roomList[ONLINE_ROOMS_MAX];
static int roomCount = 0, roomSel = 0, roomTop = 0;
static uint64_t lastListReq = 0;
static char listMsg[64] = "";

/* citro2d argument orders are easy to mix up, so wrap them once:
 *   C2D_DrawRectSolid(x, y, z, w, h, clr)
 *   C2D_DrawLine(x0, y0, clr0, x1, y1, clr1, thickness, depth)
 * All three also subtract yOff, the camera offset for world drawing.   */
static inline void rectSolid(float x, float y, float w, float h, float z, uint32_t clr) {
    C2D_DrawRectSolid(x, y - yOff, z, w, h, clr);
}
static inline void lineSolid(float x0, float y0, float z0, float x1, float y1, float z1,
                             float thickness, uint32_t clr) {
    (void)z0; (void)z1;
    C2D_DrawLine(x0, y0 - yOff, clr, x1, y1 - yOff, clr, thickness, 0.0f);
}
static inline void circleSolid(float x, float y, float r, uint32_t clr) {
    C2D_DrawCircleSolid(x, y - yOff, 0, r, clr);
}

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */
static uint32_t survivalMs(void) {
    if (!gameStart) return 0;
    return (uint32_t)(osGetTime() - gameStart);
}

static uint32_t displayMs(void) {
    return gameOver ? finalMs : survivalMs();
}

static void printTime(uint32_t ms, char *out, size_t size) {
    unsigned int totalSeconds = ms / 1000;
    unsigned int minutes = totalSeconds / 60;
    unsigned int seconds = totalSeconds % 60;
    unsigned int millis = ms % 1000;
    snprintf(out, size, "%02u:%02u.%03u", minutes, seconds, millis);
}

static uint32_t playerColor(int i) {
    switch (i & 7) {
        case 0: return C2D_Color32(245, 245, 245, 255);
        case 1: return C2D_Color32(90, 220, 255, 255);
        case 2: return C2D_Color32(255, 220, 90, 255);
        case 3: return C2D_Color32(255, 130, 200, 255);
        case 4: return C2D_Color32(130, 255, 130, 255);
        case 5: return C2D_Color32(255, 150, 80, 255);
        case 6: return C2D_Color32(190, 150, 255, 255);
        default: return C2D_Color32(150, 190, 210, 255);
    }
}

static float spawnX(int idx) { return 24.0f + (float)idx * 48.0f; }

/* Text drawing (system font via citro2d) */
static void drawText(const char *str, float x, float y, float scale,
                     uint32_t color, int align /* 0 left, 1 center, 2 right */) {
    C2D_Text t;
    float w = 0, h = 0;
    C2D_TextParse(&t, textBuf, str);
    C2D_TextOptimize(&t);
    C2D_TextGetDimensions(&t, scale, scale, &w, &h);
    if (align == 1) x -= w / 2.0f;
    else if (align == 2) x -= w;
    C2D_DrawText(&t, C2D_WithColor, x, y, 0.0f, scale, scale, color);
}

static void drawTextCentered(const char *str, float cx, float cy, float scale, uint32_t color) {
    C2D_Text t;
    float w = 0, h = 0;
    C2D_TextParse(&t, textBuf, str);
    C2D_TextOptimize(&t);
    C2D_TextGetDimensions(&t, scale, scale, &w, &h);
    C2D_DrawText(&t, C2D_WithColor, cx - w / 2.0f, cy - h / 2.0f, 0.0f, scale, scale, color);
}

static void moveSelection(int *sel, int count, u32 down) {
    if (count <= 0) return;
    if (down & KEY_DOWN) *sel = (*sel + 1) % count;
    if (down & KEY_UP) *sel = (*sel + count - 1) % count;
}

/* ------------------------------------------------------------------ */
/* Text input and settings                                             */
/* ------------------------------------------------------------------ */
/* Names travel over the network and are drawn with a fixed font, so keep
 * printable ASCII only, trimmed and cut to maxLen characters. */
static void sanitizeText(char *s, size_t maxLen) {
    size_t w = 0;
    for (size_t r = 0; s[r] && w < maxLen; r++) {
        unsigned char c = (unsigned char)s[r];
        if (c < 32 || c > 126) continue;
        if (c == ' ' && w == 0) continue;          /* no leading spaces */
        s[w++] = (char)c;
    }
    s[w] = '\0';
    while (w > 0 && s[w - 1] == ' ') s[--w] = '\0';
}

/* Bounded copy (explicit, so truncation is deliberate and warning-free). */
static void copyText(char *dst, size_t size, const char *src) {
    size_t n = strlen(src);
    if (n >= size) n = size - 1;
    memcpy(dst, src, n);
    dst[n] = '\0';
}

static bool sameText(const char *a, const char *b) {
    for (; *a && *b; a++, b++) {
        char x = *a, y = *b;
        if (x >= 'A' && x <= 'Z') x = (char)(x + 32);
        if (y >= 'A' && y <= 'Z') y = (char)(y + 32);
        if (x != y) return false;
    }
    return *a == *b;
}

/* System software keyboard.  Returns true and fills out[] (at most maxLen
 * printable ASCII characters) when the player confirmed a non-empty text. */
static bool askText(const char *hint, const char *initial, char *out, size_t maxLen) {
    SwkbdState kb;
    char buf[4 * SERVER_LEN + 16];
    memset(buf, 0, sizeof(buf));
    swkbdInit(&kb, SWKBD_TYPE_NORMAL, 2, (int)maxLen);
    swkbdSetValidation(&kb, SWKBD_NOTEMPTY_NOTBLANK, 0, 0);
    swkbdSetHintText(&kb, hint);
    if (initial && initial[0]) swkbdSetInitialText(&kb, initial);
    SwkbdButton pressed = swkbdInputText(&kb, buf, sizeof(buf));
    if (pressed != SWKBD_BUTTON_CONFIRM) return false;
    buf[sizeof(buf) - 1] = '\0';
    sanitizeText(buf, maxLen);
    if (!buf[0]) return false;
    snprintf(out, maxLen + 1, "%s", buf);
    return true;
}

static void loadSettings(void) {
    FILE *f = fopen(SETTINGS_PATH, "r");
    if (!f) return;
    char line[160];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strncmp(line, "name=", 5) == 0) {
            sanitizeText(line + 5, NAME_LEN);
            if (line[5]) copyText(settingName, sizeof(settingName), line + 5);
        } else if (strncmp(line, "server=", 7) == 0) {
            sanitizeText(line + 7, SERVER_LEN);
            if (line[7]) copyText(settingServer, sizeof(settingServer), line + 7);
        }
    }
    fclose(f);
}

static void saveSettings(void) {
#ifdef SETTINGS_DIR_1
    mkdir(SETTINGS_DIR_1, 0777);
    mkdir(SETTINGS_DIR_2, 0777);
#endif
    FILE *f = fopen(SETTINGS_PATH, "w");
    if (!f) return;
    fprintf(f, "name=%s\nserver=%s\n", settingName, settingServer);
    fclose(f);
}

/* Suggested room name for the keyboard: the last one used, else "<name>'s room". */
static void defaultRoomName(char *out) {
    char tmp[NAME_LEN + 16];
    if (lastRoomName[0]) snprintf(tmp, sizeof(tmp), "%s", lastRoomName);
    else snprintf(tmp, sizeof(tmp), "%s's room", settingName);
    sanitizeText(tmp, ROOM_LEN);
    copyText(out, ROOM_LEN + 1, tmp);
}

/* Name shown for player slot i. */
static const char *playerLabel(int i, char *tmp, size_t size) {
    if (i >= 0 && i < MAX_PLAYERS && players[i].name[0]) return players[i].name;
    snprintf(tmp, size, "P%d", i + 1);
    return tmp;
}

/* ------------------------------------------------------------------ */
/* Leaderboard (single player)                                         */
/* ------------------------------------------------------------------ */
static void loadLeaderboard(void) {
    FILE *f = fopen("sdmc:/3ds/blockfall/leaderboard.dat", "rb");
    if (f) {
        size_t got = fread(bestTimes, sizeof(uint32_t), LEADERBOARD_SIZE, f);
        (void)got;
        fclose(f);
    }
}

static void saveLeaderboard(void) {
    mkdir("sdmc:/3ds", 0777);
    mkdir("sdmc:/3ds/blockfall", 0777);
    FILE *f = fopen("sdmc:/3ds/blockfall/leaderboard.dat", "wb");
    if (f) {
        fwrite(bestTimes, sizeof(uint32_t), LEADERBOARD_SIZE, f);
        fclose(f);
    }
}

static void submitScore(uint32_t score) {
    if (scoreSaved) return;
    scoreSaved = true;
    for (int i = 0; i < LEADERBOARD_SIZE; i++) {
        if (score > bestTimes[i]) {
            for (int j = LEADERBOARD_SIZE - 1; j > i; j--)
                bestTimes[j] = bestTimes[j - 1];
            bestTimes[i] = score;
            saveLeaderboard();
            break;
        }
    }
}

/* ------------------------------------------------------------------ */
/* Core game simulation (shared by single player and multiplayer)      */
/* ------------------------------------------------------------------ */
static float rand01(void) { return (float)rand() / (float)RAND_MAX; }
static float randRange(float a, float b) { return a + (b - a) * rand01(); }

static float playerWorldY(int i) { return (i == myIndex) ? playerY : players[i].y; }

/* Single player: the highest living stickman (P1 or the second player). */
static float singleFocusY(void) {
    bool a = me.alive, b = p2Active && p2.alive;
    if (a && b) return me.y < p2.y ? me.y : p2.y;
    if (b) return p2.y;
    return me.y;
}

/* Highest point of the settled pile (NO_SCROLL if nothing has landed). */
static float pileTop(void) {
    float top = NO_SCROLL;
    for (int i = 0; i < MAX_BLOCKS; i++)
        if (blocks[i].active && !blocks[i].falling && blocks[i].y < top) top = blocks[i].y;
    return top;
}

/* Free slot, or - when the pile has used them all - recycle the lowest
 * settled block so spawning never stops. */
static int acquireBlockSlot(void) {
    for (int i = 0; i < MAX_BLOCKS; i++)
        if (!blocks[i].active) return i;
    int best = -1;
    float lowest = -1.0e9f;
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (blocks[i].active && !blocks[i].falling && blocks[i].y > lowest) {
            lowest = blocks[i].y;
            best = i;
        }
    }
    return best;
}

static void placeBlock(float x, float y, float w, float h, float speed, int color) {
    int i = acquireBlockSlot();
    if (i < 0) return;
    w = roundf(w);
    h = roundf(h);
    if (speed > 340.0f) speed = 340.0f;
    if (x < 0) x = 0;
    if (x + w > SCREEN_W) x = SCREEN_W - w;
    blocks[i].x = roundf(x);
    blocks[i].y = y;
    blocks[i].w = w;
    blocks[i].h = h;
    blocks[i].speed = speed;
    blocks[i].type = color & 7;
    blocks[i].active = true;
    blocks[i].falling = true;
}

/* World y that new blocks must spawn above: above every living player's
 * view, above the auto-scroll limit and above the top of the pile. */
static float spawnCeiling(void) {
    float ceiling = 0.0f;
    bool any = false;
    if (mode == MODE_SINGLE) {
        float t = singleFocusY() - 123.0f;
        ceiling = t < 0.0f ? t : 0.0f;
        any = true;
    } else {
        for (int i = 0; i < MAX_PLAYERS; i++) {
            if (!players[i].connected || !players[i].alive) continue;
            float t = playerWorldY(i) - 123.0f;
            if (t > 0.0f) t = 0.0f;
            if (!any || t < ceiling) ceiling = t;
            any = true;
        }
    }
    if (autoCamY < NO_SCROLL * 0.5f && autoCamY < ceiling) ceiling = autoCamY;
    float pt = pileTop();
    if (pt < NO_SCROLL && pt - 40.0f < ceiling) ceiling = pt - 40.0f;
    return ceiling - 10.0f;
}

static float aimTargetX(void) {
    if (mode == MODE_SINGLE) {
        if (p2Active && p2.alive && (!me.alive || rand() % 2)) return p2.x;
        return me.x;
    }
    int cand[MAX_PLAYERS];
    int n = 0;
    for (int i = 0; i < MAX_PLAYERS; i++)
        if (players[i].connected && players[i].alive) cand[n++] = i;
    if (n == 0) return randRange(20.0f, 380.0f);
    int i = cand[rand() % n];
    return (i == myIndex) ? playerX : players[i].x;
}

/* One random "event": a different kind of block (or group) each time. */
static void spawnWave(uint32_t elapsed) {
    float ceiling = spawnCeiling();
    float boost = ((float)elapsed / 1000.0f) * 1.8f;
    float roll = rand01();
    int color = rand() % 8;

    if (roll < 0.10f) {                      /* hail: a burst of small blocks */
        int n = 3 + rand() % 4;
        float sx = randRange(10.0f, SCREEN_W - 140.0f);
        for (int k = 0; k < n; k++) {
            float w = randRange(14.0f, 26.0f), h = randRange(14.0f, 26.0f);
            float x = sx + (float)k * randRange(18.0f, 34.0f);
            float y = ceiling - h - (float)k * randRange(12.0f, 40.0f);
            placeBlock(x, y, w, h, randRange(90.0f, 170.0f) + boost, color);
        }
    } else if (roll < 0.22f) {               /* aimed at a living player */
        float w = randRange(20.0f, 60.0f), h = randRange(16.0f, 44.0f);
        float x = aimTargetX() - w / 2.0f + randRange(-20.0f, 20.0f);
        placeBlock(x, ceiling - h - randRange(0.0f, 30.0f), w, h,
                   randRange(80.0f, 170.0f) + boost, color);
    } else if (roll < 0.30f) {               /* slow, wide slab */
        float w = randRange(90.0f, 150.0f), h = randRange(24.0f, 42.0f);
        placeBlock(randRange(0.0f, SCREEN_W - w), ceiling - h, w, h,
                   (randRange(60.0f, 100.0f) + boost) * 0.7f, color);
    } else if (roll < 0.40f) {               /* fast thin spear */
        float w = randRange(8.0f, 14.0f), h = randRange(40.0f, 76.0f);
        placeBlock(randRange(0.0f, SCREEN_W - w), ceiling - h, w, h,
                   (randRange(130.0f, 200.0f) + boost) * 1.2f, color);
    } else {                                 /* ordinary random block */
        float w = randRange(16.0f, 84.0f), h = randRange(10.0f, 58.0f);
        float sp = randRange(60.0f, 170.0f) + boost;
        if (w * h > 2800.0f) sp *= 0.8f;     /* big ones are heavier */
        placeBlock(randRange(0.0f, SCREEN_W - w), ceiling - h - randRange(0.0f, 24.0f),
                   w, h, sp, color);
    }
}

static void maybeSpawn(uint32_t elapsed, uint64_t now) {
    if (now - lastSpawn < spawnDelayMs) return;

    float base = 850.0f;
    if (elapsed > 15000) base = 650.0f;
    if (elapsed > 30000) base = 500.0f;
    if (elapsed > 60000) base = 360.0f;
    if (elapsed > 90000) base = 280.0f;

    spawnWave(elapsed);
    if (elapsed > 20000 && rand() % 100 < 28) spawnWave(elapsed);

    spawnDelayMs = (uint32_t)(base * randRange(0.35f, 1.5f)); /* irregular rhythm */
    lastSpawn = now;
}

/* Anything below the bottom of the rising view is gone. */
static void cullBlocks(void) {
    if (autoCamY >= NO_SCROLL * 0.5f) return;
    float cullY = autoCamY + SCREEN_H + 60.0f;
    for (int i = 0; i < MAX_BLOCKS; i++)
        if (blocks[i].active && blocks[i].y > cullY) blocks[i].active = false;
}

/* Constant rise after the grace period. */
static void updateScroll(float dt, uint32_t elapsed) {
    if (elapsed < SCROLL_DELAY_MS) return;
    if (!scrolling) {
        scrolling = true;
        scrollStartMs = SCROLL_DELAY_MS;
        autoCamY = 0.0f;
    }
    float secs = (float)(elapsed - scrollStartMs) / 1000.0f;
    float speed = SCROLL_BASE + SCROLL_RAMP * secs;
    if (speed > SCROLL_MAX) speed = SCROLL_MAX;

    /* Rubber band: if the pile top has fallen far below the top of the
     * view, the rise slows to a crawl so the pile can catch up. */
    float pt = pileTop();
    if (pt >= NO_SCROLL * 0.5f) pt = FLOOR_Y;
    float rel = pt - autoCamY;
    float factor = 1.0f;
    if (rel > 70.0f) {
        float t = (rel - 70.0f) / 60.0f;
        if (t > 1.0f) t = 1.0f;
        factor = 1.0f - 0.8f * t;
    }
    autoCamY -= speed * factor * dt;
}

static void updateCamera(float dt, float focusY) {
    float target = focusY + 17.0f - 140.0f;      /* keep the stickman ~60% down */
    if (target > 0.0f) target = 0.0f;
    float k = dt * 8.0f;
    if (k > 1.0f) k = 1.0f;
    camFollow += (target - camFollow) * k;
    camY = camFollow;
    if (autoCamY < camY) camY = autoCamY;        /* the rising view is a hard limit */
    if (camY > 0.0f) camY = 0.0f;
}

static void resetScrollState(void) {
    camY = 0.0f;
    camFollow = 0.0f;
    autoCamY = NO_SCROLL;
    scrolling = false;
    scrollStartMs = 0;
    spawnDelayMs = 700;
    playerKnockVX = 0.0f;
    stunT = 0.0f;
    pushCooldown = 0.0f;
    playerAnim.push = 0.0f;
    me.doubleUsed = false; me.wallReady = true; me.wallDir = 0;
    me.pushHold = 0.0f; me.shoveBudget = PUSH_BLOCK_MAX; me.shoveSend = 0.0f; me.shoveLock = 0;
    me.tapPush = false; me.shoveDt = 0.0f; me.blastReq = false;
    me.blastCd = 0.0f; me.blastFx = 0.0f;
}

/* Carried off the bottom of the rising view? */
static bool sweptAwayY(float y) {
    return autoCamY < NO_SCROLL * 0.5f && y > autoCamY + SCREEN_H - 4.0f;
}
static bool sweptAway(void) { return sweptAwayY(playerY); }

static bool overlaps(float ax, float ay, float aw, float ah,
                     float bx, float by, float bw, float bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

/* Falling blocks land on the floor or on top of settled blocks. */
static void updateBlocks(float dt) {
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (!blocks[i].active || !blocks[i].falling) continue;

        float oldBottom = blocks[i].y + blocks[i].h;
        float nextY = blocks[i].y + blocks[i].speed * dt;
        float landingY = FLOOR_Y - blocks[i].h;

        for (int j = 0; j < MAX_BLOCKS; j++) {
            if (i == j || !blocks[j].active || blocks[j].falling) continue;
            bool horizontalOverlap =
                blocks[i].x < blocks[j].x + blocks[j].w &&
                blocks[i].x + blocks[i].w > blocks[j].x;
            float platformTop = blocks[j].y;
            if (horizontalOverlap && oldBottom <= platformTop + 1.0f &&
                nextY + blocks[i].h >= platformTop &&
                platformTop - blocks[i].h < landingY) {
                landingY = platformTop - blocks[i].h;
            }
        }

        if (nextY >= landingY) {
            blocks[i].y = landingY;
            blocks[i].falling = false;
        } else {
            blocks[i].y = nextY;
        }
    }
}

/* ---- input ---- */
static void padRead1(PadInput *in) {
    u32 held = hidKeysHeld(), pressed = hidKeysDown(), up = hidKeysUp();
    float vx = 0.0f;
    if (held & KEY_LEFT) vx -= MOVE_SPEED;
    if (held & KEY_RIGHT) vx += MOVE_SPEED;
    circlePosition c;
    hidCircleRead(&c);
    if (abs(c.dx) > 30) vx += ((float)c.dx / 156.0f) * CPAD_SPEED;
    in->vx = vx;
    in->jump = (pressed & (KEY_A | KEY_B | KEY_UP)) != 0;
    in->pushHeld = (held & KEY_R) != 0;
    in->pushUp = (up & KEY_R) != 0;
    in->blast = (pressed & KEY_L) != 0;
}

/* Second local player: C-stick moves, ZL jumps, ZR pushes, SELECT blasts.
 * (New 3DS inputs; in Azahar map a second controller onto them.) */
static void padRead2(PadInput *in) {
    u32 held = hidKeysHeld(), pressed = hidKeysDown(), up = hidKeysUp();
    float vx = 0.0f;
    circlePosition c;
    hidCstickRead(&c);
    if (abs(c.dx) > 30) vx = ((float)c.dx / 156.0f) * CPAD_SPEED;
    else if (held & KEY_CSTICK_LEFT) vx = -MOVE_SPEED;
    else if (held & KEY_CSTICK_RIGHT) vx = MOVE_SPEED;
    in->vx = vx;
    in->jump = (pressed & KEY_ZL) != 0;
    in->pushHeld = (held & KEY_ZR) != 0;
    in->pushUp = (up & KEY_ZR) != 0;
    in->blast = (pressed & KEY_SELECT) != 0;
}

static bool p2JoinPressed(void) {
    return (hidKeysDown() & (KEY_ZL | KEY_ZR | KEY_SELECT)) != 0;
}

/* Movement, jumping, gravity and ability input for one stickman. Things
 * that need the rest of the world (shoving, blasting) are left as intents
 * in the body for the caller to carry out. */
static void bodyUpdate(Body *b, const PadInput *in, float dt) {
    b->tapPush = false;
    b->shoveDt = 0.0f;
    b->blastReq = false;
    if (b->grounded) { b->doubleUsed = false; b->wallReady = true; }

    if (b->stun > 0.0f) b->stun -= dt;
    if (b->pushCd > 0.0f) b->pushCd -= dt;
    if (b->anim.push > 0.0f) b->anim.push -= dt;
    if (b->blastCd > 0.0f) { b->blastCd -= dt; if (b->blastCd < 0.0f) b->blastCd = 0.0f; }
    if (b->blastFx > 0.0f) b->blastFx -= dt;
    bool control = b->stun <= 0.0f;

    if (control) {
        b->x += in->vx * dt;
        if (in->vx < -1.0f) b->anim.facing = -1;
        else if (in->vx > 1.0f) b->anim.facing = 1;
    }

    /* Knockback from being shoved decays quickly. */
    if (b->knockVX != 0.0f) {
        b->x += b->knockVX * dt;
        float decay = 1.0f - 7.0f * dt;
        if (decay < 0.0f) decay = 0.0f;
        b->knockVX *= decay;
        if (fabsf(b->knockVX) < 8.0f) b->knockVX = 0.0f;
    }

    if (b->x < 2) b->x = 2;
    if (b->x > SCREEN_W - PLAYER_W - 2) b->x = SCREEN_W - PLAYER_W - 2;

    /* R: a quick tap shoves the player in front; holding shoves a block. */
    if (in->pushHeld) {
        if (control) {
            b->pushHold += dt;
            if (b->pushHold >= PUSH_TAP_MAX && b->shoveBudget > 0.0f) {
                b->shoving = true;
                b->shoveDir = b->anim.facing < 0 ? -1 : 1;
                b->shoveDt = dt;
                if (b->anim.push < 0.1f) b->anim.push = 0.1f;
            }
        }
    } else {
        if (in->pushUp && b->pushHold > 0.0f && b->pushHold < PUSH_TAP_MAX &&
            control && b->pushCd <= 0.0f)
            b->tapPush = true;
        b->pushHold = 0.0f;
        b->shoveBudget = PUSH_BLOCK_MAX;
        b->shoving = false;
        b->shoveLock = 0;
    }

    /* L: blast the blocks around the stickman (long cooldown). */
    if (control && in->blast && b->blastCd <= 0.0f) {
        b->blastReq = true;
        b->blastCd = BLAST_COOLDOWN;
        b->blastFx = BLAST_FX_TIME;
    }

    /* Jump: ground jump, else wall jump (once), else one double jump. */
    if (control && !b->skipJ && in->jump) {
        if (b->grounded) {
            b->vy = -JUMP_VELOCITY;
            b->grounded = false;
        } else if (b->wallDir != 0 && b->wallReady) {
            b->vy = -WALL_JUMP_VELOCITY;
            b->knockVX = -(float)b->wallDir * WALL_JUMP_PUSH;
            b->anim.facing = -b->wallDir;
            b->wallReady = false;
            b->wallDir = 0;
        } else if (!b->doubleUsed) {
            b->vy = -DOUBLE_JUMP_VELOCITY;
            b->doubleUsed = true;
        }
    }
    b->skipJ = false;

    /* Gravity (slower slide while pushing into a wall), then land on the
     * floor or on top of settled blocks. */
    float oldBottom = b->y + PLAYER_H;
    b->vy += GRAVITY * dt;
    if (b->wallDir != 0 && b->wallReady && b->vy > WALL_SLIDE_SPEED &&
        in->vx * (float)b->wallDir > 0.0f)
        b->vy = WALL_SLIDE_SPEED;
    b->y += b->vy * dt;
    b->grounded = false;
    if (b->y >= GROUND_Y) {
        b->y = GROUND_Y;
        b->vy = 0.0f;
        b->grounded = true;
    }
    if (b->vy >= 0.0f) {
        for (int j = 0; j < MAX_BLOCKS; j++) {
            if (!blocks[j].active || blocks[j].falling) continue;
            bool hOverlap = b->x < blocks[j].x + blocks[j].w &&
                            b->x + PLAYER_W > blocks[j].x;
            float topY = blocks[j].y;
            if (hOverlap && oldBottom <= topY + 4.0f &&
                b->y + PLAYER_H >= topY && topY - PLAYER_H <= b->y) {
                b->y = topY - PLAYER_H;
                b->vy = 0.0f;
                b->grounded = true;
            }
        }
    }
}

/* Local player (the one on this console's buttons). */
static void updatePlayer(float dt) {
    PadInput in;
    padRead1(&in);
    bodyUpdate(&me, &in, dt);
}

/* Work out the run/jump animation state from how far the stickman moved. */
static void animUpdate(Anim *a, float dx, float dy, float dt) {
    if (dt <= 0.0f) return;
    if (fabsf(dx) > 30.0f || fabsf(dy) > 60.0f) { dx = 0; dy = 0; } /* teleport/snap */
    float vx = dx / dt;
    float vy = dy / dt;
    a->moving = fabsf(vx) > 15.0f;
    if (a->moving) {
        a->facing = vx > 0 ? 1 : -1;
        a->phase += fabsf(dx) * 0.1f;
        if (a->phase > 6.2831853f * 100.0f) a->phase -= 6.2831853f * 100.0f;
    }
    a->air = fabsf(vy) > 40.0f ? (vy < 0 ? 1 : 2) : 0;
}

/* Returns true if the stickman is killed.
 *  - Only the BOTTOM of a falling block is deadly: if it comes down on the
 *    stickman's head the stickman dies.  Touching a falling block's side or
 *    top is harmless: the side is a wall (and a fresh surface for a wall
 *    jump), the top is a floor.
 *  - SETTLED blocks are solid but harmless: the sides act as walls, the tops
 *    are floors.  Being squashed under a block while on the ground is deadly.
 *  - Pinned between a falling block and a wall / another block is deadly. */
static bool bodyResolve(Body *b) {
    b->wallDir = 0;
    for (int pass = 0; pass < 3; pass++) {
        bool moved = false;
        for (int i = 0; i < MAX_BLOCKS; i++) {
            if (!blocks[i].active) continue;
            bool falling = blocks[i].falling;
            float bx = blocks[i].x, by = blocks[i].y, bw = blocks[i].w, bh = blocks[i].h;
            if (!overlaps(b->x, b->y, PLAYER_W, PLAYER_H, bx, by, bw, bh)) continue;

            /* Push out along the axis with the least penetration. */
            float feetPen  = (b->y + PLAYER_H) - by;
            float headPen  = (by + bh) - b->y;
            float leftPen  = (b->x + PLAYER_W) - bx;
            float rightPen = (bx + bw) - b->x;
            float minPen = feetPen;
            int dir = 0;
            if (headPen  < minPen) { minPen = headPen;  dir = 1; }
            if (leftPen  < minPen) { minPen = leftPen;  dir = 2; }
            if (rightPen < minPen) { minPen = rightPen; dir = 3; }

            switch (dir) {
            case 0: /* land on top */
                b->y = by - PLAYER_H;
                if (b->vy > 0.0f) b->vy = 0.0f;
                b->grounded = true;
                break;
            case 1: /* block above us */
                if (falling) return true;       /* its bottom hit our head */
                if (b->grounded) return true;   /* squashed */
                b->y = by + bh;
                if (b->vy < 0.0f) b->vy = 0.0f; /* harmless head bump */
                break;
            case 2: b->x = bx - PLAYER_W; break; /* wall on our right */
            default: b->x = bx + bw; break;      /* wall on our left */
            }
            moved = true;
        }
        if (!moved) break;
    }

    if (b->x < 2) b->x = 2;
    if (b->x > SCREEN_W - PLAYER_W - 2) b->x = SCREEN_W - PLAYER_W - 2;

    /* Still inside a falling block after being pushed out: squeezed. */
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (!blocks[i].active || !blocks[i].falling) continue;
        if (overlaps(b->x + 1.0f, b->y + 1.0f, PLAYER_W - 2.0f, PLAYER_H - 2.0f,
                     blocks[i].x, blocks[i].y, blocks[i].w, blocks[i].h))
            return true;
    }

    /* Which wall are we touching?  (screen edges and block sides) */
    if (b->x <= 2.0f + WALL_TOUCH) b->wallDir = -1;
    else if (b->x >= SCREEN_W - PLAYER_W - 2.0f - WALL_TOUCH) b->wallDir = 1;
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (!blocks[i].active) continue;
        float by = blocks[i].y, bh = blocks[i].h;
        if (!(by < b->y + PLAYER_H - 2.0f && by + bh > b->y + 2.0f)) continue;
        int side = 0;
        if (fabsf(blocks[i].x - (b->x + PLAYER_W)) <= WALL_TOUCH) side = 1;
        else if (fabsf((blocks[i].x + blocks[i].w) - b->x) <= WALL_TOUCH) side = -1;
        if (!side) continue;
        b->wallDir = side;
        /* a block that has not landed yet is a fresh surface: reset */
        if (blocks[i].falling) b->wallReady = true;
    }
    return false;
}

static bool resolvePlayerVsBlocks(void) { return bodyResolve(&me); }

/* ---- abilities that change the world ---- */

/* Shove the settled block touching a stickman at (px,py) sideways by up to
 * `amount` px. Returns how far it moved. The first call of a hold picks the
 * touching block and remembers it in *lock, so the block keeps sliding even
 * though the shover stays put. Stops at walls and other blocks. */
static float shoveBlockAt(float px, float py, int dir, float amount, int *lock) {
    if (amount <= 0.0f) return 0.0f;
    int best = -1;
    if (*lock > 0) {
        int k = *lock - 1;
        if (blocks[k].active && !blocks[k].falling &&
            blocks[k].y < py + PLAYER_H - 2.0f && blocks[k].y + blocks[k].h > py + 2.0f) {
            float gap = dir > 0 ? blocks[k].x - (px + PLAYER_W) : px - (blocks[k].x + blocks[k].w);
            if (gap > -WALL_TOUCH) best = k;
        }
        if (best < 0) *lock = 0;
    }
    if (best < 0) {
        float bestGap = 1.0e9f;
        for (int i = 0; i < MAX_BLOCKS; i++) {
            if (!blocks[i].active || blocks[i].falling) continue;
            if (!(blocks[i].y < py + PLAYER_H - 2.0f && blocks[i].y + blocks[i].h > py + 2.0f)) continue;
            float gap = dir > 0 ? blocks[i].x - (px + PLAYER_W) : px - (blocks[i].x + blocks[i].w);
            if (gap > -WALL_TOUCH && gap < 4.0f && gap < bestGap) { best = i; bestGap = gap; }
        }
        if (best < 0) return 0.0f;
        *lock = best + 1;
    }
    Block *bl = &blocks[best];
    float room = dir > 0 ? (SCREEN_W - 3.0f) - (bl->x + bl->w) : bl->x - 3.0f;
    for (int j = 0; j < MAX_BLOCKS; j++) {
        if (j == best || !blocks[j].active || blocks[j].falling) continue;
        if (!(blocks[j].y < bl->y + bl->h && blocks[j].y + blocks[j].h > bl->y)) continue;
        float g = dir > 0 ? blocks[j].x - (bl->x + bl->w) : bl->x - (blocks[j].x + blocks[j].w);
        if (g >= -0.5f && g < room) room = g;
    }
    if (room < 0.0f) room = 0.0f;
    float mv = amount < room ? amount : room;
    bl->x += (float)dir * mv;
    return mv;
}

/* Destroy every block (landed or falling) close to a stickman at (px,py). */
static int blastBlocks(float px, float py) {
    float cx = px + PLAYER_W / 2.0f, cy = py + PLAYER_H / 2.0f;
    int n = 0;
    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (!blocks[i].active) continue;
        float dx = 0.0f, dy = 0.0f;
        if (cx < blocks[i].x) dx = blocks[i].x - cx;
        else if (cx > blocks[i].x + blocks[i].w) dx = cx - (blocks[i].x + blocks[i].w);
        if (cy < blocks[i].y) dy = blocks[i].y - cy;
        else if (cy > blocks[i].y + blocks[i].h) dy = cy - (blocks[i].y + blocks[i].h);
        if (dx * dx + dy * dy <= BLAST_RADIUS * BLAST_RADIUS) {
            blocks[i].active = false;
            blocks[i].falling = false;
            n++;
        }
    }
    return n;
}

static void bodyKnock(Body *t, int dir) {
    t->knockVX = (dir < 0 ? -1.0f : 1.0f) * PUSH_SPEED;
    t->stun = 0.25f;
    if (t->grounded) {
        t->vy = -150.0f;
        t->grounded = false;
    }
}

/* ------------------------------------------------------------------ */
/* Single player                                                       */
/* ------------------------------------------------------------------ */
static void bodyResetAt(Body *b, float x) {
    b->x = x;
    b->y = GROUND_Y;
    b->vy = 0.0f;
    b->grounded = true;
    b->anim.phase = 0.0f; b->anim.moving = false; b->anim.air = 0; b->anim.push = 0.0f;
    b->knockVX = 0.0f; b->stun = 0.0f; b->pushCd = 0.0f; b->skipJ = false;
    b->doubleUsed = false; b->wallReady = true; b->wallDir = 0;
    b->pushHold = 0.0f; b->shoveBudget = PUSH_BLOCK_MAX; b->shoving = false; b->shoveSend = 0.0f;
    b->shoveLock = 0;
    b->tapPush = false; b->shoveDt = 0.0f; b->blastReq = false;
    b->blastCd = 0.0f; b->blastFx = 0.0f;
    b->alive = true;
    b->deadMs = 0;
}

static void resetGame(void) {
    memset(blocks, 0, sizeof(blocks));
    bodyResetAt(&me, 191.0f);
    me.anim.facing = 1;
    bodyResetAt(&p2, 230.0f);
    p2.anim.facing = -1;
    p2Active = false;
    resetScrollState();
    gameOver = false;
    scoreSaved = false;
    finalMs = 0;
    gameStart = osGetTime();
    lastSpawn = gameStart;
    lastFrame = gameStart;
}

/* The second player joins mid-game next to the first one. */
static void p2Join(void) {
    if (p2Active) return;
    bodyResetAt(&p2, me.alive ? (me.x < SCREEN_W / 2.0f ? me.x + 28.0f : me.x - 28.0f) : 230.0f);
    if (me.alive) p2.y = me.y;
    p2.vy = 0.0f;
    p2.grounded = false;
    p2.anim.facing = -1;
    p2.skipJ = true;           /* the joining press must not also jump */
    p2Active = true;
}

/* Carry out one local stickman's world intents in single / co-op play. */
static void localIntents(Body *b, Body *other, bool otherIn) {
    if (b->tapPush) {
        b->tapPush = false;
        b->pushCd = PUSH_COOLDOWN;
        b->anim.push = 0.22f;
        if (otherIn && other->alive) {
            int dir = b->anim.facing < 0 ? -1 : 1;
            float reachX = dir > 0 ? b->x + PLAYER_W : b->x - PUSH_RANGE;
            if (overlaps(reachX, b->y, PUSH_RANGE, PLAYER_H, other->x, other->y, PLAYER_W, PLAYER_H))
                bodyKnock(other, dir);
        }
    }
    if (b->shoveDt > 0.0f) {
        float mv = shoveBlockAt(b->x, b->y, b->shoveDir, PUSH_BLOCK_SPEED * b->shoveDt, &b->shoveLock);
        b->shoveBudget -= mv;
    }
    if (b->blastReq) {
        b->blastReq = false;
        blastBlocks(b->x, b->y);
    }
}

static void updateSingle(float dt) {
    if (gameOver) return;
    uint32_t elapsed = survivalMs();
    PadInput in1, in2;
    padRead1(&in1);
    padRead2(&in2);
    if (!p2Active && p2JoinPressed()) {
        p2Join();
        memset(&in2, 0, sizeof(in2));     /* the joining press does nothing else */
    }

    float ox = me.x, oy = me.y, ox2 = p2.x, oy2 = p2.y;
    if (me.alive) bodyUpdate(&me, &in1, dt);
    if (p2Active && p2.alive) bodyUpdate(&p2, &in2, dt);
    if (me.alive) localIntents(&me, &p2, p2Active);
    if (p2Active && p2.alive) localIntents(&p2, &me, true);

    maybeSpawn(elapsed, osGetTime());
    updateBlocks(dt);
    updateScroll(dt, elapsed);

    if (me.alive) {
        bool dead = bodyResolve(&me) || sweptAwayY(me.y);
        animUpdate(&me.anim, me.x - ox, me.y - oy, dt);
        if (dead) { me.alive = false; me.deadMs = elapsed; }
    }
    if (p2Active && p2.alive) {
        bool dead = bodyResolve(&p2) || sweptAwayY(p2.y);
        animUpdate(&p2.anim, p2.x - ox2, p2.y - oy2, dt);
        if (dead) { p2.alive = false; p2.deadMs = elapsed; }
    }
    cullBlocks();
    updateCamera(dt, singleFocusY());
    if (!me.alive && !(p2Active && p2.alive)) {
        gameOver = true;
        finalMs = survivalMs();
        submitScore(finalMs);
    }
}

/* ------------------------------------------------------------------ */
/* Packet (de)serialisation                                            */
/* ------------------------------------------------------------------ */
static void wr8(uint8_t **p, uint8_t v) { *(*p)++ = v; }
static void wr16(uint8_t **p, uint16_t v) {
    wr8(p, (uint8_t)(v & 0xFF));
    wr8(p, (uint8_t)(v >> 8));
}
static void wr32(uint8_t **p, uint32_t v) {
    wr16(p, (uint16_t)(v & 0xFFFF));
    wr16(p, (uint16_t)(v >> 16));
}
static uint8_t rd8(const uint8_t **p) { return *(*p)++; }
static uint16_t rd16(const uint8_t **p) {
    uint16_t lo = rd8(p);
    uint16_t hi = rd8(p);
    return (uint16_t)(lo | (hi << 8));
}
static uint32_t rd32(const uint8_t **p) {
    uint32_t lo = rd16(p);
    uint32_t hi = rd16(p);
    return lo | (hi << 16);
}
static uint16_t encFixed(float v) {
    int iv = (int)lroundf(v * 8.0f);
    if (iv > 32000) iv = 32000;
    if (iv < -32000) iv = -32000;
    return (uint16_t)(int16_t)iv;
}
static float decFixed(uint16_t v) { return (float)(int16_t)v / 8.0f; }
/* 32-bit variant for world y, which can grow large as the view scrolls. */
static uint32_t encFixed32(float v) {
    double d = (double)v * 8.0;
    if (d > 2.0e9) d = 2.0e9;
    if (d < -2.0e9) d = -2.0e9;
    return (uint32_t)(int32_t)lround(d);
}
static float decFixed32(uint32_t v) { return (float)(int32_t)v / 8.0f; }

/* Fixed-size, NUL-padded text fields. */
static void wrText(uint8_t **p, const char *s, size_t width) {
    size_t n = strlen(s);
    for (size_t k = 0; k < width; k++) wr8(p, k < n ? (uint8_t)s[k] : 0);
}
static void rdText(const uint8_t **p, char *out, size_t width) {
    for (size_t k = 0; k < width; k++) out[k] = (char)rd8(p);
    out[width] = '\0';
    sanitizeText(out, width);
}

/* ------------------------------------------------------------------ */
/* Multiplayer networking                                              */
/* ------------------------------------------------------------------ */
static void freeScan(void) {
    if (scanBuf) free(scanBuf);
    scanBuf = NULL;
    scanNets = NULL;
    scanTotal = 0;
    localCount = 0;
}

/* ---- online relay connection (TCP to the Blockfall server) ---- */
static void socRelease(void) {
    if (socUp) { socExit(); socUp = false; }
    if (socBuf) { free(socBuf); socBuf = NULL; }
    if (acUp) { acExit(); acUp = false; }
}

static void onlineDisconnect(void) {
    if (sockFd >= 0) {
        close(sockFd);
        sockFd = -1;
    }
    rxLen = 0;
    txLen = 0;
}

static void onlineFlush(void) {
    while (txLen > 0 && sockFd >= 0) {
        ssize_t r = send(sockFd, txBuf, txLen, 0);
        if (r > 0) {
            memmove(txBuf, txBuf + r, txLen - (size_t)r);
            txLen -= (size_t)r;
        } else {
            if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
            onlineLost = true;       /* reset / broken pipe */
            break;
        }
    }
}

static void onlineSendFrame(uint8_t type, const uint8_t *body, size_t n) {
    if (sockFd < 0) return;
    size_t len = 1 + n;
    if (len > ONLINE_MAX_FRAME || txLen + 2 + len > sizeof(txBuf)) return; /* backlog: drop */
    txBuf[txLen++] = (uint8_t)(len & 0xFF);
    txBuf[txLen++] = (uint8_t)(len >> 8);
    txBuf[txLen++] = type;
    if (n) memcpy(txBuf + txLen, body, n);
    txLen += n;
    onlineFlush();
}

static void onlineSendData(uint16_t dst, const uint8_t *buf, size_t n) {
    static uint8_t tmp[NET_BUF_SIZE + 2];
    if (n > NET_BUF_SIZE) return;
    tmp[0] = dst == UDS_BROADCAST_NETWORKNODEID ? ONLINE_BROADCAST : (uint8_t)dst;
    memcpy(tmp + 1, buf, n);
    onlineSendFrame(ON_DATA, tmp, n + 1);
}

/* "host" or "host:port" -> host / port strings */
static void splitServer(char *host, size_t hostSize, char *port, size_t portSize) {
    const char *colon = strrchr(settingServer, ':');
    if (colon) {
        size_t n = (size_t)(colon - settingServer);
        if (n >= hostSize) n = hostSize - 1;
        memcpy(host, settingServer, n);
        host[n] = '\0';
        if (colon[1]) snprintf(port, portSize, "%s", colon + 1);
        else snprintf(port, portSize, "%d", ONLINE_DEFAULT_PORT);
    } else {
        snprintf(host, hostSize, "%s", settingServer);
        snprintf(port, portSize, "%d", ONLINE_DEFAULT_PORT);
    }
}

/* Blocking (up to ONLINE_CONNECT_MS): Wi-Fi check, DNS, TCP connect. */
static bool onlineConnect(void) {
    onlineDisconnect();
    onlineLost = false;
    if (!acUp && R_SUCCEEDED(acInit())) acUp = true;
    if (acUp) {
        u32 st = 0;
        if (R_SUCCEEDED(ACU_GetWifiStatus(&st)) && st == 0) {
            snprintf(netError, sizeof(netError), "Wi-Fi is off or not connected.");
            return false;
        }
    }
    if (!socUp) {
        socBuf = (u32 *)memalign(0x1000, 0x100000);
        if (socBuf && R_SUCCEEDED(socInit(socBuf, 0x100000))) {
            socUp = true;
        } else {
            free(socBuf);
            socBuf = NULL;
            snprintf(netError, sizeof(netError), "Network services unavailable.");
            return false;
        }
    }

    char host[SERVER_LEN + 1], port[16];
    splitServer(host, sizeof(host), port, sizeof(port));
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo *res = NULL;
    if (getaddrinfo(host, port, &hints, &res) != 0 || !res) {
        snprintf(netError, sizeof(netError), "Cannot find server \"%.40s\".", host);
        return false;
    }
    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd < 0) {
        freeaddrinfo(res);
        snprintf(netError, sizeof(netError), "Could not open a socket.");
        return false;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
    bool ok = false;
    int c = connect(fd, res->ai_addr, res->ai_addrlen);
    if (c == 0) {
        ok = true;
    } else if (errno == EINPROGRESS) {
        struct pollfd pfd;
        pfd.fd = fd;
        pfd.events = POLLOUT;
        pfd.revents = 0;
        if (poll(&pfd, 1, ONLINE_CONNECT_MS) > 0 && (pfd.revents & POLLOUT)) {
            int err = 0;
            socklen_t len = sizeof(err);
            getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len);
            ok = (err == 0);
        }
    }
    freeaddrinfo(res);
    if (!ok) {
        close(fd);
        snprintf(netError, sizeof(netError), "Could not reach the server.");
        return false;
    }
#ifdef TCP_NODELAY
    int one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one)); /* best effort */
#endif
    sockFd = fd;
    return true;
}

static void netSend(uint16_t dst, const uint8_t *buf, size_t n) {
    if (netKind == NET_ONLINE) onlineSendData(dst, buf, n);
    else udsSendTo(dst, NET_CHANNEL, UDS_SENDFLAG_Default, buf, n);
}

static void sendBye(void) {
    if (!inSession) return;
    uint8_t *p = sendBuf;
    wr8(&p, PKT_BYE);
    wr8(&p, (uint8_t)(myIndex < 0 ? 0 : myIndex));
    size_t n = (size_t)(p - sendBuf);
    uint16_t dst = isHost ? UDS_BROADCAST_NETWORKNODEID : NET_HOST_NODE;
    netSend(dst, sendBuf, n);
    netSend(dst, sendBuf, n);
}

/* Tear everything down (safe to call at any time). */
static void netStop(void) {
    onlineDisconnect();
    socRelease();
    if (inSession && netKind == NET_LOCAL) {
        udsUnbind(&bindCtx);
        if (isHost) udsDestroyNetwork();
        else udsDisconnectNetwork();
    }
    inSession = false;
    if (udsUp) {
        udsExit();
        udsUp = false;
    }
    freeScan();
}

static bool netBegin(void) {
    netKind = NET_LOCAL;
    Result ret = udsInit(NET_SHARED_MEM, NULL);
    if (R_FAILED(ret)) {
        snprintf(netError, sizeof(netError),
                 "Wireless init failed (0x%08lX). Is Wi-Fi on?", (unsigned long)ret);
        return false;
    }
    udsUp = true;
    return true;
}

static void leaveSession(const char *msg) {
    sendBye();
    netStop();
    snprintf(statusMsg, sizeof(statusMsg), "%s", msg);
    mode = roomOnline ? MODE_ONLINE_MENU : MODE_MP_MENU;
}

static void clearMatchState(void) {
    memset(blocks, 0, sizeof(blocks));
    playerX = spawnX(myIndex < 0 ? 0 : myIndex);
    playerY = GROUND_Y;
    playerVY = 0.0f;
    onGround = true;
    resetScrollState();
}

static void enterHostSession(void) {
    memset(players, 0, sizeof(players));
    players[0].connected = true;
    players[0].alive = true;
    snprintf(players[0].name, sizeof(players[0].name), "%s", settingName);
    myIndex = 0;
    isHost = true;
    welcomed = true;
    mpState = MP_LOBBY;
    mpTime = 0;
    lastNetSend = 0;
    clearMatchState();
    mode = MODE_MP_SESSION;
}

static void enterClientSession(void) {
    memset(players, 0, sizeof(players));
    myIndex = -1;
    isHost = false;
    welcomed = false;
    mpState = MP_LOBBY;
    mpTime = 0;
    lastNetSend = 0;
    lastHello = 0;
    lastWorldRecv = osGetTime();
    memset(blocks, 0, sizeof(blocks));
    mode = MODE_MP_SESSION;
}

static uint32_t netTimeoutMs(void) {
    return netKind == NET_ONLINE ? NET_TIMEOUT_ONLINE_MS : NET_TIMEOUT_MS;
}

static int countConnected(void);

/* Local wireless: the beacon (visible in scans before joining) carries the
 * room name, host name, player count and whether a round is running. */
static void updateBeacon(bool force) {
    if (!isHost || netKind != NET_LOCAL || !inSession) return;
    uint8_t count = (uint8_t)countConnected();
    uint8_t state = mpState == MP_LOBBY ? 0 : 1;
    if (!force && count == beaconCount && state == beaconState) return;
    uint8_t data[BEACON_SIZE];
    uint8_t *p = data;
    wr8(&p, 'B');
    wr8(&p, 'F');
    wr8(&p, PROTOCOL_VERSION);
    wr8(&p, count);
    wr8(&p, state);
    wrText(&p, roomName, ROOM_LEN);
    wrText(&p, players[0].name, NAME_LEN);
    udsSetApplicationData(data, (size_t)(p - data));
    beaconCount = count;
    beaconState = state;
}

static bool hostStart(const char *name) {
    if (!netBegin()) return false;
    udsNetworkStruct ns;
    udsGenerateDefaultNetworkStruct(&ns, NET_WLANCOMM_ID, 0, MAX_PLAYERS);
    Result ret = udsCreateNetwork(&ns, NET_PASSPHRASE, sizeof(NET_PASSPHRASE),
                                  &bindCtx, NET_CHANNEL, UDS_DEFAULT_RECVBUFSIZE);
    if (R_FAILED(ret)) {
        snprintf(netError, sizeof(netError),
                 "Could not create game (0x%08lX).", (unsigned long)ret);
        netStop();
        return false;
    }
    inSession = true;
    snprintf(roomName, sizeof(roomName), "%s", name);
    roomPublic = true;
    roomOnline = false;
    enterHostSession();
    beaconCount = beaconState = 0xFF;
    updateBeacon(true);
    return true;
}

/* Read the room info out of each scanned beacon. */
static void parseScan(void) {
    localCount = scanTotal > LOCAL_ROOMS_MAX ? LOCAL_ROOMS_MAX : (int)scanTotal;
    for (int i = 0; i < localCount; i++) {
        RoomInfo *r = &localRooms[i];
        memset(r, 0, sizeof(*r));
        uint8_t ad[0xC8];
        size_t got = 0;
        if (R_FAILED(udsGetNetworkStructApplicationData(&scanNets[i].network, ad, sizeof(ad), &got)))
            continue;
        if (got < BEACON_SIZE || ad[0] != 'B' || ad[1] != 'F' || ad[2] != PROTOCOL_VERSION)
            continue;
        const uint8_t *p = ad + 3;
        r->players = rd8(&p);
        r->state = rd8(&p);
        rdText(&p, r->name, ROOM_LEN);
        rdText(&p, r->host, NAME_LEN);
        r->max = MAX_PLAYERS;
        r->known = r->name[0] != '\0';
    }
}

static void joinScan(void) {
    freeScan();
    scanBuf = malloc(SCAN_BUF_SIZE);
    if (!scanBuf) return;
    Result ret = udsScanBeacons(scanBuf, SCAN_BUF_SIZE, &scanNets, &scanTotal,
                                NET_WLANCOMM_ID, 0, NULL, false);
    if (R_FAILED(ret)) {
        scanTotal = 0;
        scanNets = NULL;
    }
    parseScan();
    if (joinSel >= localCount) joinSel = 0;
    joinTop = 0;
}

static bool joinConnect(int idx) {
    if (!scanNets || idx < 0 || idx >= localCount) return false;
    Result ret = udsConnectNetwork(&scanNets[idx].network, NET_PASSPHRASE,
                                   sizeof(NET_PASSPHRASE), &bindCtx,
                                   UDS_BROADCAST_NETWORKNODEID, UDSCONTYPE_Client,
                                   NET_CHANNEL, UDS_DEFAULT_RECVBUFSIZE);
    if (R_FAILED(ret)) {
        snprintf(netError, sizeof(netError),
                 "Could not join game (0x%08lX).", (unsigned long)ret);
        return false;
    }
    inSession = true;
    snprintf(roomName, sizeof(roomName), "%s", localRooms[idx].known ? localRooms[idx].name : "");
    roomPublic = true;
    roomOnline = false;
    freeScan();
    enterClientSession();
    return true;
}

static uint32_t mpElapsed(void) {
    if (!isHost && mpState == MP_PLAYING)
        return mpTime + (uint32_t)(osGetTime() - mpTimeRecv);
    return mpTime;
}

static int countAlive(void) {
    int n = 0;
    for (int i = 0; i < MAX_PLAYERS; i++)
        if (players[i].connected && players[i].alive) n++;
    return n;
}

static int countConnected(void) {
    int n = 0;
    for (int i = 0; i < MAX_PLAYERS; i++)
        if (players[i].connected) n++;
    return n;
}

static int rankOrder[MAX_PLAYERS];
static int rankCount = 0;

static void computeRanking(void) {
    rankCount = 0;
    for (int i = 0; i < MAX_PLAYERS; i++)
        if (players[i].connected) rankOrder[rankCount++] = i;
    for (int a = 1; a < rankCount; a++) {
        int v = rankOrder[a];
        int b = a - 1;
        while (b >= 0) {
            NetPlayer *pb = &players[rankOrder[b]];
            NetPlayer *pv = &players[v];
            bool vBetter = (pv->alive && !pb->alive) ||
                           (pv->alive == pb->alive && pv->timeMs > pb->timeMs);
            if (!vBetter) break;
            rankOrder[b + 1] = rankOrder[b];
            b--;
        }
        rankOrder[b + 1] = v;
    }
}

/* ---- host: broadcast the full world ---- */
static size_t encodeWorld(uint8_t *out) {
    uint8_t *p = out;
    wr8(&p, PKT_WORLD);
    wr8(&p, (uint8_t)mpState);
    wr32(&p, mpTime);
    wr32(&p, scrolling ? encFixed32(autoCamY) : 0x7FFFFFFFu);
    for (int i = 0; i < MAX_PLAYERS; i++) {
        bool push, faceLeft, blast;
        if (i == 0) { /* the host's own stickman */
            push = playerAnim.push > 0.0f;
            faceLeft = playerAnim.facing < 0;
            blast = me.blastFx > 0.0f;
        } else {
            push = players[i].netPush;
            faceLeft = players[i].netFaceLeft;
            blast = players[i].blastFx > 0.0f;
        }
        uint8_t flags = (uint8_t)((players[i].connected ? 1 : 0) | (players[i].alive ? 2 : 0) |
                                  (push ? 4 : 0) | (faceLeft ? 8 : 0) | (blast ? 16 : 0));
        wr8(&p, flags);
        wr16(&p, encFixed(players[i].x));
        wr32(&p, encFixed32(players[i].y));
        wr32(&p, players[i].timeMs);
        wrText(&p, players[i].connected ? players[i].name : "", NAME_LEN);
    }
    for (int i = 0; i < MAX_BLOCKS; i++) {
        const Block *b = &blocks[i];
        uint8_t flags = (uint8_t)((b->active ? 1 : 0) | (b->falling ? 2 : 0) |
                                  ((b->type & 7) << 4));
        wr8(&p, flags);
        wr16(&p, encFixed(b->x));
        wr32(&p, encFixed32(b->y));
        wr8(&p, (uint8_t)b->w);
        wr8(&p, (uint8_t)b->h);
        int sp = (int)(b->speed / 2.0f);
        if (sp > 255) sp = 255;
        if (sp < 0) sp = 0;
        wr8(&p, (uint8_t)sp);
    }
    return (size_t)(p - out);
}

static void sendWorld(void) {
    size_t n = encodeWorld(sendBuf);
    netSend(UDS_BROADCAST_NETWORKNODEID, sendBuf, n);
}

/* ---- client: apply a world snapshot ---- */
static void applyWorld(const uint8_t *buf, size_t n, uint64_t now) {
    if (n < WORLD_PACKET_SIZE) return;
    const uint8_t *p = buf + 1; /* skip type */
    MpState prev = mpState;
    uint8_t st = rd8(&p);
    if (st > MP_RESULTS) return;
    mpState = (MpState)st;
    mpTime = rd32(&p);
    mpTimeRecv = now;
    lastWorldRecv = now;
    uint32_t autoRaw = rd32(&p);

    for (int i = 0; i < MAX_PLAYERS; i++) {
        uint8_t flags = rd8(&p);
        float x = decFixed(rd16(&p));
        float y = decFixed32(rd32(&p));
        uint32_t t = rd32(&p);
        rdText(&p, players[i].name, NAME_LEN);
        bool conn = (flags & 1) != 0;
        bool alive = (flags & 2) != 0;
        if (i == myIndex) {
            players[i].connected = conn;
            if (mpState == MP_RESULTS) {
                players[i].alive = alive;
                players[i].timeMs = t;
            }
        } else {
            if (conn && !players[i].connected) { players[i].x = x; players[i].y = y; }
            players[i].connected = conn;
            players[i].alive = alive;
            players[i].netPush = (flags & 4) != 0;
            players[i].netFaceLeft = (flags & 8) != 0;
            if ((flags & 16) && players[i].blastFx <= 0.0f) players[i].blastFx = BLAST_FX_TIME;
            players[i].tx = x;
            players[i].ty = y;
            players[i].timeMs = t;
        }
    }

    if ((mpState == MP_COUNTDOWN && prev != MP_COUNTDOWN) ||
        (mpState == MP_LOBBY && prev != MP_LOBBY)) {
        clearMatchState();
        if (myIndex >= 0) {
            players[myIndex].alive = true;
            players[myIndex].timeMs = 0;
        }
    }

    /* The host decides how far the view has risen. */
    if (autoRaw == 0x7FFFFFFFu) {
        autoCamY = NO_SCROLL;
        scrolling = false;
    } else {
        autoCamY = decFixed32(autoRaw);
        scrolling = true;
    }

    for (int i = 0; i < MAX_BLOCKS; i++) {
        uint8_t flags = rd8(&p);
        float x = decFixed(rd16(&p));
        float y = decFixed32(rd32(&p));
        uint8_t w = rd8(&p);
        uint8_t h = rd8(&p);
        uint8_t sp = rd8(&p);
        blocks[i].active = (flags & 1) != 0;
        blocks[i].falling = (flags & 2) != 0;
        blocks[i].type = (flags >> 4) & 7;
        blocks[i].x = x;
        blocks[i].y = y;
        blocks[i].w = (float)w;
        blocks[i].h = (float)h;
        blocks[i].speed = (float)sp * 2.0f;
    }
}

/* ---- push ---- */

/* We were shoved: fly sideways, hop, and lose control briefly. */
static void applyPush(int dir) {
    if (mpState != MP_PLAYING || myIndex < 0 || !players[myIndex].alive) return;
    bodyKnock(&me, dir);
}

static void sendPushPacket(int from, int to, int dir) {
    uint8_t *p = sendBuf;
    wr8(&p, PKT_PUSH);
    wr8(&p, (uint8_t)from);
    wr8(&p, (uint8_t)to);
    wr8(&p, (uint8_t)(int8_t)dir);
    size_t n = (size_t)(p - sendBuf);
    if (isHost) {
        if (to > 0 && to < MAX_PLAYERS && players[to].connected)
            netSend(players[to].node, sendBuf, n);
    } else {
        netSend(NET_HOST_NODE, sendBuf, n); /* the host relays it */
    }
}

static void sendBlockPush(int dir, float amount) {
    int a = (int)(amount * 8.0f + 0.5f);
    if (a < 1) return;
    if (a > 255) a = 255;
    uint8_t *p = sendBuf;
    wr8(&p, PKT_BLOCKPUSH);
    wr8(&p, (uint8_t)myIndex);
    wr8(&p, (uint8_t)(int8_t)dir);
    wr8(&p, (uint8_t)a);
    netSend(NET_HOST_NODE, sendBuf, (size_t)(p - sendBuf));
}

/* Carry out what the local stickman asked for this frame (multiplayer):
 *   R tap  -> shove the player in front        (network packet to the victim)
 *   R hold -> shove a block a little           (host moves it; clients ask)
 *   L      -> blast nearby blocks              (host does it; clients ask)  */
static void mpIntents(void) {
    if (me.tapPush) {
        me.tapPush = false;
        int dir = me.anim.facing < 0 ? -1 : 1;
        me.pushCd = PUSH_COOLDOWN;
        me.anim.push = 0.22f;
        float reachX = dir > 0 ? me.x + PLAYER_W : me.x - PUSH_RANGE;
        for (int i = 0; i < MAX_PLAYERS; i++) {
            if (i == myIndex || !players[i].connected || !players[i].alive) continue;
            if (overlaps(reachX, me.y, PUSH_RANGE, PLAYER_H,
                         players[i].x, players[i].y, PLAYER_W, PLAYER_H))
                sendPushPacket(myIndex, i, dir);
        }
    }
    if (me.shoveDt > 0.0f) {
        float want = PUSH_BLOCK_SPEED * me.shoveDt;
        if (isHost) {
            me.shoveBudget -= shoveBlockAt(me.x, me.y, me.shoveDir, want, &me.shoveLock);
        } else {
            me.shoveBudget -= want;
            me.shoveSend += want;
            if (me.shoveSend >= 3.0f) { sendBlockPush(me.shoveDir, me.shoveSend); me.shoveSend = 0.0f; }
        }
    } else if (me.shoveSend > 0.0f) {
        if (!isHost) sendBlockPush(me.shoveDir, me.shoveSend);
        me.shoveSend = 0.0f;
    }
    if (me.blastReq) {
        me.blastReq = false;
        if (isHost) {
            blastBlocks(me.x, me.y);
        } else {
            uint8_t *p = sendBuf;
            wr8(&p, PKT_BLAST);
            wr8(&p, (uint8_t)myIndex);
            netSend(NET_HOST_NODE, sendBuf, (size_t)(p - sendBuf));
        }
    }
}

/* Give player i the requested name; if somebody else already has it, add a
 * number ("ANNA" -> "ANNA2") so scoreboards stay readable. */
static void uniquePlayerName(int i, const char *want) {
    char name[NAME_LEN + 1];
    snprintf(name, sizeof(name), "%s", want[0] ? want : "PLAYER");
    for (int attempt = 2; attempt < 10 + MAX_PLAYERS; attempt++) {
        bool taken = false;
        for (int k = 0; k < MAX_PLAYERS; k++)
            if (k != i && players[k].connected && sameText(players[k].name, name)) taken = true;
        if (!taken) break;
        char suffix[8];
        snprintf(suffix, sizeof(suffix), "%d", attempt);
        size_t keep = NAME_LEN - strlen(suffix);
        snprintf(name, sizeof(name), "%.*s%s", (int)keep, want[0] ? want : "PLAYER", suffix);
    }
    snprintf(players[i].name, sizeof(players[i].name), "%s", name);
}

static void handleHostPacket(const uint8_t *buf, size_t n, uint16_t src, uint64_t now) {
    if (n < 1) return;
    const uint8_t *p = buf + 1;
    switch (buf[0]) {
    case PKT_HELLO: {
        uint8_t version = (n >= 2) ? rd8(&p) : 0;
        int idx = -1;
        for (int i = 1; i < MAX_PLAYERS; i++)
            if (players[i].connected && players[i].node == src) idx = i;
        if (idx < 0 && mpState == MP_LOBBY && version == PROTOCOL_VERSION &&
            n >= HELLO_PACKET_SIZE) {
            char name[NAME_LEN + 1];
            rdText(&p, name, NAME_LEN);
            for (int i = 1; i < MAX_PLAYERS; i++) {
                if (!players[i].connected) {
                    memset(&players[i], 0, sizeof(players[i]));
                    players[i].connected = true;
                    players[i].alive = true;
                    players[i].node = src;
                    players[i].x = players[i].tx = spawnX(i);
                    players[i].y = players[i].ty = GROUND_Y;
                    players[i].anim.facing = 1;
                    uniquePlayerName(i, name);
                    idx = i;
                    break;
                }
            }
        }
        if (idx >= 0) players[idx].lastHeard = now;
        uint8_t *q = sendBuf;
        wr8(&q, PKT_WELCOME);
        wr8(&q, (uint8_t)(idx >= 0 ? idx : (version != PROTOCOL_VERSION ? WELCOME_BAD_VERSION : 0xFF)));
        netSend(src, sendBuf, (size_t)(q - sendBuf));
        break;
    }
    case PKT_PLAYER: {
        if (n < 13) return;
        int idx = rd8(&p);
        uint8_t flags = rd8(&p);
        float x = decFixed(rd16(&p));
        float y = decFixed32(rd32(&p));
        uint32_t t = rd32(&p);
        if (idx < 1 || idx >= MAX_PLAYERS) return;
        if (!players[idx].connected || players[idx].node != src) return;
        players[idx].lastHeard = now;
        players[idx].tx = x;
        players[idx].ty = y;
        players[idx].netPush = (flags & 2) != 0;
        players[idx].netFaceLeft = (flags & 4) != 0;
        if (mpState == MP_PLAYING && players[idx].alive && !(flags & 1)) {
            uint32_t elapsed = (uint32_t)(now - gameStart);
            players[idx].alive = false;
            players[idx].timeMs = t < elapsed ? t : elapsed;
        }
        break;
    }
    case PKT_PUSH: {
        if (n < 4 || mpState != MP_PLAYING) return;
        int from = rd8(&p);
        int to = rd8(&p);
        int dir = (int8_t)rd8(&p);
        if (from < 1 || from >= MAX_PLAYERS) return;
        if (!players[from].connected || players[from].node != src || !players[from].alive) return;
        if (to < 0 || to >= MAX_PLAYERS || to == from) return;
        if (!players[to].connected || !players[to].alive) return;
        if (to == 0) applyPush(dir);          /* the host was shoved */
        else sendPushPacket(from, to, dir);   /* relay to the victim */
        break;
    }
    case PKT_BLOCKPUSH: {
        if (n < 4 || mpState != MP_PLAYING) return;
        int idx = rd8(&p);
        int dir = (int8_t)rd8(&p) < 0 ? -1 : 1;
        float amt = (float)rd8(&p) / 8.0f;
        if (idx < 1 || idx >= MAX_PLAYERS) return;
        if (!players[idx].connected || !players[idx].alive || players[idx].node != src) return;
        if (now - hostShoveLast[idx] > 400) { hostShoveBudget[idx] = PUSH_BLOCK_MAX; hostShoveLock[idx] = 0; }
        hostShoveLast[idx] = now;
        if (amt > hostShoveBudget[idx]) amt = hostShoveBudget[idx];
        hostShoveBudget[idx] -= shoveBlockAt(players[idx].x, players[idx].y, dir, amt, &hostShoveLock[idx]);
        break;
    }
    case PKT_BLAST: {
        if (n < 2 || mpState != MP_PLAYING) return;
        int idx = rd8(&p);
        if (idx < 1 || idx >= MAX_PLAYERS) return;
        if (!players[idx].connected || !players[idx].alive || players[idx].node != src) return;
        if (now < hostBlastReady[idx]) return;          /* still cooling down */
        hostBlastReady[idx] = (uint32_t)now + (uint32_t)(BLAST_COOLDOWN * 1000.0f) - 1000u;
        blastBlocks(players[idx].x, players[idx].y);
        players[idx].blastFx = BLAST_FX_TIME;
        break;
    }
    case PKT_BYE: {
        for (int i = 1; i < MAX_PLAYERS; i++) {
            if (players[i].connected && players[i].node == src) {
                if (mpState == MP_PLAYING && players[i].alive) {
                    players[i].alive = false;
                    players[i].timeMs = (uint32_t)(now - gameStart);
                }
                if (mpState == MP_LOBBY || mpState == MP_COUNTDOWN) players[i].connected = false;
                else players[i].lastHeard = 0; /* times out of the ranking */
            }
        }
        break;
    }
    default: break;
    }
}

static void handleClientPacket(const uint8_t *buf, size_t n, uint64_t now) {
    if (n < 1) return;
    const uint8_t *p = buf + 1;
    switch (buf[0]) {
    case PKT_WELCOME: {
        if (n < 2) return;
        uint8_t idx = rd8(&p);
        if (idx == WELCOME_BAD_VERSION) {
            leaveSession("Host runs a different Blockfall version.");
            return;
        }
        if (idx >= MAX_PLAYERS) {
            leaveSession("Game is full or already started.");
            return;
        }
        myIndex = idx;
        welcomed = true;
        lastWorldRecv = now;
        players[myIndex].connected = true;
        players[myIndex].alive = true;
        clearMatchState();
        break;
    }
    case PKT_WORLD:
        applyWorld(buf, n, now);
        break;
    case PKT_PUSH: {
        if (n < 4) return;
        (void)rd8(&p); /* from */
        (void)rd8(&p); /* to */
        int dir = (int8_t)rd8(&p);
        applyPush(dir);
        break;
    }
    case PKT_BYE:
        leaveSession("The host left the game.");
        break;
    default: break;
    }
}

/* ---- online: frames from the relay server ---- */
static void onlineFail(const char *msg);
static void onlineHandleRooms(const uint8_t *b, size_t n);
static void enterOnlineSession(bool host);

typedef struct { const uint8_t *p, *end; bool bad; } Cursor;
static uint8_t curU8(Cursor *c) {
    if (c->p >= c->end) { c->bad = true; return 0; }
    return *c->p++;
}
static void curStr(Cursor *c, char *out, size_t maxLen) {
    size_t n = curU8(c);
    if ((size_t)(c->end - c->p) < n) { c->bad = true; out[0] = '\0'; return; }
    size_t take = n < maxLen ? n : maxLen;
    memcpy(out, c->p, take);
    out[take] = '\0';
    c->p += n;
    sanitizeText(out, maxLen);
}

static void onlineHandleRooms(const uint8_t *b, size_t n) {
    Cursor c = { b, b + n, false };
    int count = curU8(&c);
    RoomInfo tmp[ONLINE_ROOMS_MAX];
    int got = 0;
    for (int i = 0; i < count && !c.bad; i++) {
        RoomInfo r;
        memset(&r, 0, sizeof(r));
        curStr(&c, r.name, ROOM_LEN);
        curStr(&c, r.host, NAME_LEN);
        r.players = curU8(&c);
        r.max = curU8(&c);
        r.state = curU8(&c);
        r.known = true;
        if (!c.bad && got < ONLINE_ROOMS_MAX && r.name[0]) tmp[got++] = r;
    }
    if (c.bad) return;
    char keep[ROOM_LEN + 1] = "";
    if (roomSel >= 0 && roomSel < roomCount) snprintf(keep, sizeof(keep), "%s", roomList[roomSel].name);
    memcpy(roomList, tmp, sizeof(RoomInfo) * (size_t)got);
    roomCount = got;
    roomSel = 0;
    for (int i = 0; i < roomCount; i++)
        if (keep[0] && sameText(roomList[i].name, keep)) roomSel = i;
    if (roomTop > roomSel) roomTop = roomSel;
    if (roomSel >= roomTop + 4) roomTop = roomSel - 3;
    if (onlineOp == OP_LIST && mode == MODE_ONLINE_BUSY) {
        onlineOp = OP_NONE;
        mode = MODE_ONLINE_LIST;
        listMsg[0] = '\0';
    }
}

static void onlineHandleFrame(uint8_t type, const uint8_t *b, size_t n, uint64_t now) {
    switch (type) {
    case ON_ROOMS:
        onlineHandleRooms(b, n);
        break;
    case ON_CREATED:
        if (onlineOp == OP_CREATE) { onlineOp = OP_NONE; enterOnlineSession(true); }
        break;
    case ON_JOINED:
        if (onlineOp == OP_JOIN) { onlineOp = OP_NONE; enterOnlineSession(false); }
        break;
    case ON_ERROR: {
        Cursor c = { b, b + n, false };
        (void)curU8(&c); /* code */
        char msg[64];
        curStr(&c, msg, sizeof(msg) - 1);
        onlineFail(msg[0] ? msg : "The server refused the request.");
        break;
    }
    case ON_SDATA:
        if (n < 2 || !inSession || netKind != NET_ONLINE) break;
        if (isHost) handleHostPacket(b + 1, n - 1, b[0], now);
        else if (b[0] == NET_HOST_NODE) handleClientPacket(b + 1, n - 1, now);
        break;
    default: break;
    }
}

/* Read whatever the server sent and act on every complete frame. */
static void onlinePump(uint64_t now) {
    if (sockFd < 0) return;
    onlineFlush();
    bool eof = false;
    for (int guard = 0; guard < 16 && sockFd >= 0; guard++) {
        size_t room = sizeof(rxBuf) - rxLen;
        if (room == 0) break;
        ssize_t r = recv(sockFd, rxBuf + rxLen, room, 0);
        if (r > 0) {
            rxLen += (size_t)r;
            if ((size_t)r < room) break;
        } else {
            if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) break;
            eof = true;
            break;
        }
    }
    size_t pos = 0;
    while (sockFd >= 0 && rxLen - pos >= 3) {
        size_t len = (size_t)rxBuf[pos] | ((size_t)rxBuf[pos + 1] << 8);
        if (len < 1 || len > ONLINE_MAX_FRAME) { eof = true; break; }
        if (rxLen - pos < 2 + len) break;
        /* copy: handlers may tear the connection (and rxBuf) down */
        static uint8_t frame[ONLINE_MAX_FRAME];
        memcpy(frame, rxBuf + pos + 2, len);
        pos += 2 + len;
        onlineHandleFrame(frame[0], frame + 1, len - 1, now);
    }
    if (sockFd < 0) return;               /* a handler closed the connection */
    if (pos) {
        memmove(rxBuf, rxBuf + pos, rxLen - pos);
        rxLen -= pos;
    }
    if (eof || rxLen == sizeof(rxBuf)) onlineLost = true;
    if (onlineLost) onlineDisconnect();
}

static void netPoll(uint64_t now) {
    if (netKind == NET_ONLINE) {
        onlinePump(now);
        return;
    }
    for (int k = 0; k < 48 && inSession; k++) {
        size_t actual = 0;
        u16 src = 0;
        Result ret = udsPullPacket(&bindCtx, netBuf, sizeof(netBuf), &actual, &src);
        if (R_FAILED(ret) || actual == 0) break;
        if (isHost) handleHostPacket(netBuf, actual, src, now);
        else handleClientPacket(netBuf, actual, now);
    }
}

static void interpolateRemotes(float dt) {
    float k = dt * 15.0f;
    if (k > 1.0f) k = 1.0f;
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (i == myIndex || !players[i].connected) continue;
        float ox = players[i].x, oy = players[i].y;
        players[i].x += (players[i].tx - players[i].x) * k;
        players[i].y += (players[i].ty - players[i].y) * k;
        animUpdate(&players[i].anim, players[i].x - ox, players[i].y - oy, dt);
        players[i].anim.facing = players[i].netFaceLeft ? -1 : 1;
        players[i].anim.push = players[i].netPush ? 0.2f : 0.0f;
        if (players[i].blastFx > 0.0f) players[i].blastFx -= dt;
    }
}

static void hostStartCountdown(uint64_t now) {
    mpState = MP_COUNTDOWN;
    countdownEnd = now + COUNTDOWN_MS;
    srand((unsigned int)now);
    memset(blocks, 0, sizeof(blocks));
    resetScrollState();
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (!players[i].connected) continue;
        players[i].alive = true;
        players[i].timeMs = 0;
        players[i].lastHeard = now;
        players[i].netPush = false;
        players[i].x = players[i].tx = spawnX(i);
        players[i].y = players[i].ty = GROUND_Y;
    }
    playerX = spawnX(0);
    playerY = GROUND_Y;
    playerVY = 0.0f;
    onGround = true;
    memset(hostBlastReady, 0, sizeof(hostBlastReady));
    memset(hostShoveLast, 0, sizeof(hostShoveLast));
    memset(hostShoveLock, 0, sizeof(hostShoveLock));
    for (int i = 0; i < MAX_PLAYERS; i++) { players[i].blastFx = 0.0f; hostShoveBudget[i] = PUSH_BLOCK_MAX; }
    mpTime = COUNTDOWN_MS;
    lastNetSend = 0;
}

static void hostEndRound(uint32_t elapsed) {
    mpState = MP_RESULTS;
    mpTime = elapsed;
    for (int i = 0; i < MAX_PLAYERS; i++)
        if (players[i].connected && players[i].alive) players[i].timeMs = elapsed;
    lastNetSend = 0;
}

static void hostBackToLobby(void) {
    mpState = MP_LOBBY;
    mpTime = 0;
    memset(blocks, 0, sizeof(blocks));
    resetScrollState();
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (!players[i].connected) continue;
        players[i].alive = true;
        players[i].timeMs = 0;
    }
    playerX = spawnX(0);
    playerY = GROUND_Y;
    playerVY = 0.0f;
    onGround = true;
    lastNetSend = 0;
}

/* Camera target while spectating: follow the highest survivor. */
static float spectateFocus(void) {
    float best = playerY;
    bool any = false;
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (i == myIndex || !players[i].connected || !players[i].alive) continue;
        if (!any || players[i].y < best) { best = players[i].y; any = true; }
    }
    return best;
}

static void updateMultiplayer(float dt, u32 down) {
    uint64_t now = osGetTime();

    if (down & KEY_START || (down & KEY_B && (mpState == MP_LOBBY || mpState == MP_RESULTS))) {
        leaveSession("");
        return;
    }

    netPoll(now);
    if (!inSession) return;
    if (netKind == NET_ONLINE && sockFd < 0) {
        leaveSession("Lost connection to the server.");
        return;
    }

    if (isHost) {
        updateBeacon(false);
        players[0].x = playerX;
        players[0].y = playerY;

        /* Drop players who stopped talking to us. */
        for (int i = 1; i < MAX_PLAYERS; i++) {
            if (players[i].connected && now - players[i].lastHeard > netTimeoutMs()) {
                if (mpState == MP_PLAYING && players[i].alive) {
                    players[i].alive = false;
                    players[i].timeMs = (uint32_t)(now - gameStart);
                }
                if (mpState == MP_LOBBY || mpState == MP_COUNTDOWN) players[i].connected = false;
                else if (players[i].alive) players[i].alive = false;
            }
        }

        switch (mpState) {
        case MP_LOBBY:
            if ((down & KEY_A) && countConnected() >= 2) hostStartCountdown(now);
            break;
        case MP_COUNTDOWN:
            if (now >= countdownEnd) {
                mpState = MP_PLAYING;
                gameStart = now;
                lastSpawn = now;
                mpTime = 0;
                lastNetSend = 0;
            } else {
                mpTime = (uint32_t)(countdownEnd - now);
            }
            break;
        case MP_PLAYING: {
            uint32_t elapsed = (uint32_t)(now - gameStart);
            mpTime = elapsed;
            maybeSpawn(elapsed, now);
            updateBlocks(dt);
            updateScroll(dt, elapsed);
            if (players[0].alive) {
                float ox = playerX, oy = playerY;
                updatePlayer(dt);
                bool dead = resolvePlayerVsBlocks() || sweptAway();
                animUpdate(&playerAnim, playerX - ox, playerY - oy, dt);
                mpIntents();
                if (dead) {
                    players[0].alive = false;
                    players[0].timeMs = elapsed;
                }
            }
            cullBlocks();
            updateCamera(dt, players[0].alive ? playerY : spectateFocus());
            if (countAlive() <= 1) hostEndRound(elapsed);
            break;
        }
        case MP_RESULTS:
            if (down & KEY_A) hostBackToLobby();
            break;
        }

        interpolateRemotes(dt);
        if (now - lastNetSend >= NET_SEND_INTERVAL_MS) {
            sendWorld();
            lastNetSend = now;
        }
    } else {
        if (now - lastWorldRecv > netTimeoutMs()) {
            leaveSession("Lost connection to the host.");
            return;
        }
        if (!welcomed) {
            if (now - lastHello >= 400) {
                uint8_t *p = sendBuf;
                wr8(&p, PKT_HELLO);
                wr8(&p, PROTOCOL_VERSION);
                wrText(&p, settingName, NAME_LEN);
                netSend(NET_HOST_NODE, sendBuf, (size_t)(p - sendBuf));
                lastHello = now;
            }
            return;
        }

        if (mpState == MP_PLAYING) {
            updateBlocks(dt); /* predict between snapshots */
            if (players[myIndex].alive) {
                float ox = playerX, oy = playerY;
                updatePlayer(dt);
                bool dead = resolvePlayerVsBlocks() || sweptAway();
                animUpdate(&playerAnim, playerX - ox, playerY - oy, dt);
                mpIntents();
                if (dead) {
                    players[myIndex].alive = false;
                    players[myIndex].timeMs = mpElapsed();
                    lastNetSend = 0; /* report death immediately */
                }
            }
            updateCamera(dt, players[myIndex].alive ? playerY : spectateFocus());
        }
        players[myIndex].x = playerX;
        players[myIndex].y = playerY;

        uint32_t interval = (mpState == MP_PLAYING) ? 33 : 100;
        if (now - lastNetSend >= interval) {
            uint8_t *p = sendBuf;
            wr8(&p, PKT_PLAYER);
            wr8(&p, (uint8_t)myIndex);
            wr8(&p, (uint8_t)((players[myIndex].alive ? 1 : 0) |
                              (playerAnim.push > 0.0f ? 2 : 0) |
                              (playerAnim.facing < 0 ? 4 : 0)));
            wr16(&p, encFixed(playerX));
            wr32(&p, encFixed32(playerY));
            wr32(&p, players[myIndex].timeMs);
            netSend(NET_HOST_NODE, sendBuf, (size_t)(p - sendBuf));
            lastNetSend = now;
        }
        interpolateRemotes(dt);
    }
}

/* ------------------------------------------------------------------ */
/* Online rooms: connect, create, browse, join                         */
/* ------------------------------------------------------------------ */
static void wrStr(uint8_t **p, const char *s) {
    size_t n = strlen(s);
    if (n > 255) n = 255;
    wr8(p, (uint8_t)n);
    for (size_t k = 0; k < n; k++) wr8(p, (uint8_t)s[k]);
}

static void enterOnlineSession(bool host) {
    netKind = NET_ONLINE;
    inSession = true;
    roomOnline = true;
    roomPublic = onlineRoomPublic;
    snprintf(roomName, sizeof(roomName), "%s", onlineRoom);
    if (host) enterHostSession();
    else enterClientSession();
}

/* A request failed (server error, timeout, lost connection). */
static void onlineFail(const char *msg) {
    if (mode == MODE_MP_SESSION) return;
    if (mode == MODE_ONLINE_LIST) {
        snprintf(listMsg, sizeof(listMsg), "%s", msg);
        return;
    }
    OnlineOp op = onlineOp;
    onlineOp = OP_NONE;
    if (mode == MODE_ONLINE_BUSY && op == OP_JOIN && opFromList && sockFd >= 0) {
        snprintf(listMsg, sizeof(listMsg), "%s", msg);
        lastListReq = 0;                 /* refresh the list right away */
        mode = MODE_ONLINE_LIST;
        return;
    }
    onlineDisconnect();
    socRelease();
    snprintf(statusMsg, sizeof(statusMsg), "%s", msg);
    mode = MODE_ONLINE_MENU;
}

static void startOnlineOp(OnlineOp op, const char *room, bool isPublic, bool fromList) {
    onlineOp = op;
    opSent = false;
    opFromList = fromList;
    opStart = osGetTime();
    onlineRoomPublic = isPublic;
    snprintf(onlineRoom, sizeof(onlineRoom), "%s", room);
    opDelay = sockFd >= 0 ? 0 : 3;       /* let "CONNECTING" draw first */
    statusMsg[0] = '\0';
    mode = MODE_ONLINE_BUSY;
}

static void sendOnlineRequest(uint64_t now) {
    uint8_t body[64];
    uint8_t *p = body;
    switch (onlineOp) {
    case OP_LIST:
        onlineSendFrame(ON_LIST, NULL, 0);
        lastListReq = now;
        break;
    case OP_CREATE:
        wr8(&p, ONLINE_VERSION);
        wr8(&p, onlineRoomPublic ? 1 : 0);
        wrStr(&p, onlineRoom);
        wrStr(&p, settingName);
        onlineSendFrame(ON_CREATE, body, (size_t)(p - body));
        break;
    case OP_JOIN:
        wr8(&p, ONLINE_VERSION);
        wrStr(&p, onlineRoom);
        onlineSendFrame(ON_JOIN, body, (size_t)(p - body));
        break;
    default: break;
    }
}

static void updateOnlineBusy(u32 down) {
    uint64_t now = osGetTime();
    if (down & (KEY_B | KEY_START)) {
        onlineOp = OP_NONE;
        if (opFromList && sockFd >= 0) {
            mode = MODE_ONLINE_LIST;
        } else {
            onlineDisconnect();
            socRelease();
            mode = MODE_ONLINE_MENU;
        }
        return;
    }
    if (opDelay > 0) { opDelay--; return; }
    if (sockFd < 0) {
        if (!onlineConnect()) {
            onlineFail(netError);
            return;
        }
        opStart = osGetTime();
    }
    if (!opSent) {
        sendOnlineRequest(now);
        opSent = true;
        opStart = now;
    }
    onlinePump(now);
    if (mode != MODE_ONLINE_BUSY) return;
    if (sockFd < 0) { onlineFail("Lost connection to the server."); return; }
    if (now - opStart > ONLINE_REPLY_MS) onlineFail("The server did not answer.");
}

/* Ask for a room name with the system keyboard, then run op on it. */
static void promptRoom(OnlineOp op, bool isPublic, bool fromList) {
    char name[ROOM_LEN + 1];
    char initial[ROOM_LEN + 1] = "";
    if (op == OP_CREATE) defaultRoomName(initial);
    const char *hint = op == OP_CREATE ? "Room name" : "Name of the room to join";
    if (!askText(hint, initial, name, ROOM_LEN)) return;
    if (op == OP_CREATE) snprintf(lastRoomName, sizeof(lastRoomName), "%s", name);
    startOnlineOp(op, name, isPublic, fromList);
}

static void updateOnlineMenu(u32 down) {
    if (down & (KEY_B | KEY_START)) {
        netStop();
        mode = MODE_MP_MENU;
        return;
    }
    moveSelection(&onlineMenuSel, 5, down);
    if (!(down & KEY_A)) return;
    statusMsg[0] = '\0';
    switch (onlineMenuSel) {
    case 0: promptRoom(OP_CREATE, true, false); break;
    case 1: promptRoom(OP_CREATE, false, false); break;
    case 2: roomCount = 0; roomSel = roomTop = 0; startOnlineOp(OP_LIST, "", true, false); break;
    case 3: promptRoom(OP_JOIN, false, false); break;
    default: netStop(); mode = MODE_MP_MENU; break;
    }
}

static void updateOnlineList(u32 down) {
    uint64_t now = osGetTime();
    onlinePump(now);
    if (mode != MODE_ONLINE_LIST) return;
    if (sockFd < 0) {
        socRelease();
        snprintf(statusMsg, sizeof(statusMsg), "Lost connection to the server.");
        mode = MODE_ONLINE_MENU;
        return;
    }
    if (down & (KEY_B | KEY_START)) {
        onlineDisconnect();
        socRelease();
        mode = MODE_ONLINE_MENU;
        return;
    }
    moveSelection(&roomSel, roomCount, down);
    if (roomSel < roomTop) roomTop = roomSel;
    if (roomSel >= roomTop + 4) roomTop = roomSel - 3;

    if ((down & KEY_Y) || now - lastListReq >= ONLINE_REFRESH_MS) {
        onlineSendFrame(ON_LIST, NULL, 0);
        lastListReq = now;
    }
    if ((down & KEY_A) && roomCount > 0) {
        const RoomInfo *r = &roomList[roomSel];
        if (r->state != 0) snprintf(listMsg, sizeof(listMsg), "That round already started.");
        else if (r->players >= r->max) snprintf(listMsg, sizeof(listMsg), "That room is full.");
        else startOnlineOp(OP_JOIN, r->name, true, true);
    } else if (down & KEY_X) {
        promptRoom(OP_JOIN, true, true);
    }
}

/* ---- settings ---- */
static void updateSettings(u32 down) {
    if (down & (KEY_B | KEY_START)) { mode = MODE_MENU; return; }
    moveSelection(&settingsSel, 3, down);
    if (!(down & KEY_A)) return;
    if (settingsSel == 0) {
        char tmp[NAME_LEN + 1];
        if (askText("Your name in multiplayer", settingName, tmp, NAME_LEN)) {
            snprintf(settingName, sizeof(settingName), "%s", tmp);
            saveSettings();
        }
    } else if (settingsSel == 1) {
        char tmp[SERVER_LEN + 1];
        if (askText("Server address (host:port)", settingServer, tmp, SERVER_LEN)) {
            snprintf(settingServer, sizeof(settingServer), "%s", tmp);
            saveSettings();
        }
    } else {
        mode = MODE_MENU;
    }
}

/* ------------------------------------------------------------------ */
/* Drawing                                                             */
/* ------------------------------------------------------------------ */
static uint32_t blockColor(int type) {
    switch (type & 7) {
        case 0: return C2D_Color32(235, 85, 75, 255);
        case 1: return C2D_Color32(70, 155, 245, 255);
        case 2: return C2D_Color32(185, 105, 235, 255);
        case 3: return C2D_Color32(235, 175, 55, 255);
        case 4: return C2D_Color32(75, 205, 145, 255);
        case 5: return C2D_Color32(60, 200, 215, 255);
        case 6: return C2D_Color32(240, 120, 170, 255);
        default: return C2D_Color32(225, 130, 60, 255);
    }
}

static void limb(float x0, float y0, float x1, float y1, float x2, float y2,
                 float thickness, uint32_t color) {
    lineSolid(x0, y0, 0, x1, y1, 0, thickness, color);
    lineSolid(x1, y1, 0, x2, y2, 0, thickness, color);
}

/* Animated stickman: idle, run cycle, jump poses and a two-handed shove. */
static void drawStickmanAnim(float px, float py, uint32_t color, const Anim *a) {
    float cx = px + PLAYER_W / 2.0f;
    float f = a->facing < 0 ? -1.0f : 1.0f;
    bool pushing = a->push > 0.0f && !a->air;
    float lean = pushing ? 3.0f * f : ((a->moving && !a->air) ? 2.5f * f : 0.0f);
    float bob = (a->moving && !a->air && !pushing) ? fabsf(sinf(a->phase)) * 1.8f : 0.0f;

    float hipX = cx, hipY = py + 23 - bob;
    float neckX = cx + lean, neckY = py + 11 - bob;
    float shX = cx + lean * 0.8f, shY = py + 14 - bob;

    circleSolid(neckX + lean * 0.3f, py + 5 - bob, 5, color);
    lineSolid(neckX, neckY, 0, hipX, hipY, 0, 3, color);

    if (a->air == 1) {            /* rising: arms up, one knee driven forward */
        limb(shX, shY, shX - 5, shY - 5, shX - 8, py + 4, 2.5f, color);
        limb(shX, shY, shX + 5, shY - 5, shX + 8, py + 3, 2.5f, color);
        limb(hipX, hipY, hipX + f * 7, hipY + 4, hipX + f * 3, hipY + 10, 2.5f, color);
        limb(hipX, hipY, hipX - f * 3, hipY + 6, hipX - f * 8, hipY + 8, 2.5f, color);
    } else if (a->air == 2) {     /* falling: arms out, legs spread */
        limb(shX, shY, shX - 6, shY + 1, shX - 11, shY - 2, 2.5f, color);
        limb(shX, shY, shX + 6, shY + 1, shX + 11, shY - 2, 2.5f, color);
        limb(hipX, hipY, hipX - 4, hipY + 5, hipX - 7, hipY + 10, 2.5f, color);
        limb(hipX, hipY, hipX + 4, hipY + 5, hipX + 7, hipY + 10, 2.5f, color);
    } else {
        if (a->moving && !pushing) {          /* run cycle legs */
            for (int k = 0; k < 2; k++) {
                float pl = a->phase + (float)k * 3.14159265f;
                float lift = fmaxf(0.0f, cosf(pl)) * 5.0f;
                float footX = hipX + f * sinf(pl) * 9.0f;
                float footY = py + 33 - lift;
                float kneeX = hipX + f * (sinf(pl) * 5.0f + 3.0f);
                float kneeY = hipY + 5 - lift * 0.4f;
                limb(hipX, hipY, kneeX, kneeY, footX, footY, 2.5f, color);
            }
        } else {                               /* standing / braced for a shove */
            float spread = pushing ? 7.0f : 4.0f;
            limb(hipX, hipY, hipX - f * spread * 0.5f, py + 28, hipX - f * spread, py + 33, 2.5f, color);
            limb(hipX, hipY, hipX + f * spread * 0.5f, py + 28, hipX + f * (spread + 3), py + 33, 2.5f, color);
        }

        if (pushing) {                         /* both arms thrust forward */
            lineSolid(shX, shY, 0, shX + f * 15, shY + 1, 0, 2.5f, color);
            lineSolid(shX, shY + 2, 0, shX + f * 15, shY + 4, 0, 2.5f, color);
            uint32_t flash = C2D_Color32(255, 255, 255, 220);
            lineSolid(shX + f * 18, shY - 3, 0, shX + f * 24, shY - 7, 0, 1.5f, flash);
            lineSolid(shX + f * 19, shY + 2, 0, shX + f * 26, shY + 2, 0, 1.5f, flash);
            lineSolid(shX + f * 18, shY + 7, 0, shX + f * 24, shY + 11, 0, 1.5f, flash);
        } else if (a->moving) {                /* swinging arms */
            for (int k = 0; k < 2; k++) {
                float pa = a->phase + (float)k * 3.14159265f + 3.14159265f;
                float elbowX = shX + f * sinf(pa) * 4.0f;
                float elbowY = shY + 4;
                float handX = shX + f * (sinf(pa) * 8.0f + 2.0f);
                float handY = shY + 7 - fmaxf(0.0f, cosf(pa)) * 2.0f;
                limb(shX, shY, elbowX, elbowY, handX, handY, 2.5f, color);
            }
        } else {                               /* arms hanging */
            limb(shX, shY, shX - 4, shY + 5, shX - 6, shY + 10, 2.5f, color);
            limb(shX, shY, shX + 4, shY + 5, shX + 6, shY + 10, 2.5f, color);
        }
    }
}

/* Draw a stickman in world space (applies the camera offset). */
static void drawStickmanWorld(float px, float py, uint32_t color, const Anim *a) {
    yOff = camY;
    drawStickmanAnim(px, py, color, a);
    yOff = 0.0f;
}

/* Expanding shockwave ring for a blast, centred on the stickman. */
static void drawBlastFx(float px, float py, float t) {
    if (t <= 0.0f) return;
    float k = 1.0f - t / BLAST_FX_TIME;             /* 0 -> 1 */
    float r = 10.0f + (BLAST_RADIUS - 10.0f) * k;
    float cx = px + PLAYER_W / 2.0f, cy = py + PLAYER_H / 2.0f;
    uint32_t clr = C2D_Color32(255, (uint8_t)(220 - 120 * k), 90, (uint8_t)(255 - 200 * k));
    yOff = camY;
    for (int i = 0; i < 20; i++) {
        float a0 = (float)i * 0.31415927f, a1 = (float)(i + 1) * 0.31415927f;
        lineSolid(cx + cosf(a0) * r, cy + sinf(a0) * r, 0, cx + cosf(a1) * r, cy + sinf(a1) * r, 0, 2.0f, clr);
    }
    yOff = 0.0f;
}

/* Bottom-left: blast cooldown. */
static void drawAbilityHud(const Body *b, float y) {
    char line[32];
    if (b->blastCd > 0.0f) snprintf(line, sizeof(line), "BLAST %ds", (int)(b->blastCd + 0.999f));
    else snprintf(line, sizeof(line), "BLAST READY");
    drawText(line, 8, y, 0.42f, b->blastCd > 0.0f ? C2D_Color32(170, 185, 215, 255)
                                                   : C2D_Color32(120, 230, 150, 255), 0);
}

static void drawWorld(void) {
    yOff = camY;
    /* faint height guides so the rising view is easy to read */
    uint32_t guide = C2D_Color32(28, 38, 60, 255);
    float first = floorf(camY / 80.0f) * 80.0f;
    for (float wy = first; wy < camY + SCREEN_H + 80.0f; wy += 80.0f)
        rectSolid(0, wy, SCREEN_W, 1, 0, guide);

    rectSolid(0, FLOOR_Y, SCREEN_W, 60, 0, C2D_Color32(55, 65, 85, 255));

    for (int i = 0; i < MAX_BLOCKS; i++) {
        if (!blocks[i].active) continue;
        float sy = blocks[i].y - camY;
        if (sy > SCREEN_H || sy + blocks[i].h < 0) continue; /* off screen */
        rectSolid(blocks[i].x, blocks[i].y, blocks[i].w, blocks[i].h, 0,
                  blockColor(blocks[i].type));
        rectSolid(blocks[i].x + 3, blocks[i].y + 3,
                  blocks[i].w > 6 ? blocks[i].w - 6 : blocks[i].w,
                  2, 0, C2D_Color32(255, 255, 255, 100));
    }
    yOff = 0.0f;

    /* walls, and a red kill strip once the view is rising */
    rectSolid(0, 0, 3, SCREEN_H, 0, C2D_Color32(35, 45, 65, 255));
    rectSolid(SCREEN_W - 3, 0, 3, SCREEN_H, 0, C2D_Color32(35, 45, 65, 255));
    if (scrolling)
        rectSolid(0, SCREEN_H - 5, SCREEN_W, 5, 0, C2D_Color32(210, 55, 55, 255));
}

static int heightMeters(void) {
    int m = (int)((GROUND_Y - (mode == MODE_SINGLE ? singleFocusY() : playerY)) / 12.0f);
    return m < 0 ? 0 : m;
}

/* "THE SCREEN RISES IN 3" countdown during the grace period. */
static void drawRiseHint(uint32_t elapsed) {
    if (elapsed >= SCROLL_DELAY_MS) return;
    char line[48];
    snprintf(line, sizeof(line), "THE SCREEN RISES IN %u",
             (unsigned)((SCROLL_DELAY_MS - elapsed + 999) / 1000));
    drawTextCentered(line, SCREEN_W / 2.0f, 30, 0.5f, C2D_Color32(255, 170, 80, 255));
}

static void updateBackdrop(float dt) {
    for (int i = 0; i < 16; i++) {
        bgBlocks[i].y += bgBlocks[i].speed * dt;
        if (bgBlocks[i].y > SCREEN_H) {
            bgBlocks[i].type = rand() % 8;
            bgBlocks[i].w = 14.0f + (float)(rand() % 36);
            bgBlocks[i].h = 10.0f + (float)(rand() % 30);
            bgBlocks[i].x = (float)(rand() % (SCREEN_W - 40));
            bgBlocks[i].y = -bgBlocks[i].h;
            bgBlocks[i].speed = 30.0f + (float)(rand() % 70);
        }
    }
}

static void initBackdrop(void) {
    for (int i = 0; i < 16; i++) {
        bgBlocks[i].type = rand() % 8;
        bgBlocks[i].w = 14.0f + (float)(rand() % 36);
        bgBlocks[i].h = 10.0f + (float)(rand() % 30);
        bgBlocks[i].x = (float)(rand() % (SCREEN_W - 40));
        bgBlocks[i].y = (float)(rand() % SCREEN_H);
        bgBlocks[i].speed = 30.0f + (float)(rand() % 70);
    }
}

static void drawBackdrop(void) {
    for (int i = 0; i < 16; i++) {
        uint32_t c = blockColor(bgBlocks[i].type);
        /* dim the colour so the foreground stays readable */
        uint32_t dim = (c & 0x00FFFFFFu) | 0x50000000u;
        rectSolid(bgBlocks[i].x, bgBlocks[i].y, bgBlocks[i].w, bgBlocks[i].h, 0, dim);
    }
    rectSolid(0, 232, SCREEN_W, 8, 0, C2D_Color32(55, 65, 85, 255));
}

static void drawTitle(const char *title, const char *subtitle) {
    uint32_t gold = C2D_Color32(255, 210, 80, 255);
    drawText(title, SCREEN_W / 2.0f + 2, 22, 1.4f, C2D_Color32(0, 0, 0, 255), 1);
    drawText(title, SCREEN_W / 2.0f, 20, 1.4f, gold, 1);
    if (subtitle)
        drawText(subtitle, SCREEN_W / 2.0f, 70, 0.55f, C2D_Color32(170, 185, 215, 255), 1);
}

static void drawButtonH(float y, const char *label, bool selected, float h) {
    float x = 100, w = 200;
    uint32_t border = selected ? C2D_Color32(255, 210, 80, 255) : C2D_Color32(70, 85, 115, 255);
    uint32_t fill = selected ? C2D_Color32(60, 75, 115, 255) : C2D_Color32(28, 36, 58, 255);
    uint32_t txt = selected ? C2D_Color32(255, 255, 255, 255) : C2D_Color32(160, 170, 190, 255);
    rectSolid(x - 3, y - 3, w + 6, h + 6, 0, border);
    rectSolid(x, y, w, h, 0, fill);
    drawTextCentered(label, x + w / 2.0f, y + h / 2.0f, 0.6f, txt);
    if (selected) drawText(">", x + 10, y + h / 2.0f - 10.0f, 0.6f, C2D_Color32(255, 210, 80, 255), 0);
}

static void drawButton(float y, const char *label, bool selected) {
    drawButtonH(y, label, selected, 32.0f);
}

/* Wide row for room lists and settings: label on the left, value on the right. */
static void drawRow(float y, const char *label, const char *value, uint32_t valueColor,
                    bool selected, float h) {
    float x = 30, w = 340;
    uint32_t border = selected ? C2D_Color32(255, 210, 80, 255) : C2D_Color32(70, 85, 115, 255);
    uint32_t fill = selected ? C2D_Color32(60, 75, 115, 255) : C2D_Color32(28, 36, 58, 255);
    uint32_t txt = selected ? C2D_Color32(255, 255, 255, 255) : C2D_Color32(190, 198, 215, 255);
    rectSolid(x - 2, y - 2, w + 4, h + 4, 0, border);
    rectSolid(x, y, w, h, 0, fill);
    drawText(label, x + 12, y + h / 2.0f - 9.0f, 0.5f, txt, 0);
    if (value && value[0]) drawText(value, x + w - 10, y + h / 2.0f - 9.0f, 0.5f, valueColor, 2);
}

static void drawMenuStickman(void) {
    /* Two stickmen jog back and forth along the floor. */
    for (int k = 0; k < 2; k++) {
        float t = menuClock * 0.7f + (float)k * 3.14159f;
        float x = 200.0f - PLAYER_W / 2.0f + sinf(t) * 150.0f;
        Anim a;
        a.facing = cosf(t) > 0 ? 1 : -1;
        a.moving = true;
        a.air = 0;
        a.push = 0.0f;
        a.phase = menuClock * 18.0f + (float)k * 1.5f;
        drawStickmanAnim(x, GROUND_Y, playerColor(k), &a);
    }
}

static void drawMainMenu(void) {
    drawBackdrop();
    drawTitle("BLOCKFALL", "STICKMAN SURVIVAL");
    drawButtonH(98, "PLAY GAME", menuSel == 0, 28.0f);
    drawButtonH(134, "MULTIPLAYER", menuSel == 1, 28.0f);
    drawButtonH(170, "SETTINGS", menuSel == 2, 28.0f);
    drawMenuStickman();
}

static void drawMpMenu(void) {
    drawBackdrop();
    drawTitle("MULTIPLAYER", statusMsg[0] ? NULL : "UP TO 8 PLAYERS - LOCAL OR ONLINE");
    if (statusMsg[0])
        drawText(statusMsg, SCREEN_W / 2.0f, 70, 0.42f, C2D_Color32(255, 120, 110, 255), 1);
    drawButton(90, "LOCAL: HOST GAME", mpMenuSel == 0);
    drawButton(128, "LOCAL: JOIN GAME", mpMenuSel == 1);
    drawButton(166, "ONLINE", mpMenuSel == 2);
    drawButton(204, "BACK", mpMenuSel == 3);
}

static void drawOnlineMenu(void) {
    drawBackdrop();
    drawTitle("ONLINE", NULL);
    if (statusMsg[0])
        drawText(statusMsg, SCREEN_W / 2.0f, 68, 0.42f, C2D_Color32(255, 120, 110, 255), 1);
    else
        drawText(settingServer, SCREEN_W / 2.0f, 68, 0.42f, C2D_Color32(140, 155, 190, 255), 1);
    drawButtonH(88, "HOST PUBLIC ROOM", onlineMenuSel == 0, 24.0f);
    drawButtonH(116, "HOST PRIVATE ROOM", onlineMenuSel == 1, 24.0f);
    drawButtonH(144, "BROWSE PUBLIC ROOMS", onlineMenuSel == 2, 24.0f);
    drawButtonH(172, "JOIN BY ROOM NAME", onlineMenuSel == 3, 24.0f);
    drawButtonH(200, "BACK", onlineMenuSel == 4, 24.0f);
}

static void drawOnlineBusy(void) {
    drawBackdrop();
    drawTitle("ONLINE", NULL);
    const char *what = onlineOp == OP_CREATE ? "CREATING ROOM..." :
                       onlineOp == OP_JOIN ? "JOINING ROOM..." : "LOADING ROOMS...";
    if (sockFd < 0) what = "CONNECTING TO SERVER...";
    drawTextCentered(what, SCREEN_W / 2.0f, 120, 0.6f, C2D_Color32(230, 230, 240, 255));
    drawTextCentered(settingServer, SCREEN_W / 2.0f, 150, 0.42f, C2D_Color32(140, 155, 190, 255));
    drawTextCentered("B: CANCEL", SCREEN_W / 2.0f, 200, 0.42f, C2D_Color32(170, 185, 215, 255));
}

/* Room rows shared by the local join list and the online browser. */
static void drawRoomRows(const RoomInfo *rooms, int count, int sel, int top) {
    int shown = count - top > 4 ? 4 : count - top;
    for (int k = 0; k < shown; k++) {
        const RoomInfo *r = &rooms[top + k];
        char label[40], value[24];
        if (r->known) {
            snprintf(label, sizeof(label), "%s", r->name);
            snprintf(value, sizeof(value), "%s%u/%u", r->state ? "IN GAME  " : "",
                     (unsigned)r->players, (unsigned)r->max);
        } else {
            snprintf(label, sizeof(label), "GAME %d", top + k + 1);
            value[0] = '\0';
        }
        drawRow(76.0f + (float)k * 34.0f, label, value,
                r->state ? C2D_Color32(255, 170, 80, 255) : C2D_Color32(120, 230, 150, 255),
                top + k == sel, 28.0f);
    }
    if (top > 0) drawText("^", SCREEN_W - 14, 72, 0.5f, C2D_Color32(170, 185, 215, 255), 1);
    if (top + shown < count) drawText("v", SCREEN_W - 14, 190, 0.5f, C2D_Color32(170, 185, 215, 255), 1);
}

static void drawOnlineList(void) {
    drawBackdrop();
    drawTitle("PUBLIC ROOMS", NULL);
    if (roomCount == 0) {
        drawTextCentered("NO PUBLIC ROOMS RIGHT NOW", SCREEN_W / 2.0f, 112, 0.55f,
                         C2D_Color32(255, 150, 130, 255));
        drawTextCentered("HOST ONE FROM THE ONLINE MENU!", SCREEN_W / 2.0f, 136, 0.42f,
                         C2D_Color32(170, 185, 215, 255));
    } else {
        drawRoomRows(roomList, roomCount, roomSel, roomTop);
    }
    if (listMsg[0])
        drawTextCentered(listMsg, SCREEN_W / 2.0f, 214, 0.42f, C2D_Color32(255, 120, 110, 255));
    drawTextCentered("A: JOIN  X: BY NAME  Y: REFRESH  B: BACK", SCREEN_W / 2.0f, 230, 0.38f,
                     C2D_Color32(170, 185, 215, 255));
}

static void drawSettings(void) {
    drawBackdrop();
    drawTitle("SETTINGS", NULL);
    uint32_t val = C2D_Color32(255, 210, 80, 255);
    drawRow(84, "PLAYER NAME", settingName, val, settingsSel == 0, 34.0f);
    drawRow(128, "SERVER", settingServer, val, settingsSel == 1, 34.0f);
    drawRow(172, "BACK", "", val, settingsSel == 2, 34.0f);
    drawTextCentered("A: EDIT WITH KEYBOARD   B: BACK", SCREEN_W / 2.0f, 224, 0.4f,
                     C2D_Color32(170, 185, 215, 255));
}

static void drawJoinScreen(void) {
    drawBackdrop();
    drawTitle("JOIN GAME", NULL);
    if (scanCountdown > 0) {
        drawTextCentered("SCANNING FOR GAMES...", SCREEN_W / 2.0f, 130, 0.6f,
                         C2D_Color32(230, 230, 240, 255));
        return;
    }
    if (localCount == 0) {
        drawTextCentered("NO GAMES FOUND", SCREEN_W / 2.0f, 120, 0.6f,
                         C2D_Color32(255, 150, 130, 255));
        drawTextCentered("Y: SCAN AGAIN   B: BACK", SCREEN_W / 2.0f, 150, 0.45f,
                         C2D_Color32(170, 185, 215, 255));
    } else {
        drawRoomRows(localRooms, localCount, joinSel, joinTop);
        if (joinMsg[0])
            drawTextCentered(joinMsg, SCREEN_W / 2.0f, 214, 0.42f, C2D_Color32(255, 120, 110, 255));
        drawTextCentered("A: JOIN  X: FIND BY NAME  Y: RESCAN  B: BACK", SCREEN_W / 2.0f, 230, 0.38f,
                         C2D_Color32(170, 185, 215, 255));
    }
}

static void playerName(int i, char *out, size_t size) {
    char tmp[8];
    snprintf(out, size, "%s%s%s", playerLabel(i, tmp, sizeof(tmp)),
             i == 0 ? " (HOST)" : "", i == myIndex ? " - YOU" : "");
}

static void drawLobby(void) {
    drawBackdrop();
    drawTitle("LOBBY", NULL);
    if (roomName[0]) {
        char info[64];
        snprintf(info, sizeof(info), "ROOM: %s   (%s%s)", roomName,
                 roomOnline ? "ONLINE" : "LOCAL",
                 (roomOnline && isHost) ? (roomPublic ? ", PUBLIC" : ", PRIVATE") : "");
        drawText(info, SCREEN_W / 2.0f, 60, 0.4f, C2D_Color32(140, 155, 190, 255), 1);
    }

    if (!isHost && !welcomed) {
        drawTextCentered("CONNECTING TO HOST...", SCREEN_W / 2.0f, 130, 0.6f,
                         C2D_Color32(230, 230, 240, 255));
        return;
    }

    /* 8 slots in two columns of 4 */
    for (int i = 0; i < MAX_PLAYERS; i++) {
        float x = (i < 4) ? 10.0f : 205.0f;
        float y = 78.0f + (float)(i % 4) * 33.0f;
        rectSolid(x, y, 185, 28, 0, C2D_Color32(28, 36, 58, 255));
        if (players[i].connected) {
            char name[48];
            playerName(i, name, sizeof(name));
            rectSolid(x, y, 5, 28, 0, playerColor(i));
            drawText(name, x + 14, y + 4, 0.42f, playerColor(i), 0);
        } else {
            drawText("WAITING...", x + 14, y + 4, 0.42f, C2D_Color32(100, 110, 135, 255), 0);
        }
    }

    if (isHost) {
        if (countConnected() >= 2)
            drawTextCentered("A: START ROUND   B: LEAVE", SCREEN_W / 2.0f, 218, 0.45f,
                             C2D_Color32(120, 230, 150, 255));
        else
            drawTextCentered("WAITING FOR PLAYERS TO JOIN...", SCREEN_W / 2.0f, 218, 0.45f,
                             C2D_Color32(170, 185, 215, 255));
    } else {
        drawTextCentered("WAITING FOR HOST TO START   B: LEAVE", SCREEN_W / 2.0f, 218, 0.42f,
                         C2D_Color32(170, 185, 215, 255));
    }
}

static void drawMpMatch(void) {
    drawWorld();

    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (!players[i].connected || !players[i].alive) continue;
        float px = (i == myIndex) ? playerX : players[i].x;
        float py = (i == myIndex) ? playerY : players[i].y;
        drawStickmanWorld(px, py, playerColor(i),
                          (i == myIndex) ? &playerAnim : &players[i].anim);
        drawBlastFx(px, py, (i == myIndex) ? me.blastFx : players[i].blastFx);
        char tag[NAME_LEN + 8], tmp[8];
        if (i == myIndex) snprintf(tag, sizeof(tag), "YOU");
        else snprintf(tag, sizeof(tag), "%s", playerLabel(i, tmp, sizeof(tmp)));
        drawText(tag, px + PLAYER_W / 2.0f, py - 16 - camY, 0.4f, playerColor(i), 1);
    }

    /* HUD */
    char tbuf[32];
    char line[48];
    uint32_t elapsed = mpElapsed();
    if (mpState == MP_PLAYING || mpState == MP_RESULTS) {
        printTime(elapsed, tbuf, sizeof(tbuf));
        drawText(tbuf, 8, 4, 0.55f, C2D_Color32(240, 240, 250, 255), 0);
        snprintf(line, sizeof(line), "HEIGHT %d M", heightMeters());
        drawText(line, 8, 24, 0.42f, C2D_Color32(170, 185, 215, 255), 0);
    }
    snprintf(line, sizeof(line), "ALIVE: %d", countAlive());
    drawText(line, SCREEN_W - 8, 4, 0.55f, C2D_Color32(240, 240, 250, 255), 2);
    if (mpState == MP_PLAYING) drawRiseHint(elapsed);
    if (mpState == MP_PLAYING && myIndex >= 0 && players[myIndex].alive) drawAbilityHud(&me, 222);

    if (myIndex >= 0 && !players[myIndex].alive && mpState == MP_PLAYING)
        drawTextCentered("YOU ARE OUT - SPECTATING", SCREEN_W / 2.0f, 50, 0.55f,
                         C2D_Color32(255, 120, 110, 255));

    if (mpState == MP_COUNTDOWN) {
        snprintf(line, sizeof(line), "%u", (unsigned)((mpTime + 999) / 1000));
        drawTextCentered(line, SCREEN_W / 2.0f, 100, 2.6f, C2D_Color32(255, 210, 80, 255));
        drawTextCentered("GET READY!  R PUSHES   L BLASTS", SCREEN_W / 2.0f, 150, 0.55f,
                         C2D_Color32(240, 240, 250, 255));
    }

    if (mpState == MP_RESULTS) {
        computeRanking();
        rectSolid(60, 16, 280, 214, 0, C2D_Color32(0, 0, 0, 220));
        rectSolid(64, 20, 272, 206, 0, C2D_Color32(40, 30, 60, 235));
        drawTextCentered("ROUND OVER", SCREEN_W / 2.0f, 36, 0.75f, C2D_Color32(255, 210, 80, 255));
        for (int k = 0; k < rankCount; k++) {
            int i = rankOrder[k];
            char name[48], tm[32], row[96];
            playerName(i, name, sizeof(name));
            printTime(players[i].timeMs, tm, sizeof(tm));
            snprintf(row, sizeof(row), "%d. %s  %s%s", k + 1, name, tm,
                     (k == 0) ? "  WIN" : "");
            drawText(row, 76, 58.0f + (float)k * 18.0f, 0.4f, playerColor(i), 0);
        }
        if (isHost)
            drawTextCentered("A: PLAY AGAIN   B: LEAVE", SCREEN_W / 2.0f, 212, 0.42f,
                             C2D_Color32(120, 230, 150, 255));
        else
            drawTextCentered("WAITING FOR HOST   B: LEAVE", SCREEN_W / 2.0f, 212, 0.42f,
                             C2D_Color32(170, 185, 215, 255));
    }
}

static void drawSingle(void) {
    drawWorld();
    if (me.alive) drawStickmanWorld(me.x, me.y, playerColor(0), &me.anim);
    if (p2Active && p2.alive) drawStickmanWorld(p2.x, p2.y, playerColor(1), &p2.anim);
    if (me.alive) drawBlastFx(me.x, me.y, me.blastFx);
    if (p2Active && p2.alive) drawBlastFx(p2.x, p2.y, p2.blastFx);
    char tm[32], line[64];
    uint32_t ms = displayMs();
    printTime(ms, tm, sizeof(tm));
    drawText(tm, 8, 4, 0.55f, C2D_Color32(240, 240, 250, 255), 0);
    snprintf(line, sizeof(line), "HEIGHT %d M", heightMeters());
    drawText(line, SCREEN_W - 8, 4, 0.55f, C2D_Color32(240, 240, 250, 255), 2);
    if (!gameOver) drawRiseHint(ms);
    if (!gameOver) {
        if (me.alive) drawAbilityHud(&me, 222);
        if (p2Active && p2.alive) {
            char l2[32];
            if (p2.blastCd > 0.0f) snprintf(l2, sizeof(l2), "P2 BLAST %ds", (int)(p2.blastCd + 0.999f));
            else snprintf(l2, sizeof(l2), "P2 BLAST READY");
            drawText(l2, SCREEN_W - 8, 222, 0.42f, C2D_Color32(255, 150, 130, 255), 2);
        } else if (!p2Active) {
            drawText("P2: PRESS ZL / ZR TO JOIN", SCREEN_W - 8, 222, 0.38f,
                     C2D_Color32(120, 135, 165, 255), 2);
        }
    }

    if (gameOver) {
        rectSolid(55, 70, 290, 100, 0, C2D_Color32(0, 0, 0, 210));
        rectSolid(59, 74, 282, 92, 0, C2D_Color32(90, 25, 35, 230));
        drawTextCentered("GAME OVER", SCREEN_W / 2.0f, 98, 0.9f, C2D_Color32(255, 230, 230, 255));
        snprintf(line, sizeof(line), p2Active ? "YOU SURVIVED %s  (CO-OP)" : "YOU SURVIVED %s", tm);
        drawTextCentered(line, SCREEN_W / 2.0f, 128, 0.5f, C2D_Color32(255, 210, 80, 255));
        drawTextCentered("A / B / X / Y: TRY AGAIN", SCREEN_W / 2.0f, 150, 0.42f,
                         C2D_Color32(230, 200, 200, 255));
    }
}

static void renderTop(void) {
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TextBufClear(textBuf);
    C2D_SceneBegin(top);
    C2D_TargetClear(top, C2D_Color32(12, 16, 28, 255));
    yOff = 0.0f;

    switch (mode) {
    case MODE_MENU:   drawMainMenu(); break;
    case MODE_SINGLE: drawSingle(); break;
    case MODE_MP_MENU: drawMpMenu(); break;
    case MODE_MP_JOIN: drawJoinScreen(); break;
    case MODE_SETTINGS: drawSettings(); break;
    case MODE_ONLINE_MENU: drawOnlineMenu(); break;
    case MODE_ONLINE_BUSY: drawOnlineBusy(); break;
    case MODE_ONLINE_LIST: drawOnlineList(); break;
    case MODE_MP_SESSION:
        if (mpState == MP_LOBBY || (!isHost && !welcomed)) drawLobby();
        else drawMpMatch();
        break;
    }
    C3D_FrameEnd(0);
}

/* ------------------------------------------------------------------ */
/* Bottom screen (console)                                             */
/* ------------------------------------------------------------------ */
static void printLeaderboard(void) {
    printf("\n  BEST SURVIVAL TIMES\n");
    printf("  ------------------\n");
    for (int i = 0; i < LEADERBOARD_SIZE; i++) {
        char scoreString[32];
        if (bestTimes[i]) printTime(bestTimes[i], scoreString, sizeof(scoreString));
        else strcpy(scoreString, "--:--.---");
        printf("  %d. %s\n", i + 1, scoreString);
    }
}

static void printBottom(void) {
    consoleClear();
    printf("\x1b[1;1H       BLOCKFALL: STICKMAN SURVIVAL\n");
    printf("====================================\n\n");

    switch (mode) {
    case MODE_MENU:
        printf("  HOME\n\n");
        printf("  D-PAD UP/DOWN : choose\n");
        printf("  A             : select\n");
        printf("  START         : quit\n\n");
        printf("  Playing as: %s\n", settingName);
        printLeaderboard();
        break;

    case MODE_SINGLE: {
        char timeString[32];
        uint32_t ms = displayMs();
        printTime(ms, timeString, sizeof(timeString));
        printf("  SURVIVAL TIME: %s\n", timeString);
        printf("  HEIGHT: %d M\n", heightMeters());
        printf("  DIFFICULTY: %s\n",
            ms < 15000 ? "EASY" :
            ms < 30000 ? "MEDIUM" :
            ms < 60000 ? "HARD" :
            ms < 90000 ? "EXTREME" : "NIGHTMARE");
        printLeaderboard();
        if (gameOver) {
            printf("\n  *** GAME OVER! ***\n");
            printf("  Press A/B/X/Y to retry.\n");
        } else {
            printf("\n  D-PAD / CIRCLE PAD: MOVE\n");
            printf("  A / B / UP: JUMP (again in air,\n");
            printf("      or off a wall once)\n");
            printf("  R: tap push, hold shove block\n");
            printf("  L: blast blocks (15 s cooldown)\n");
            if (p2Active) printf("  P2: C-STICK ZL=JUMP ZR=PUSH SEL=BLAST\n");
            else printf("  P2 joins with ZL / ZR / SELECT\n");
        }
        printf("  START: MENU\n");
        break;
    }

    case MODE_MP_MENU:
        printf("  MULTIPLAYER\n\n");
        printf("  LOCAL: wireless, up to 8 consoles\n");
        printf("  with this same app, close together.\n");
        printf("  Host types a room name; others\n");
        printf("  pick it from the list.\n\n");
        printf("  ONLINE: play over the internet\n");
        printf("  through the Blockfall server.\n");
        printf("  Public or private rooms.\n\n");
        printf("  You appear as: %s\n", settingName);
        printf("  (change it in SETTINGS)\n\n");
        printf("  Last stickman standing wins.\n");
        printf("  Shove rivals with X / Y / L / R!\n");
        break;

    case MODE_SETTINGS:
        printf("  SETTINGS\n\n");
        printf("  PLAYER NAME\n    %s\n\n", settingName);
        printf("  SERVER (online play)\n    %s\n\n", settingServer);
        printf("  A: edit with the keyboard\n");
        printf("  B: back (saved automatically)\n");
        break;

    case MODE_ONLINE_MENU:
        printf("  ONLINE\n\n");
        printf("  Server: %.28s\n\n", settingServer);
        printf("  HOST PUBLIC  - listed for all\n");
        printf("  HOST PRIVATE - not listed; friends\n");
        printf("                 type the room name\n");
        printf("  BROWSE       - pick a public room\n");
        printf("  JOIN BY NAME - enter a room name\n\n");
        printf("  You appear as: %s\n", settingName);
        printf("  B: back\n");
        break;

    case MODE_ONLINE_BUSY:
        printf("  ONLINE\n\n");
        if (sockFd < 0) printf("  Connecting to\n  %.34s ...\n", settingServer);
        else printf("  Waiting for the server...\n");
        printf("\n  B: cancel\n");
        break;

    case MODE_ONLINE_LIST:
        printf("  PUBLIC ROOMS\n\n");
        printf("  Rooms found: %d\n", roomCount);
        if (roomCount > 0 && roomSel < roomCount) {
            const RoomInfo *r = &roomList[roomSel];
            printf("\n  Selected: %s\n", r->name);
            printf("  Host:     %s\n", r->host);
            printf("  Players:  %u/%u%s\n", (unsigned)r->players, (unsigned)r->max,
                   r->state ? "  (in game)" : "");
        }
        printf("\n  UP/DOWN: pick   A: join\n");
        printf("  X: join by name Y: refresh\n");
        printf("  B: back\n");
        break;

    case MODE_MP_JOIN:
        printf("  JOIN A GAME\n\n");
        if (scanCountdown > 0) printf("  Scanning...\n");
        else printf("  Games found: %d\n", localCount);
        printf("\n  UP/DOWN: pick   A: join\n");
        printf("  X: find by name Y: rescan\n");
        printf("  B: back\n");
        break;

    case MODE_MP_SESSION: {
        printf("  %s%s%s\n", isHost ? "HOSTING" : "CLIENT", roomName[0] ? ": " : "", roomName);
        printf("  %s%s\n", roomOnline ? "Online" : "Local wireless",
               (roomOnline && isHost) ? (roomPublic ? " - public" : " - private") : "");
        printf("  Players: %d/%d\n", countConnected(), MAX_PLAYERS);
        for (int i = 0; i < MAX_PLAYERS; i++) {
            if (!players[i].connected) continue;
            char name[48], tm[32];
            playerName(i, name, sizeof(name));
            if (mpState == MP_PLAYING || mpState == MP_RESULTS) {
                if (players[i].alive) printf("  %-26s ALIVE\n", name);
                else {
                    printTime(players[i].timeMs, tm, sizeof(tm));
                    printf("  %-26s %s\n", name, tm);
                }
            } else {
                printf("  %s\n", name);
            }
        }
        printf("\n");
        if (mpState == MP_LOBBY) {
            if (isHost) printf("  A: start (needs 2+ players)\n");
            else printf("  Waiting for the host...\n");
            printf("  B: leave\n");
        } else if (mpState == MP_PLAYING) {
            printf("  MOVE: D-PAD / CIRCLE PAD\n");
            printf("  JUMP: A / B / D-PAD UP\n");
            printf("  R: push / hold = shove block\n");
            printf("  L: blast (15 s)  jump x2 / wall\n");
            printf("  START: leave\n");
        } else if (mpState == MP_RESULTS) {
            if (isHost) printf("  A: play again\n");
            printf("  B: leave\n");
        }
        break;
    }
    }
}

/* ------------------------------------------------------------------ */
/* One frame of logic (everything except drawing)                      */
/* ------------------------------------------------------------------ */
/* Returns false when the player quits from the home screen. */
static bool updateFrame(float dt, u32 down) {
    switch (mode) {
    case MODE_MENU:
        if (down & KEY_START) return false;
        moveSelection(&menuSel, 3, down);
        if (down & KEY_A) {
            if (menuSel == 0) {
                resetGame();
                skipJump = true;
                mode = MODE_SINGLE;
            } else if (menuSel == 1) {
                mpMenuSel = 0;
                statusMsg[0] = '\0';
                mode = MODE_MP_MENU;
            } else {
                settingsSel = 0;
                mode = MODE_SETTINGS;
            }
        }
        break;

    case MODE_SETTINGS:
        updateSettings(down);
        break;

    case MODE_SINGLE:
        if (down & KEY_START) { mode = MODE_MENU; break; }
        if (gameOver && (down & (KEY_A | KEY_B | KEY_X | KEY_Y | KEY_TOUCH))) {
            resetGame();
            skipJump = true; /* the restart press must not also jump */
        }
        updateSingle(dt);
        break;

    case MODE_MP_MENU:
        if (down & (KEY_B | KEY_START)) { mode = MODE_MENU; break; }
        moveSelection(&mpMenuSel, 4, down);
        if (down & KEY_A) {
            statusMsg[0] = '\0';
            if (mpMenuSel == 0) {
                /* local host: type a room name with the keyboard */
                char name[ROOM_LEN + 1];
                char initial[ROOM_LEN + 1];
                defaultRoomName(initial);
                if (askText("Room name", initial, name, ROOM_LEN)) {
                    snprintf(lastRoomName, sizeof(lastRoomName), "%s", name);
                    if (!hostStart(name)) snprintf(statusMsg, sizeof(statusMsg), "%s", netError);
                }
            } else if (mpMenuSel == 1) {
                if (netBegin()) {
                    joinSel = 0;
                    joinMsg[0] = '\0';
                    scanCountdown = 3;
                    mode = MODE_MP_JOIN;
                } else {
                    snprintf(statusMsg, sizeof(statusMsg), "%s", netError);
                }
            } else if (mpMenuSel == 2) {
                onlineMenuSel = 0;
                statusMsg[0] = '\0';
                mode = MODE_ONLINE_MENU;
            } else {
                mode = MODE_MENU;
            }
        }
        break;

    case MODE_ONLINE_MENU:
        updateOnlineMenu(down);
        break;

    case MODE_ONLINE_BUSY:
        updateOnlineBusy(down);
        break;

    case MODE_ONLINE_LIST:
        updateOnlineList(down);
        break;

    case MODE_MP_JOIN:
        if (down & (KEY_B | KEY_START)) {
            netStop();
            scanCountdown = 0;
            mode = MODE_MP_MENU;
            break;
        }
        if (scanCountdown > 0) {
            scanCountdown--;
            if (scanCountdown == 0) joinScan();
            break;
        }
        moveSelection(&joinSel, localCount, down);
        if (joinSel < joinTop) joinTop = joinSel;
        if (joinSel >= joinTop + 4) joinTop = joinSel - 3;
        if (down & KEY_Y) { scanCountdown = 3; joinMsg[0] = '\0'; }
        if ((down & KEY_X) && localCount > 0) {
            /* find a room by typing its name */
            char want[ROOM_LEN + 1];
            if (askText("Name of the room to find", NULL, want, ROOM_LEN)) {
                int found = -1;
                for (int i = 0; i < localCount; i++)
                    if (localRooms[i].known && sameText(localRooms[i].name, want)) { found = i; break; }
                if (found >= 0) {
                    joinSel = found;
                    joinMsg[0] = '\0';
                    if (joinSel < joinTop) joinTop = joinSel;
                    if (joinSel >= joinTop + 4) joinTop = joinSel - 3;
                } else {
                    snprintf(joinMsg, sizeof(joinMsg), "NO ROOM NAMED \"%.16s\"", want);
                }
            }
        }
        if ((down & KEY_A) && localCount > 0) {
            if (localRooms[joinSel].known && localRooms[joinSel].state != 0) {
                snprintf(joinMsg, sizeof(joinMsg), "THAT ROUND ALREADY STARTED");
            } else if (!joinConnect(joinSel)) {
                netStop();
                snprintf(statusMsg, sizeof(statusMsg), "%s", netError);
                mode = MODE_MP_MENU;
            }
        }
        break;

    case MODE_MP_SESSION:
        updateMultiplayer(dt, down);
        break;
    }
    return true;
}

/* ------------------------------------------------------------------ */
/* Main                                                                */
/* ------------------------------------------------------------------ */
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    gfxInitDefault();
    consoleInit(GFX_BOTTOM, NULL);
    cfguInit();
    romfsInit();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    textBuf = C2D_TextBufNew(4096);
    srand((unsigned int)osGetTime());
    loadLeaderboard();
    loadSettings();
    initBackdrop();
    lastFrame = osGetTime();
    mode = MODE_MENU;

    bool running = true;
    while (aptMainLoop() && running) {
        hidScanInput();
        u32 down = hidKeysDown();

        uint64_t now = osGetTime();
        float dt = (float)(now - lastFrame) / 1000.0f;
        if (dt > 0.05f) dt = 0.05f;
        if (dt < 0.0f) dt = 0.0f;
        lastFrame = now;
        menuClock += dt;
        updateBackdrop(dt);

        running = updateFrame(dt, down);

        renderTop();
        printBottom();
        gspWaitForVBlank();
    }

    netStop();
    C2D_TextBufDelete(textBuf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    cfguExit();
    gfxExit();
    return 0;
}
