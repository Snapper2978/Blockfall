#!/usr/bin/env bash
# Build Blockfall.cia (and optionally publish it to the updates/ folder).
#
#   ./cia/make_cia.sh 1 0 0                 # version 1.0.0
#   ./cia/make_cia.sh 1 1 0 --publish       # build 1.1.0 and copy to updates/
#
# Run it from the project folder, in a devkitPro shell (MSYS2 on Windows).
# Needs on PATH: make + devkitARM (DEVKITARM set), makerom, bannertool.
# Every NEW release must have a HIGHER version than the one installed.
set -euo pipefail
cd "$(dirname "$0")/.."

MAJOR=${1:-}; MINOR=${2:-}; MICRO=${3:-}
if [ -z "$MAJOR" ] || [ -z "$MINOR" ] || [ -z "$MICRO" ]; then
    echo "usage: $0 MAJOR MINOR MICRO [--publish]   e.g. $0 1 0 0" >&2
    exit 1
fi
PUBLISH=${4:-}
for tool in make makerom bannertool; do
    command -v "$tool" >/dev/null 2>&1 || { echo "missing tool: $tool (see cia/CIA_GUIDE.txt)" >&2; exit 1; }
done
: "${DEVKITARM:?DEVKITARM is not set - open a devkitPro shell}"

VERSION="$MAJOR.$MINOR.$MICRO"
OUT=cia/out
mkdir -p "$OUT"

echo "== building the game"
make

echo "== icon + banner"
bannertool makesmdh -s "Blockfall" -l "Blockfall: Stickman Survival" -p "Homebrew" \
    -i cia/icon.png -o "$OUT/icon.icn"
bannertool makebanner -i cia/banner.png -a cia/silence.wav -o "$OUT/banner.bnr"

echo "== packing Blockfall-$VERSION.cia"
makerom -f cia -o "$OUT/Blockfall-$VERSION.cia" -elf Blockfall.elf \
    -rsf cia/Blockfall.rsf -icon "$OUT/icon.icn" -banner "$OUT/banner.bnr" \
    -exefslogo -target t -major "$MAJOR" -minor "$MINOR" -micro "$MICRO"

echo "built $OUT/Blockfall-$VERSION.cia"

if [ "$PUBLISH" = "--publish" ]; then
    mkdir -p updates
    cp "$OUT/Blockfall-$VERSION.cia" "updates/Blockfall-$VERSION.cia"
    cp "$OUT/Blockfall-$VERSION.cia" updates/latest.cia
    echo "$VERSION" > updates/version.txt
    echo "published to updates/ (latest.cia + Blockfall-$VERSION.cia)"
fi
