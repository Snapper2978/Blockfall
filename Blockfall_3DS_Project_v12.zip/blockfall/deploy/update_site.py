#!/usr/bin/env python3
"""Tiny web page that hands out Blockfall updates.

    python3 update_site.py                    # serves ./updates on port 8080
    python3 update_site.py --dir /srv/updates --port 80

Put new builds in the updates folder (cia/make_cia.sh ... --publish does it):
    updates/latest.cia            <- always the newest build
    updates/Blockfall-1.2.0.cia   <- every release, kept
    updates/version.txt           <- e.g. 1.2.0
On the 3DS open FBI > Remote Install > Scan QR Code and scan a QR code of
http://YOUR-SERVER:8080/latest.cia  (any QR generator website will make one).
Read-only: GET/HEAD only, nothing outside the updates folder is served.
"""
import argparse
import html
import os
import sys
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer


class Handler(SimpleHTTPRequestHandler):
    def list_directory(self, path):                    # our own tidy index
        try:
            names = sorted(os.listdir(path), reverse=True)
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return None
        version = ""
        try:
            with open(os.path.join(path, "version.txt")) as f:
                version = f.read().strip()
        except OSError:
            pass
        rows = []
        for name in names:
            full = os.path.join(path, name)
            if name.startswith(".") or not os.path.isfile(full):
                continue
            size = os.path.getsize(full)
            rows.append('<li><a href="%s">%s</a> <small>(%.1f KB)</small></li>'
                        % (html.escape(name, quote=True), html.escape(name), size / 1024))
        page = ("<!doctype html><meta charset=utf-8><meta name=viewport "
                "content='width=device-width,initial-scale=1'><title>Blockfall updates</title>"
                "<body style='font-family:sans-serif;max-width:34em;margin:2em auto'>"
                "<h1>Blockfall updates</h1><p>Latest version: <b>%s</b></p>"
                "<p>On the 3DS: FBI &gt; Remote Install &gt; Scan QR Code, using a QR code of "
                "the <b>latest.cia</b> link.</p><ul>%s</ul></body>"
                % (html.escape(version or "unknown"), "\n".join(rows) or "<li>(empty)</li>"))
        data = page.encode()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        from io import BytesIO
        return BytesIO(data)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")   # always offer the newest
        super().end_headers()

    def do_POST(self):
        self.send_error(HTTPStatus.METHOD_NOT_ALLOWED)

    do_PUT = do_DELETE = do_POST


def main():
    ap = argparse.ArgumentParser(description="Blockfall update download page")
    ap.add_argument("--dir", default="updates", help="folder to serve (default ./updates)")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--host", default="0.0.0.0")
    args = ap.parse_args()
    root = os.path.abspath(args.dir)
    os.makedirs(root, exist_ok=True)
    handler = lambda *a, **k: Handler(*a, directory=root, **k)
    srv = ThreadingHTTPServer((args.host, args.port), handler)
    print("Serving %s on http://%s:%d/" % (root, args.host, args.port))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
