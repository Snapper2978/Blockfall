#!/usr/bin/env python3
"""Check that a Blockfall relay server is reachable, from ANY computer.

    python3 check_server.py your.domain.com        (port 7777)
    python3 check_server.py 203.0.113.5:7777

Does what a console does: connects, asks for the room list, reads the reply.
"""
import socket
import struct
import sys
import time

PROTOCOL_VERSION = 1


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1:7777"
    host, _, port = target.partition(":")
    port = int(port or 7777)
    t0 = time.time()
    try:
        s = socket.create_connection((host, port), timeout=6)
    except OSError as exc:
        print(f"FAIL: cannot connect to {host}:{port} ({exc})")
        print("  - is the server running?  - is TCP port %d open in the firewall /" % port)
        print("    cloud security group / router port-forward?")
        return 1
    ms = (time.time() - t0) * 1000
    try:
        s.sendall(struct.pack("<HB", 1, 0x01))                   # LIST
        s.settimeout(6)
        data = b""
        while len(data) < 3:
            chunk = s.recv(3 - len(data))
            if not chunk:
                break
            data += chunk
        if len(data) < 3 or data[2] != 0x81:
            print("FAIL: connected, but that is not a Blockfall server.")
            return 1
        (length,) = struct.unpack("<H", data[:2])
        body = b""
        while len(body) < length - 1:
            chunk = s.recv(length - 1 - len(body))
            if not chunk:
                break
            body += chunk
        rooms = body[0] if body else 0
        print(f"OK: Blockfall server at {host}:{port} answered "
              f"(connect {ms:.0f} ms, {rooms} public room(s) right now).")
        return 0
    except OSError as exc:
        print(f"FAIL: connected but no answer ({exc})")
        return 1
    finally:
        s.close()


if __name__ == "__main__":
    sys.exit(main())
