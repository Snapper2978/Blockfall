Put release builds here (cia/make_cia.sh MAJOR MINOR MICRO --publish does it for you).
